// =====================================
// PRODUCT DETAIL PAGE FUNCTIONALITY
// =====================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('Product detail page loaded');
    
    // Initialize all functionality
    initializeProductDetail();
    initializeImageGallery();
    initializeProductTabs();
    initializeQuantityControls();
    initializeActions();
    initializeRelatedProducts();
    
    // Load cart from localStorage and setup cart functionality
    if (typeof window.loadCartFromStorage === 'function') {
        window.loadCartFromStorage();
    }
    
    setupEventListeners();
});

function initializeProductDetail() {
    // Setup mobile menu with more robust selector
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    console.log('Mobile menu elements found:', { 
        toggle: !!mobileMenuToggle, 
        menu: !!navMenu 
    });
    
    if (mobileMenuToggle && navMenu) {
        // Remove any existing event listeners
        mobileMenuToggle.replaceWith(mobileMenuToggle.cloneNode(true));
        const newToggle = document.querySelector('.mobile-menu-toggle');
        
        newToggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            console.log('Mobile menu toggle clicked');
            navMenu.classList.toggle('active');
            
            // Toggle hamburger animation
            const icon = newToggle.querySelector('i');
            if (icon) {
                if (navMenu.classList.contains('active')) {
                    icon.classList.remove('fa-bars');
                    icon.classList.add('fa-times');
                } else {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
            }
            
            console.log('Menu active state:', navMenu.classList.contains('active'));
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!navMenu.contains(e.target) && !newToggle.contains(e.target)) {
                navMenu.classList.remove('active');
                const icon = newToggle.querySelector('i');
                if (icon) {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
            }
        });
        
        // Close menu when window is resized to desktop
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                navMenu.classList.remove('active');
                const icon = newToggle.querySelector('i');
                if (icon) {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
            }
        });
    }
    
    // Setup cart icon click
    const cartIcon = document.querySelector('.cart-icon-wrapper');
    if (cartIcon) {
        cartIcon.addEventListener('click', function() {
            if (typeof window.toggleCart === 'function') {
                window.toggleCart();
            }
        });
    }
    
    console.log('Product detail initialized');
}

function initializeImageGallery() {
    const thumbnails = document.querySelectorAll('.thumbnail');
    const mainImage = document.querySelector('.main-image');
    
    if (thumbnails.length > 0 && mainImage) {
        // Set first thumbnail as active
        thumbnails[0].classList.add('active');
        
        thumbnails.forEach((thumbnail, index) => {
            thumbnail.addEventListener('click', function() {
                // Remove active class from all thumbnails
                thumbnails.forEach(t => t.classList.remove('active'));
                
                // Add active class to clicked thumbnail
                this.classList.add('active');
                
                // Update main image with animation
                mainImage.style.opacity = '0.5';
                
                setTimeout(() => {
                    // In a real app, you would change the image source here
                    // mainImage.innerHTML = '<img src="' + newImageSrc + '" alt="Product Image">';
                    mainImage.style.opacity = '1';
                }, 200);
                
                console.log('Image changed to thumbnail', index + 1);
            });
        });
    }
}

function initializeProductTabs() {
    const tabHeaders = document.querySelectorAll('.tab-header');
    const tabContents = document.querySelectorAll('.tab-content');
    
    if (tabHeaders.length > 0 && tabContents.length > 0) {
        // Set first tab as active
        tabHeaders[0].classList.add('active');
        tabContents[0].classList.add('active');
        
        tabHeaders.forEach((header, index) => {
            header.addEventListener('click', function() {
                // Remove active class from all headers and contents
                tabHeaders.forEach(h => h.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked header and corresponding content
                this.classList.add('active');
                if (tabContents[index]) {
                    tabContents[index].classList.add('active');
                }
                
                console.log('Tab switched to:', this.textContent);
            });
        });
    }
}

function initializeQuantityControls() {
    const quantityInput = document.querySelector('.quantity-input');
    const decreaseBtn = document.querySelector('.quantity-btn.decrease');
    const increaseBtn = document.querySelector('.quantity-btn.increase');
    
    if (quantityInput && decreaseBtn && increaseBtn) {
        let currentQuantity = parseInt(quantityInput.value) || 1;
        
        decreaseBtn.addEventListener('click', function() {
            if (currentQuantity > 1) {
                currentQuantity--;
                quantityInput.value = currentQuantity;
                updateQuantityDisplay();
            }
        });
        
        increaseBtn.addEventListener('click', function() {
            if (currentQuantity < 99) {
                currentQuantity++;
                quantityInput.value = currentQuantity;
                updateQuantityDisplay();
            }
        });
        
        quantityInput.addEventListener('change', function() {
            let newQuantity = parseInt(this.value) || 1;
            if (newQuantity < 1) newQuantity = 1;
            if (newQuantity > 99) newQuantity = 99;
            
            currentQuantity = newQuantity;
            this.value = currentQuantity;
            updateQuantityDisplay();
        });
        
        function updateQuantityDisplay() {
            console.log('Quantity updated to:', currentQuantity);
            // Update any quantity-dependent displays here
        }
    }
}

function initializeActions() {
    const addToCartBtn = document.querySelector('.add-to-cart-btn');
    const buyNowBtn = document.querySelector('.buy-now-btn');
    const wishlistBtn = document.querySelector('.wishlist-btn');
    
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', function() {
            const productName = document.querySelector('.product-title')?.textContent || 'Product';
            const productPrice = document.querySelector('.current-price')?.textContent || '0';
            const productId = document.querySelector('[data-product-id]')?.dataset.productId || '1';
            const quantity = parseInt(document.querySelector('.quantity-input')?.value) || 1;
            
            // Add to cart multiple times based on quantity
            for (let i = 0; i < quantity; i++) {
                if (typeof window.addToCart === 'function') {
                    window.addToCart(productName, productPrice, productId);
                }
            }
            
            // Visual feedback
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="fas fa-check"></i> Đã thêm vào giỏ!';
            this.style.background = 'linear-gradient(135deg, #10b981, #059669)';
            
            setTimeout(() => {
                this.innerHTML = originalText;
                this.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
            }, 2000);
            
            console.log(`Added ${quantity}x ${productName} to cart`);
        });
    }
    
    if (buyNowBtn) {
        buyNowBtn.addEventListener('click', function() {
            // First add to cart
            if (addToCartBtn) {
                addToCartBtn.click();
            }
            
            // Then open cart
            setTimeout(() => {
                if (typeof window.toggleCart === 'function') {
                    window.toggleCart();
                }
                
                // And proceed to checkout
                setTimeout(() => {
                    if (typeof window.proceedToCheckout === 'function') {
                        window.proceedToCheckout();
                    }
                }, 500);
            }, 100);
            
            console.log('Buy now clicked');
        });
    }
    
    if (wishlistBtn) {
        let isWishlisted = false;
        
        wishlistBtn.addEventListener('click', function() {
            isWishlisted = !isWishlisted;
            
            if (isWishlisted) {
                this.innerHTML = '<i class="fas fa-heart"></i>';
                this.style.borderColor = '#ef4444';
                this.style.color = '#ef4444';
                this.style.background = 'rgba(239, 68, 68, 0.1)';
                
                // Show notification
                showNotification('Đã thêm vào danh sách yêu thích!', 'success');
            } else {
                this.innerHTML = '<i class="far fa-heart"></i>';
                this.style.borderColor = '#e5e7eb';
                this.style.color = '#666';
                this.style.background = 'rgba(255, 255, 255, 0.9)';
                
                showNotification('Đã xóa khỏi danh sách yêu thích!', 'info');
            }
            
            console.log('Wishlist toggled:', isWishlisted);
        });
    }
}

function initializeRelatedProducts() {
    // The new slider initialization is now handled by initRelatedProductsSlider
    // This function is kept for compatibility
    console.log('Related products will be initialized by the new slider system');
}

function setupEventListeners() {
    // Close cart when clicking overlay
    document.addEventListener('click', function(e) {
        if (e.target.id === 'cartOverlay') {
            if (typeof window.toggleCart === 'function') {
                window.toggleCart();
            }
        }
    });
    
    // Close modals when clicking overlay
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-overlay')) {
            if (typeof window.closeCheckoutModal === 'function') {
                window.closeCheckoutModal();
            }
        }
    });
    
    // Smooth scroll for anchor links (exclude admin dropdown)
    document.querySelectorAll('a[href^="#"]:not(.dropdown-toggle)').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href && href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
    
    // Handle breadcrumb clicks
    const breadcrumbLinks = document.querySelectorAll('.breadcrumb a');
    breadcrumbLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Add loading animation
            this.style.opacity = '0.7';
            setTimeout(() => {
                this.style.opacity = '1';
            }, 300);
        });
    });
}

// Utility function for notifications
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? 'linear-gradient(135deg, #10b981, #059669)' : 'linear-gradient(135deg, #3b82f6, #1d4ed8)'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        z-index: 10000;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        max-width: 350px;
        font-weight: 500;
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove
    setTimeout(() => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => {
            if (notification.parentNode) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Format price function
function formatPrice(price) {
    return new Intl.NumberFormat('vi-VN').format(price) + ' VNĐ';
}

// Export functions for global use
window.productDetailFunctions = {
    showNotification,
    formatPrice
};

// =====================================
// SIMPLE RELATED PRODUCTS SLIDER
// =====================================

let currentIndex = 0;
let itemsPerPage = 3;
let totalItems = 0;

function initRelatedProductsSlider() {
    const track = document.getElementById('productsTrack');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    if (!track || !prevBtn || !nextBtn) {
        console.log('Slider elements not found:', { track: !!track, prevBtn: !!prevBtn, nextBtn: !!nextBtn });
        return;
    }
    
    const items = track.querySelectorAll('.product-item');
    totalItems = items.length;
    
    console.log('Initializing slider with', totalItems, 'items');
    
    // Calculate items per page based on screen size
    updateItemsPerPage();
    console.log('Items per page:', itemsPerPage);
    
    // Add event listeners
    prevBtn.addEventListener('click', slidePrev);
    nextBtn.addEventListener('click', slideNext);
    
    // Add click handlers to product items
    items.forEach(item => {
        item.addEventListener('click', function() {
            const productId = this.dataset.productId;
            if (productId) {
                window.location.href = `/product/${productId}`;
            }
        });
    });
    
    // Add touch/swipe support for mobile
    let touchStartX = 0;
    let touchEndX = 0;
    let isDragging = false;
    
    track.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
        isDragging = false;
    }, { passive: true });
    
    track.addEventListener('touchmove', function(e) {
        isDragging = true;
    }, { passive: true });
    
    track.addEventListener('touchend', function(e) {
        if (!isDragging) return;
        
        touchEndX = e.changedTouches[0].screenX;
        const swipeDistance = touchStartX - touchEndX;
        const minSwipeDistance = 50;
        
        if (Math.abs(swipeDistance) > minSwipeDistance) {
            if (swipeDistance > 0) {
                // Swipe left - next
                slideNext();
            } else {
                // Swipe right - previous
                slidePrev();
            }
        }
    }, { passive: true });
    
    // Prevent scrolling when swiping on the slider
    track.addEventListener('touchmove', function(e) {
        e.preventDefault();
    }, { passive: false });
    
    // Update initial state
    updateSlider();
    
    // Handle window resize
    window.addEventListener('resize', handleSliderResize);
}

function updateItemsPerPage() {
    const width = window.innerWidth;
    if (width >= 1200) {
        itemsPerPage = 3;
    } else if (width >= 768) {
        itemsPerPage = 2;
    } else {
        itemsPerPage = 1; // Show only 1 product on mobile
    }
}

function slidePrev() {
    console.log('slidePrev - currentIndex:', currentIndex);
    
    if (currentIndex > 0) {
        currentIndex--;
        updateSlider();
        console.log('Moved to index:', currentIndex);
    } else {
        console.log('Already at first item');
    }
}

function slideNext() {
    const maxIndex = Math.max(0, totalItems - itemsPerPage);
    console.log('slideNext - currentIndex:', currentIndex, 'maxIndex:', maxIndex, 'totalItems:', totalItems, 'itemsPerPage:', itemsPerPage);
    
    if (currentIndex < maxIndex) {
        currentIndex++;
        updateSlider();
        console.log('Moved to index:', currentIndex);
    } else {
        console.log('Already at last item');
    }
}

function updateSlider() {
    const track = document.getElementById('productsTrack');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    if (!track) return;
    
    // Calculate translate value based on viewport width
    const width = window.innerWidth;
    let translateX = 0;
    
    if (width < 768) {
        // Mobile: move by the actual product item width including margins
        const productItem = track.querySelector('.product-item');
        if (productItem) {
            const itemStyles = window.getComputedStyle(productItem);
            const itemWidth = productItem.offsetWidth;
            const marginLeft = parseFloat(itemStyles.marginLeft) || 0;
            const marginRight = parseFloat(itemStyles.marginRight) || 0;
            
            // For smaller products, calculate the center position
            const containerWidth = track.parentElement.offsetWidth - 70; // Account for nav buttons
            const totalItemWidth = itemWidth + marginLeft + marginRight;
            const centerOffset = (containerWidth - itemWidth) / 2;
            
            translateX = -currentIndex * totalItemWidth + centerOffset;
            
            console.log('Mobile slider calculation:', {
                currentIndex,
                itemWidth,
                marginLeft,
                marginRight,
                totalItemWidth,
                containerWidth,
                centerOffset,
                translateX
            });
        }
    } else {
        // Desktop/Tablet: use item width + gap
        const itemWidth = track.querySelector('.product-item')?.offsetWidth || 280;
        const gap = parseFloat(getComputedStyle(track).gap) || 24;
        translateX = -currentIndex * (itemWidth + gap);
        
        console.log('Desktop slider calculation:', {
            currentIndex,
            itemWidth,
            gap,
            translateX
        });
    }
    
    track.style.transform = `translateX(${translateX}px)`;
    console.log('Applied transform:', `translateX(${translateX}px)`);
    
    // Update button states
    const maxIndex = Math.max(0, totalItems - itemsPerPage);
    prevBtn.disabled = currentIndex <= 0;
    nextBtn.disabled = currentIndex >= maxIndex;
    
    // Add visual feedback for disabled buttons
    if (prevBtn.disabled) {
        prevBtn.style.opacity = '0.4';
        prevBtn.style.cursor = 'not-allowed';
    } else {
        prevBtn.style.opacity = '1';
        prevBtn.style.cursor = 'pointer';
    }
    
    if (nextBtn.disabled) {
        nextBtn.style.opacity = '0.4';
        nextBtn.style.cursor = 'not-allowed';
    } else {
        nextBtn.style.opacity = '1';
        nextBtn.style.cursor = 'pointer';
    }
}

function handleSliderResize() {
    updateItemsPerPage();
    
    // Reset to valid position if needed
    const maxIndex = Math.max(0, totalItems - itemsPerPage);
    if (currentIndex > maxIndex) {
        currentIndex = maxIndex;
    }
    
    // Recalculate and update slider position with a small delay
    setTimeout(() => {
        updateSlider();
    }, 150); // Slightly longer delay to ensure DOM has updated
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(initRelatedProductsSlider, 100);
    
    // Initialize admin dropdown with delay
    setTimeout(initializeProductDetailAdminDropdown, 300);
});

// Admin Dropdown Functionality for Product Detail
function initializeProductDetailAdminDropdown() {
    console.log('Initializing product detail admin dropdown...');
    
    // Wait for DOM to be fully ready
    const adminDropdown = document.querySelector('.admin-dropdown');
    if (!adminDropdown) {
        console.log('Admin dropdown not found, retrying in 200ms...');
        setTimeout(initializeProductDetailAdminDropdown, 200);
        return;
    }

    const dropdownToggle = adminDropdown.querySelector('.dropdown-toggle');
    const dropdownMenu = adminDropdown.querySelector('.dropdown-menu');

    if (!dropdownToggle || !dropdownMenu) {
        console.log('Dropdown elements not found:', {
            toggle: !!dropdownToggle,
            menu: !!dropdownMenu,
            dropdownHTML: adminDropdown.innerHTML
        });
        return;
    }

    console.log('Admin dropdown elements found, setting up events...');

    // Remove existing event listeners to prevent duplicates
    const newToggle = dropdownToggle.cloneNode(true);
    dropdownToggle.parentNode.replaceChild(newToggle, dropdownToggle);

    // Toggle dropdown on click
    newToggle.addEventListener('click', function(e) {
        console.log('Admin dropdown toggle clicked');
        e.preventDefault();
        e.stopPropagation();
        
        // Close other dropdowns
        document.querySelectorAll('.admin-dropdown.active').forEach(dropdown => {
            if (dropdown !== adminDropdown) {
                dropdown.classList.remove('active');
            }
        });
        
        // Toggle current dropdown
        const isActive = adminDropdown.classList.contains('active');
        if (isActive) {
            adminDropdown.classList.remove('active');
            console.log('Admin dropdown closed');
        } else {
            adminDropdown.classList.add('active');
            console.log('Admin dropdown opened');
        }
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!adminDropdown.contains(e.target)) {
            if (adminDropdown.classList.contains('active')) {
                console.log('Closing admin dropdown - clicked outside');
                adminDropdown.classList.remove('active');
            }
        }
    });

    // Close dropdown on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && adminDropdown.classList.contains('active')) {
            console.log('Closing admin dropdown - escape key');
            adminDropdown.classList.remove('active');
        }
    });

    // Handle dropdown menu clicks
    dropdownMenu.addEventListener('click', function(e) {
        const link = e.target.closest('a');
        if (link && link.getAttribute('href') !== '#') {
            console.log('Admin dropdown menu item clicked:', link.getAttribute('href'));
            // Allow normal navigation for actual links
            adminDropdown.classList.remove('active');
        }
    });
    
    console.log('Product detail admin dropdown initialized successfully');
}

console.log('Product detail script loaded successfully');
