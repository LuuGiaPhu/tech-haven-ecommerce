/**
 * Import function triggers from their respective submodules:
 *
 * const {onCall} = require("firebase-functions/v2/https");
 * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

const {setGlobalOptions} = require("firebase-functions");
const {onRequest} = require("firebase-functions/https");
const express = require("express");
const path = require("path");

setGlobalOptions({maxInstances: 10});

// Create Express app
const app = express();

// Set view engine and static files
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));

// Sample products data
const products = [
  {
    id: 1,
    name: "ASUS ROG Strix G15 Gaming",
    price: 35990000,
    oldPrice: 39990000,
    rating: 5,
    reviewCount: 45,
    availability: "Còn hàng",
    category: "Laptop",
    brand: "ASUS",
    sku: "G513QM-HN015T",
    description: "Laptop gaming cao cấp với RTX 3060 và AMD Ryzen 9",
    images: ["/images/laptop.jpg"],
    specifications: {
      "CPU": "AMD Ryzen 9 5900HX",
      "GPU": "RTX 3060 6GB",
      "RAM": "16GB DDR4",
      "Storage": "512GB SSD NVMe",
      "Display": "15.6'' FHD 144Hz",
    },
    features: ["Ray Tracing", "DLSS", "144Hz Display", "RGB Backlight"],
  },
];

// Routes
app.get("/", (req, res) => {
  res.render("index");
});

app.get("/shop", (req, res) => {
  res.render("shop");
});

app.get("/product/:id", (req, res) => {
  const productId = parseInt(req.params.id);
  const product = products.find((p) => p.id === productId) || products[0];
  res.render("product_detail", {product});
});

app.get("/category", (req, res) => {
  res.render("category");
});

app.get("/admin/input", (req, res) => {
  res.render("input");
});

app.get("/admin/edit", (req, res) => {
  res.render("edit");
});

// Export the Express app as Firebase Function
exports.app = onRequest(app);
