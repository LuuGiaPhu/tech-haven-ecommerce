const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => {
    const products = [
        {
            id: 1,
            name: "RTX 4070",
            price: "$15.00",
            rating: 5,
            image: "/images/gpu1.jpg"
        },
        {
            id: 2,
            name: "RTX 4080",
            price: "$24.00",
            rating: 4,
            image: "/images/gpu2.jpg"
        },
        {
            id: 3,
            name: "MOTHERBOARD5",
            price: "$158.00",
            rating: 5,
            image: "/images/keyboard.jpg"
        },
        {
            id: 4,
            name: "Alienware",
            price: "$73.00",
            rating: 4,
            image: "/images/laptop.jpg"
        }
    ];

    res.render('index', { products });
});

app.get('/desktops', (req, res) => {
    res.render('category', { category: 'Desktops' });
});

app.get('/laptops', (req, res) => {
    res.render('category', { category: 'Laptops' });
});

app.get('/components', (req, res) => {
    res.render('category', { category: 'Components' });
});

app.get('/shop', (req, res) => {
    res.render('shop');
});

app.get('/product/:id', (req, res) => {
    const productId = req.params.id;
    // Sample product data - in real app this would come from database
    const product = {
        id: productId,
        name: "ASUS ROG Strix G15 Gaming Laptop",
        price: 35990000,
        oldPrice: 39990000,
        category: "laptop",
        brand: "asus",
        rating: 5,
        reviewCount: 152,
        availability: "Còn hàng",
        sku: "ASU-ROG-G15-001",
        description: "Laptop gaming ASUS ROG Strix G15 với hiệu năng mạnh mẽ, thiết kế đẳng cấp và công nghệ tản nhiệt tiên tiến. Phù hợp cho game thủ và những người làm việc chuyên nghiệp.",
        specifications: {
            cpu: "AMD Ryzen 7 6800H (8 nhân, 16 luồng, 3.2GHz up to 4.7GHz)",
            gpu: "NVIDIA GeForce RTX 3060 6GB GDDR6",
            ram: "16GB DDR5-4800MHz (2x8GB, còn trống 2 slot)",
            storage: "512GB PCIe 4.0 NVMe SSD (còn trống 1 slot M.2)",
            display: "15.6\" FHD (1920x1080) IPS, 144Hz, 100% sRGB",
            ports: "3x USB-A 3.2, 1x USB-C 3.2, 1x HDMI 2.0b, 1x RJ45",
            audio: "2x 4W speakers với Smart Amp technology",
            keyboard: "RGB Backlit với Anti-Ghosting",
            battery: "90Wh Li-ion, sạc nhanh 150W",
            os: "Windows 11 Home bản quyền",
            dimensions: "354.9 x 259.9 x 22.69~27.2mm",
            weight: "2.3kg"
        },
        features: [
            "Tản nhiệt Intelligent Cooling với 2 quạt Arc Flow",
            "ROG Keystone II để tùy chỉnh profile game",
            "Armoury Crate để điều khiển RGB và hiệu năng",
            "MUX Switch cho hiệu năng gaming tối ưu",
            "Wi-Fi 6E (802.11ax) tốc độ cao",
            "DTS:X Ultra surround sound"
        ],
        images: [
            "/images/laptop.jpg",
            "/images/laptop.jpg",
            "/images/laptop.jpg"
        ],
        relatedProducts: [
            { id: 2, name: "MSI Katana 17 B13V", price: 28990000, image: "/images/laptop.jpg" },
            { id: 3, name: "Acer Predator Helios 300", price: 32990000, image: "/images/laptop.jpg" },
            { id: 4, name: "HP Omen 16-k0000", price: 26990000, image: "/images/laptop.jpg" }
        ]
    };
    
    res.render('product_detail', { product });
});

app.get('/peripherals', (req, res) => {
    res.render('category', { category: 'Peripherals' });
});

app.get('/build-pc', (req, res) => {
    res.render('category', { category: 'Build PC' });
});

app.get('/admin/input', (req, res) => {
    res.render('input');
});

app.get('/admin/edit', (req, res) => {
    res.render('edit');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
