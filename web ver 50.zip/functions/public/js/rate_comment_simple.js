/**
 * SIMPLE COMMENT DETAIL POPUP SYSTEM - COMPLETE REWRITE
 * Shows ONLY clicked comment details (no parent, no children)
 * User requirement: "hiển thị đúng chi tiết comment đó và không hiển thị parent hay child"
 */

console.log('🚀 Loading Simple Comment Detail Popup System...');

// Simple popup state
let simplePopupInitialized = false;
let commentDetailOverlay = null;

// Simple CSS injection - clean and minimal
function injectSimplePopupCSS() {
    if (document.getElementById('simplePopupCSS')) {
        console.log('✅ Simple popup CSS already injected');
        return;
    }
    
    const style = document.createElement('style');
    style.id = 'simplePopupCSS';
    style.textContent = `
        /* Simple Comment Detail Popup */
        #commentDetailOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        #commentDetailOverlay.active {
            display: flex;
            opacity: 1;
            align-items: center;
            justify-content: center;
        }
        
        .comment-detail-popup {
            background: white;
            border-radius: 12px;
            padding: 24px;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }
        
        #commentDetailOverlay.active .comment-detail-popup {
            transform: scale(1);
        }
        
        .comment-detail-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
        }
        
        .comment-detail-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        
        .comment-detail-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #666;
            padding: 5px;
            border-radius: 50%;
            transition: background-color 0.2s;
        }
        
        .comment-detail-close:hover {
            background-color: #f5f5f5;
        }
        
        .popup-comment-item {
            display: flex;
            gap: 12px;
            padding: 16px 0;
        }
        
        .popup-comment-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #667eea;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            flex-shrink: 0;
        }
        
        .popup-comment-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .popup-comment-content {
            flex: 1;
        }
        
        .popup-comment-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 8px;
        }
        
        .popup-comment-user h5 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            color: #333;
        }
        
        .popup-comment-user p {
            margin: 2px 0 0 0;
            font-size: 12px;
            color: #666;
        }
        
        .popup-comment-meta {
            font-size: 12px;
            color: #999;
            display: flex;
            gap: 12px;
        }
        
        .popup-comment-text {
            color: #444;
            line-height: 1.5;
            font-size: 14px;
        }
        
        /* Hide parent and child sections completely */
        #parentCommentSection,
        #childCommentsSection {
            display: none !important;
        }
    `;
    
    document.head.appendChild(style);
    console.log('✅ Simple popup CSS injected');
}

// Simple initialization
function initializeSimpleCommentDetailPopup() {
    if (simplePopupInitialized) {
        console.log('✅ Simple popup already initialized');
        return;
    }
    
    console.log('🔧 Initializing simple comment detail popup...');
    
    // Inject CSS
    injectSimplePopupCSS();
    
    // Get overlay element
    commentDetailOverlay = document.getElementById('commentDetailOverlay');
    if (!commentDetailOverlay) {
        console.error('❌ Comment detail overlay not found');
        return;
    }
    
    // Setup simple click handlers
    setupSimpleClickHandlers();
    
    // Setup close handler
    const closeButton = commentDetailOverlay.querySelector('.comment-detail-close');
    if (closeButton) {
        closeButton.onclick = closeSimpleCommentPopup;
    }
    
    // Setup overlay click to close
    commentDetailOverlay.onclick = (e) => {
        if (e.target === commentDetailOverlay) {
            closeSimpleCommentPopup();
        }
    };
    
    simplePopupInitialized = true;
    console.log('✅ Simple comment detail popup initialized');
}

// Setup simple click handlers for all comments
function setupSimpleClickHandlers() {
    console.log('🖱️ Setting up simple click handlers...');
    
    const allComments = document.querySelectorAll('[data-comment-id]');
    console.log(`📊 Found ${allComments.length} comments to setup`);
    
    allComments.forEach((comment, index) => {
        // Remove any existing handlers
        const newComment = comment.cloneNode(true);
        comment.replaceWith(newComment);
        
        // Add simple click handler
        newComment.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log(`🖱️ Simple click on comment ${index + 1}:`, newComment.dataset.commentId);
            showSimpleCommentDetail(newComment);
        });
        
        console.log(`✅ Simple handler added to comment ${index + 1}`);
    });
    
    console.log('✅ All simple click handlers setup complete');
}

// Show simple comment detail - ONLY clicked comment
function showSimpleCommentDetail(commentElement) {
    if (!commentElement || !commentElement.dataset.commentId) {
        console.error('❌ Invalid comment element');
        return;
    }
    
    const commentId = commentElement.dataset.commentId;
    console.log('🔍 SIMPLE - Showing detail for comment:', commentId);
    
    // Find comment in commentsData array
    if (!window.commentsData || !Array.isArray(window.commentsData)) {
        console.error('❌ No comments data available');
        return;
    }
    
    // Find the specific comment
    let commentData = null;
    
    // Search in main comments
    for (const comment of window.commentsData) {
        if (comment.id === commentId) {
            commentData = comment;
            break;
        }
        
        // Search in replies if not found in main
        if (comment.replies && Array.isArray(comment.replies)) {
            for (const reply of comment.replies) {
                if (reply.id === commentId) {
                    commentData = reply;
                    break;
                }
            }
        }
        
        if (commentData) break;
    }
    
    if (!commentData) {
        console.error('❌ Comment data not found for ID:', commentId);
        return;
    }
    
    console.log('✅ SIMPLE - Found comment data:', {
        id: commentData.id,
        username: commentData.userDisplayName || commentData.username,
        content: commentData.content || commentData.text
    });
    
    // Populate and show popup
    populateSimpleCommentPopup(commentData);
    
    // Show overlay
    commentDetailOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    console.log('✅ SIMPLE - Popup displayed successfully');
}

// Populate simple comment popup with ONLY clicked comment data
function populateSimpleCommentPopup(commentData) {
    console.log('📝 SIMPLE - Populating popup with comment data');
    
    // Get elements
    const mainUsername = document.getElementById('mainUsername');
    const mainRole = document.getElementById('mainRole');
    const mainText = document.getElementById('mainText');
    const mainTime = document.getElementById('mainTime');
    const mainRating = document.getElementById('mainRating');
    const mainAvatar = document.getElementById('mainAvatar');
    
    if (!mainUsername || !mainText) {
        console.error('❌ Required popup elements not found');
        return;
    }
    
    // Clear and populate with clicked comment data only
    const username = commentData.userDisplayName || commentData.username || 'Người dùng';
    const text = commentData.content || commentData.text || '';
    const timestamp = commentData.createdAt ? getTimeAgo(commentData.createdAt) : '';
    const avatar = commentData.userAvatar || commentData.avatar;
    const rating = commentData.rating || 0;
    
    mainUsername.textContent = username;
    if (mainRole) mainRole.textContent = 'Khách hàng';
    mainText.textContent = text;
    if (mainTime) mainTime.textContent = timestamp;
    if (mainRating) mainRating.textContent = rating ? `${rating}/5` : '0/5';
    
    // Set avatar
    if (mainAvatar) {
        if (avatar) {
            mainAvatar.innerHTML = `<img src="${avatar}" alt="${username}">`;
        } else {
            mainAvatar.innerHTML = username.charAt(0).toUpperCase();
        }
    }
    
    // Force hide parent and child sections
    const parentSection = document.getElementById('parentCommentSection');
    const childSection = document.getElementById('childCommentsSection');
    
    if (parentSection) {
        parentSection.style.display = 'none';
        parentSection.style.visibility = 'hidden';
    }
    
    if (childSection) {
        childSection.style.display = 'none';
        childSection.style.visibility = 'hidden';
    }
    
    console.log('✅ SIMPLE - Popup populated with clicked comment only:', {
        displayedUsername: mainUsername.textContent,
        displayedText: mainText.textContent,
        displayedTime: mainTime?.textContent
    });
}

// Close simple comment popup
function closeSimpleCommentPopup() {
    console.log('🚪 SIMPLE - Closing popup...');
    
    if (commentDetailOverlay) {
        commentDetailOverlay.classList.remove('active');
        document.body.style.overflow = '';
        
        // Clear content after animation
        setTimeout(() => {
            const mainUsername = document.getElementById('mainUsername');
            const mainText = document.getElementById('mainText');
            if (mainUsername) mainUsername.textContent = '';
            if (mainText) mainText.textContent = '';
        }, 300);
    }
    
    console.log('✅ SIMPLE - Popup closed');
}

// Utility function for time formatting
function getTimeAgo(date) {
    if (!date) return 'Vừa xong';
    
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (diffInSeconds < 60) {
        return 'Vừa xong';
    } else if (diffInSeconds < 3600) {
        const minutes = Math.floor(diffInSeconds / 60);
        return `${minutes} phút trước`;
    } else if (diffInSeconds < 86400) {
        const hours = Math.floor(diffInSeconds / 3600);
        return `${hours} giờ trước`;
    } else if (diffInSeconds < 604800) {
        const days = Math.floor(diffInSeconds / 86400);
        return `${days} ngày trước`;
    } else {
        return date.toLocaleDateString('vi-VN');
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(() => {
            initializeSimpleCommentDetailPopup();
        }, 1000);
    });
} else {
    setTimeout(() => {
        initializeSimpleCommentDetailPopup();
    }, 1000);
}

// Export functions
window.showSimpleCommentDetail = showSimpleCommentDetail;
window.closeSimpleCommentPopup = closeSimpleCommentPopup;
window.initializeSimpleCommentDetailPopup = initializeSimpleCommentDetailPopup;

console.log('✅ Simple Comment Detail Popup System loaded successfully');
console.log('💡 New behavior: Shows ONLY clicked comment details (no parent, no children)');

// Simple test function
window.testSimpleCommentPopup = function(commentId) {
    console.log('🧪 SIMPLE TEST - Testing comment:', commentId);
    
    const element = document.querySelector(`[data-comment-id="${commentId}"]`);
    if (!element) {
        console.error('❌ Comment not found:', commentId);
        return;
    }
    
    console.log('✅ Found comment, opening simple popup');
    showSimpleCommentDetail(element);
};