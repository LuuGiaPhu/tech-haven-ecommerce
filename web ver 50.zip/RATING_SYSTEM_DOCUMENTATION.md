# Rating System Documentation

## Firebase Firestore Collection: `ratings`

### Collection Structure

The `ratings` collection stores all product ratings with the following schema:

### Document Fields

| Field Name | Type | Required | Description |
|-----------|------|----------|-------------|
| `productId` | string | ✅ | Reference to the product being rated |
| `userId` | string | ✅ | Firebase Auth UID of the user who created the rating |
| `userDisplayName` | string | ✅ | Display name of the user (fallback to email) |
| `userAvatar` | string | ❌ | URL to user's profile photo (from users.photo field) |
| `stars` | number | ✅ | Rating value (1-5 stars) |
| `content` | string | ❌ | Optional text content of the rating |
| `createdAt` | timestamp | ✅ | Server timestamp when rating was created |
| `updatedAt` | timestamp | ✅ | Server timestamp when rating was last updated |

### Index Requirements

Create the following composite indexes in Firestore:

```javascript
// Index 1: For loading ratings by product
Collection ID: ratings
Fields indexed:
- productId (Ascending)
- createdAt (Descending)
Query scope: Collection

// Index 2: For checking user's existing rating
Collection ID: ratings
Fields indexed:
- productId (Ascending)
- userId (Ascending)
Query scope: Collection
```

### Security Rules

Add these rules to `firestore.rules`:

```javascript
// Ratings collection rules
match /ratings/{ratingId} {
  // Allow read for everyone
  allow read: if true;
  
  // Allow create for authenticated users
  allow create: if request.auth != null 
    && request.auth.uid == resource.data.userId
    && request.data.keys().hasAll(['productId', 'userId', 'userDisplayName', 'stars', 'createdAt', 'updatedAt'])
    && request.data.stars is number
    && request.data.stars >= 1
    && request.data.stars <= 5;
  
  // Allow update for rating owner only
  allow update: if request.auth != null 
    && request.auth.uid == resource.data.userId
    && request.data.keys().hasAll(['productId', 'userId', 'userDisplayName', 'stars', 'updatedAt'])
    && request.data.stars is number
    && request.data.stars >= 1
    && request.data.stars <= 5;
  
  // Allow delete for rating owner only
  allow delete: if request.auth != null 
    && request.auth.uid == resource.data.userId;
}
```

### Example Document

```json
{
  "productId": "product123",
  "userId": "user_firebase_uid",
  "userDisplayName": "John Doe",
  "userAvatar": "https://firebasestorage.googleapis.com/v0/b/project/o/users%2Fuser_id%2Fphoto.jpg",
  "stars": 5,
  "content": "Sản phẩm rất tốt, đáng tiền!",
  "createdAt": "2024-01-15T10:30:00Z",
  "updatedAt": "2024-01-15T10:30:00Z"
}
```

## Rating System Features

### ✅ Implemented Features

1. **Star Rating Input**: Interactive 1-5 star selection with hover effects
2. **Real-time Updates**: Firebase Firestore real-time listeners
3. **Cross-tab Synchronization**: WebSocket-like functionality using localStorage
4. **User Authentication Integration**: Connects with existing auth system
5. **Avatar Integration**: Uses photos from users collection
6. **Rating Statistics**: Live average rating and distribution charts
7. **Rating Management**: Users can update/delete their own ratings
8. **Rating Filtering**: Filter ratings by star count
9. **One Rating Per User**: Prevents duplicate ratings per user per product
10. **Responsive Design**: Mobile-friendly interface

### 📊 Rating Analytics

The system calculates and displays:
- Average rating (with decimal precision)
- Total number of ratings
- Rating distribution (percentage per star level)
- Star visualization with full/half/empty stars

### 🔄 Real-time Synchronization

- **Firebase Listeners**: Real-time updates when ratings change
- **Cross-tab Sync**: Updates across browser tabs using localStorage events
- **Broadcast System**: Notifies all tabs when ratings are added/updated/deleted
- **Auto-refresh**: UI updates automatically without page reload

### 🎨 UI Components

1. **Rating Summary Section**:
   - Average rating display
   - Star visualization
   - Rating count
   - Distribution bars

2. **Rating Form**:
   - Star input with hover effects
   - Text content input
   - User avatar and name
   - Submit/Update buttons

3. **Rating List**:
   - Individual rating items
   - User info and timestamps
   - Star display per rating
   - Delete option for own ratings
   - Filter dropdown

### 🚀 Integration Points

- **Authentication**: Uses `window.currentUser` and Firebase Auth
- **Product Context**: Gets `productId` from page elements or URL
- **Notification System**: Integrates with existing `showNotification()` function
- **User Photos**: Fetches from `users` collection `photo` field

### 🔧 Configuration

The rating system is automatically initialized when:
1. DOM is loaded
2. Product ID is found on the page
3. Firebase is available
4. User authentication state is determined

No manual configuration required - the system integrates seamlessly with existing codebase.