const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => {
    const products = [
        {
            id: 1,
            name: "RTX 4070",
            price: "$15.00",
            rating: 5,
            image: "/images/gpu1.jpg"
        },
        {
            id: 2,
            name: "RTX 4080",
            price: "$24.00",
            rating: 4,
            image: "/images/gpu2.jpg"
        },
        {
            id: 3,
            name: "MOTHERBOARD5",
            price: "$158.00",
            rating: 5,
            image: "/images/keyboard.jpg"
        },
        {
            id: 4,
            name: "Alienware",
            price: "$73.00",
            rating: 4,
            image: "/images/laptop.jpg"
        }
    ];

    res.render('index', { products });
});

app.get('/desktops', (req, res) => {
    res.render('category', { category: 'Desktops' });
});

app.get('/laptops', (req, res) => {
    res.render('category', { category: 'Laptops' });
});

app.get('/components', (req, res) => {
    res.render('category', { category: 'Components' });
});

app.get('/shop', (req, res) => {
    res.render('shop');
});

app.get('/peripherals', (req, res) => {
    res.render('category', { category: 'Peripherals' });
});

app.get('/build-pc', (req, res) => {
    res.render('category', { category: 'Build PC' });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
