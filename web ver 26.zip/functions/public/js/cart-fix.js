// Cart fix for handling invalid items and syncing between localStorage and Firebase

// Clean up invalid cart items
function cleanupInvalidCartItems() {
    console.log('🧹 Starting cart cleanup...');
    
    // Get current cart from global variables or localStorage
    let currentCartItems = window.cartItems || JSON.parse(localStorage.getItem('techHavenCart') || '[]');
    const beforeCount = currentCartItems.length;
    
    // Filter out invalid items
    const validCartItems = currentCartItems.filter(item => {
        const isValid = item && 
                      item.productName && 
                      item.productName !== 'undefined' && 
                      item.productName !== 'null' &&
                      item.productPrice && 
                      !isNaN(parseFloat(item.productPrice.toString().replace(/[^\\d.-]/g, '')));
        
        if (!isValid) {
            console.warn('🗑️ Removing invalid cart item:', item);
        }
        return isValid;
    });
    
    // Update global cart state
    window.cartItems = validCartItems;
    window.cartCount = validCartItems.reduce((total, item) => total + (item.quantity || 1), 0);
    
    // Update localStorage
    localStorage.setItem('techHavenCart', JSON.stringify(validCartItems));
    localStorage.setItem('techHavenCartCount', window.cartCount.toString());
    
    const afterCount = validCartItems.length;
    console.log(`🧹 Cart cleanup completed: ${beforeCount} → ${afterCount} items (removed ${beforeCount - afterCount} invalid items)`);
    
    // Update UI
    if (typeof updateCartUI === 'function') {
        updateCartUI();
    }
    
    return validCartItems;
}

// Enhanced cart data validation for UI rendering
function validateCartItemForUI(item) {
    if (!item) return null;
    
    // Validate and clean item data
    const productName = item.productName || item.name || 'Sản phẩm không xác định';
    const productId = item.productId || item.id || 'unknown';
    const quantity = parseInt(item.quantity) || 1;
    
    // Validate price - handle various price formats
    let numericPrice = 0;
    if (item.productPrice) {
        const priceStr = item.productPrice.toString().replace(/[^\\d.-]/g, '');
        numericPrice = parseFloat(priceStr) || 0;
    } else if (item.price) {
        const priceStr = item.price.toString().replace(/[^\\d.-]/g, '');
        numericPrice = parseFloat(priceStr) || 0;
    } else if (item.numericPrice) {
        numericPrice = parseFloat(item.numericPrice) || 0;
    }
    
    // Skip items with invalid data
    if (productName === 'undefined' || productName === 'null' || isNaN(numericPrice)) {
        return null;
    }
    
    return {
        id: productId,
        productId: productId,
        productName: productName,
        productPrice: formatPrice(numericPrice),
        numericPrice: numericPrice,
        quantity: quantity,
        image: item.image || item.productImage || 'fas fa-cube',
        imageColor: item.imageColor || '#667eea'
    };
}

// Enhanced updateCartUI with better validation
function enhancedUpdateCartUI() {
    const cartItemsContainer = document.getElementById('cartItems');
    const cartBadge = document.getElementById('cartBadge');
    const cartTotal = document.getElementById('cartTotal');
    
    if (!cartItemsContainer) {
        console.log('🔍 Cart items container not found, skipping UI update');
        return;
    }
    
    // Get current cart items
    let currentCartItems = window.cartItems || JSON.parse(localStorage.getItem('techHavenCart') || '[]');
    
    // Validate and clean items
    const validatedItems = [];
    currentCartItems.forEach(item => {
        const validatedItem = validateCartItemForUI(item);
        if (validatedItem) {
            validatedItems.push(validatedItem);
        }
    });
    
    // Update global state with cleaned items
    window.cartItems = validatedItems;
    window.cartCount = validatedItems.reduce((total, item) => total + (item.quantity || 1), 0);
    
    console.log('🎨 Updating cart UI with', validatedItems.length, 'valid items, total count:', window.cartCount);
    
    // Update badge with correct count
    if (cartBadge) {
        cartBadge.textContent = window.cartCount;
        cartBadge.style.display = window.cartCount > 0 ? 'flex' : 'none';
        console.log('📊 Cart badge updated:', window.cartCount);
    }
    
    // Update cart items display
    if (validatedItems.length === 0) {
        cartItemsContainer.innerHTML = '<div class="empty-cart">Giỏ hàng trống</div>';
    } else {
        cartItemsContainer.innerHTML = validatedItems.map(item => {
            const imageHtml = item.image.startsWith('fas ') 
                ? `<i class="${item.image}" style="color: ${item.imageColor}; font-size: 2rem;"></i>`
                : `<img src="${item.image}" alt="${item.productName}" onerror="this.outerHTML='<i class=\\"fas fa-cube\\" style=\\"color: ${item.imageColor}; font-size: 2rem;\\"></i>'">`;
            
            return `
                <div class="cart-item" data-product-id="${item.productId}" data-cart-id="${item.id}">
                    <div class="cart-item-image">
                        ${imageHtml}
                    </div>
                    <div class="cart-item-details">
                        <div class="cart-item-name">${item.productName}</div>
                        <div class="cart-item-price">${item.productPrice}</div>
                        <div class="cart-item-controls">
                            <button class="quantity-btn decrease-qty" data-cart-id="${item.id}" data-current-quantity="${item.quantity}">
                                <i class="fas fa-minus"></i>
                            </button>
                            <span class="cart-item-quantity">${item.quantity}</span>
                            <button class="quantity-btn increase-qty" data-cart-id="${item.id}" data-current-quantity="${item.quantity}">
                                <i class="fas fa-plus"></i>
                            </button>
                            <button class="remove-item" data-cart-id="${item.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }
    
    // Update total
    if (cartTotal) {
        const total = validatedItems.reduce((sum, item) => sum + (item.numericPrice * item.quantity), 0);
        cartTotal.innerHTML = formatPrice(total) + ' ₫';
    }
    
    // Save cleaned cart back to localStorage
    localStorage.setItem('techHavenCart', JSON.stringify(validatedItems));
    localStorage.setItem('techHavenCartCount', window.cartCount.toString());
    
    console.log('✅ Enhanced cart UI updated successfully with', validatedItems.length, 'valid items');
}

// Format price function (if not already defined)
function formatPrice(price) {
    if (typeof price === 'string') {
        const numericPrice = parseFloat(price.replace(/[^\\d.-]/g, ''));
        return isNaN(numericPrice) ? '0' : numericPrice.toLocaleString('vi-VN');
    }
    return (price || 0).toLocaleString('vi-VN');
}

// Initialize cart fix when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('🛒 Cart fix loaded');
    
    // Clean up invalid items immediately
    setTimeout(() => {
        cleanupInvalidCartItems();
    }, 500);
    
    // Override updateCartUI if it exists
    if (typeof window.updateCartUI === 'function') {
        window.originalUpdateCartUI = window.updateCartUI;
        window.updateCartUI = enhancedUpdateCartUI;
        console.log('🔄 Overrode updateCartUI with enhanced version');
    } else {
        window.updateCartUI = enhancedUpdateCartUI;
        console.log('✅ Set enhanced updateCartUI as primary function');
    }
    
    // Add cleanup function to global scope
    window.cleanupInvalidCartItems = cleanupInvalidCartItems;
    
    // Listen for storage changes to sync across tabs
    window.addEventListener('storage', function(e) {
        if (e.key === 'techHavenCart' || e.key === 'techHavenCartCount') {
            console.log('🔄 Cart storage changed, updating UI');
            enhancedUpdateCartUI();
        }
    });
});

// Export functions for use in other scripts
window.cartFix = {
    cleanupInvalidCartItems,
    validateCartItemForUI,
    enhancedUpdateCartUI,
    formatPrice
};