// =====================================
// SHOPPING CART GLOBAL STATE
// =====================================
let cartItems = JSON.parse(localStorage.getItem('techHavenCart')) || [];
let cartCount = parseInt(localStorage.getItem('techHavenCartCount')) || 0;

// =====================================
// EARLY CART FUNCTION DEFINITIONS 
// (to prevent overwriting by other scripts)
// =====================================

// Define addToCart function immediately to prevent overwriting
function defineAddToCartFunction() {
    // Get authentication token for API calls
    async function getAuthToken() {
        if (window.currentUser) {
            // For Firebase Auth users
            if (window.currentUser.provider === 'firebase' && window.firebase && window.firebase.auth && window.firebase.auth().currentUser) {
                try {
                    return await window.firebase.auth().currentUser.getIdToken();
                } catch (error) {
                    console.warn('⚠️ Could not get Firebase ID token:', error);
                }
            }
            
            // For manual users, create a simple token with user info
            if (window.currentUser.provider === 'manual' || !window.currentUser.provider) {
                return btoa(JSON.stringify({
                    uid: window.currentUser.uid,
                    email: window.currentUser.email,
                    provider: 'manual',
                    timestamp: Date.now()
                }));
            }
        }
        
        return null;
    }

    // Add to cart function with duplicate prevention
    window.addToCart = async function(productName, productPrice, productId = null, productImage = null) {
        // Prevent duplicate calls
        if (window.addToCartInProgress) {
            console.log('⚠️ addToCart already in progress, skipping duplicate call');
            return;
        }
        
        window.addToCartInProgress = true;
        console.log('🛒 Starting addToCart process (early definition)');
        
        try {
            // Validate input data
            if (!productName || productName === 'undefined' || !productPrice) {
                console.error('❌ Invalid product data:', { productName, productPrice, productId });
                showCartNotification('Lỗi: Dữ liệu sản phẩm không hợp lệ');
                return;
            }
            
            // Clean price string to get numeric value
            const cleanPrice = productPrice.replace(/[^\d]/g, '');
            const numericPrice = parseInt(cleanPrice);
            
            if (isNaN(numericPrice) || numericPrice <= 0) {
                console.error('❌ Invalid price:', productPrice);
                showCartNotification('Lỗi: Giá sản phẩm không hợp lệ');
                return;
            }
            
            // Use product name as ID if no productId provided (for index page)
            const itemId = productId ? String(productId) : productName;
            
            console.log('Adding to cart - Product ID:', itemId, 'Name:', productName);
        
            // If user is logged in, work directly with database
            if (window.currentUser) {
                try {
                    let headers = {
                        'Content-Type': 'application/json'
                    };
                    
                    let body = {
                        productId: itemId,
                        productName: productName,
                        productPrice: productPrice,
                        numericPrice: numericPrice,
                        productImage: productImage,
                        quantity: 1 // Always add 1, server will handle accumulation
                    };
                    
                    // Add Authorization header only for Firebase Auth users
                    if (window.currentUser.provider === 'firebase') {
                        const token = await getAuthToken();
                        if (token) {
                            headers['Authorization'] = `Bearer ${token}`;
                        }
                    } else {
                        // For manual users, add userId to body
                        body.userId = window.currentUser.uid;
                    }
                    
                    const response = await fetch('/api/cart', {
                        method: 'POST',
                        headers: headers,
                        body: JSON.stringify(body)
                    });
                    
                    const result = await response.json();
                    if (result.success) {
                        console.log('✅ Item added to database cart');
                        // Show success notification
                        if (typeof showCartNotification === 'function') {
                            showCartNotification(productName);
                        } else {
                            // Fallback notification
                            console.log('✅ Added to cart:', productName);
                        }
                        // Reload cart and update UI
                        if (typeof loadCartFromDatabase === 'function') {
                            console.log('🔄 Calling loadCartFromDatabase after successful add to cart...');
                            await loadCartFromDatabase(); // This will update cartCount and call updateCartUI()
                            console.log('✅ loadCartFromDatabase completed');
                        } else if (typeof updateCartUI === 'function') {
                            console.log('⚠️ loadCartFromDatabase not found, using fallback updateCartUI');
                            // Fallback if loadCartFromDatabase doesn't exist
                            cartCount++;
                            updateCartUI();
                        } else {
                            console.log('❌ Neither loadCartFromDatabase nor updateCartUI found!');
                        }
                    } else {
                        throw new Error(result.error || 'Failed to add to cart');
                    }
                } catch (error) {
                    console.error('❌ Failed to add item to database cart:', error);
                    if (typeof showNotification === 'function') {
                        showNotification('Có lỗi xảy ra khi thêm vào giỏ hàng!', 'error');
                    } else {
                        alert('Có lỗi xảy ra khi thêm vào giỏ hàng!');
                    }
                }
            } else {
                // For non-logged users, work with local storage only
                console.log('👤 Guest user detected - managing cart locally');
                
                const existingItem = cartItems.find(item => String(item.id) === String(itemId));
                
                if (existingItem) {
                    existingItem.quantity += 1;
                    if (productImage) {
                        existingItem.image = productImage;
                    }
                    console.log('🔄 Updated existing cart item:', existingItem);
                } else {
                    const newItem = {
                        id: itemId,
                        name: productName,
                        price: productPrice,
                        numericPrice: numericPrice,
                        quantity: 1,
                        image: productImage || 'fas fa-cube'
                    };
                    
                    // Validate the new item before adding
                    if (newItem.id && newItem.id !== 'undefined' && 
                        newItem.name && newItem.name !== 'undefined' && 
                        !isNaN(newItem.numericPrice) && newItem.numericPrice > 0) {
                        cartItems.push(newItem);
                        console.log('✨ Added new cart item:', newItem);
                    } else {
                        console.error('❌ Invalid item data, not adding to cart:', newItem);
                        return;
                    }
                }
                
                // Recalculate cart count correctly
                cartCount = cartItems.reduce((total, item) => total + (item.quantity || 1), 0);
                console.log('🔢 Updated cart count:', cartCount, 'from', cartItems.length, 'items');
                
                // FORCE save to localStorage immediately
                localStorage.setItem('techHavenCart', JSON.stringify(cartItems));
                localStorage.setItem('techHavenCartCount', cartCount.toString());
                console.log('💾 Saved to localStorage:', {
                    items: cartItems.length,
                    count: cartCount,
                    storage: localStorage.getItem('techHavenCart')
                });
                
                // Force update UI immediately
                if (typeof updateCartUI === 'function') {
                    updateCartUI();
                } else {
                    // Fallback: manually update cart badge if updateCartUI not available yet
                    console.log('⚠️ updateCartUI not available, updating badge manually');
                    const cartBadge = document.getElementById('cartBadge');
                    const mobileCartCount = document.getElementById('mobileCartCount');
                    if (cartBadge) {
                        cartBadge.textContent = cartCount;
                        cartBadge.style.display = cartCount > 0 ? 'flex' : 'none';
                    }
                    if (mobileCartCount) {
                        mobileCartCount.textContent = cartCount;
                    }
                }
                
                // Also call saveCartToStorage if it exists (for consistency)
                if (typeof saveCartToStorage === 'function') {
                    saveCartToStorage();
                }
                
                // Show notification
                if (typeof showCartNotification === 'function') {
                    showCartNotification(productName);
                } else {
                    console.log('✅ Added to cart:', productName);
                }
                
                // Force trigger cart badge update
                const cartBadge = document.getElementById('cartBadge');
                const mobileCartCount = document.getElementById('mobileCartCount');
                if (cartBadge) {
                    cartBadge.textContent = cartCount;
                    cartBadge.style.display = cartCount > 0 ? 'flex' : 'none';
                    console.log('🏷️ Cart badge updated:', cartBadge.textContent, 'display:', cartBadge.style.display);
                }
                if (mobileCartCount) {
                    mobileCartCount.textContent = cartCount;
                    console.log('📱 Mobile cart count updated:', mobileCartCount.textContent);
                }
            }
        
        } finally {
            // Reset the flag to allow future calls
            window.addToCartInProgress = false;
            console.log('🏁 addToCart process completed (early definition)');
        }
    };
    
    console.log('🚀 Early addToCart function defined with duplicate prevention');
}

// Define early updateCartUI function to prevent undefined errors
function defineEarlyUpdateCartUI() {
    // Simple early version of updateCartUI for immediate availability
    window.updateCartUI = function() {
        console.log('🔄 Early updateCartUI called');
        
        // Get cart data from localStorage
        const storedCartItems = JSON.parse(localStorage.getItem('techHavenCart')) || [];
        const storedCartCount = parseInt(localStorage.getItem('techHavenCartCount')) || 0;
        
        // Update cart badge
        const cartBadge = document.getElementById('cartBadge');
        const mobileCartCount = document.getElementById('mobileCartCount');
        
        if (cartBadge) {
            cartBadge.textContent = storedCartCount;
            cartBadge.style.display = storedCartCount > 0 ? 'flex' : 'none';
            console.log('🏷️ Early cart badge updated:', storedCartCount);
        }
        
        if (mobileCartCount) {
            mobileCartCount.textContent = storedCartCount;
            console.log('📱 Early mobile cart count updated:', storedCartCount);
        }
        
        // Update cart items display if container exists
        const cartItemsContainer = document.getElementById('cartItems');
        if (cartItemsContainer) {
            if (storedCartItems.length > 0) {
                // Generate full cart item HTML to match logged-in user format
                cartItemsContainer.innerHTML = storedCartItems.map(item => {
                    const itemId = item.id || item.productId || 'unknown';
                    const itemName = item.name || item.productName || 'Product';
                    const itemPrice = item.price || '0 VNĐ';
                    const itemQuantity = item.quantity || 1;
                    const itemImage = item.image || item.productImage || '';
                    
                    // Generate image HTML
                    let imageHtml = '';
                    if (itemImage && itemImage.startsWith('http')) {
                        imageHtml = `<img src="${itemImage}" alt="${itemName}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px;">`;
                    } else if (itemImage && itemImage.startsWith('fas ')) {
                        imageHtml = `<i class="${itemImage}" style="font-size: 2rem; color: #666;"></i>`;
                    } else {
                        imageHtml = `<i class="fas fa-cube" style="font-size: 2rem; color: #666;"></i>`;
                    }
                    
                    return `
                        <div class="cart-item" data-product-id="${itemId}" data-cart-id="${itemId}">
                            <div class="cart-item-image">
                                ${imageHtml}
                            </div>
                            <div class="cart-item-details">
                                <div class="cart-item-name">${itemName}</div>
                                <div class="cart-item-price">${itemPrice}</div>
                                <div class="cart-item-controls">
                                    <button class="quantity-btn decrease-qty" data-cart-id="${itemId}" data-current-quantity="${itemQuantity}" onclick="updateGuestCartQuantity('${itemId}', ${itemQuantity - 1})">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                    <span class="cart-item-quantity">${itemQuantity}</span>
                                    <button class="quantity-btn increase-qty" data-cart-id="${itemId}" data-current-quantity="${itemQuantity}" onclick="updateGuestCartQuantity('${itemId}', ${itemQuantity + 1})">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                    <button class="remove-item" data-cart-id="${itemId}" onclick="removeGuestCartItem('${itemId}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
                console.log('📦 Early cart items updated with full UI:', storedCartItems.length);
            } else {
                cartItemsContainer.innerHTML = `
                    <div class="empty-cart">
                        <i class="fas fa-shopping-cart" style="font-size: 3rem; color: #ccc;"></i>
                        <p>Giỏ hàng của bạn đang trống</p>
                    </div>
                `;
            }
        }
        
                // Update cart total
        const cartTotalElement = document.getElementById('cartTotal');
        if (cartTotalElement) {
            if (storedCartItems.length > 0) {
                const total = storedCartItems.reduce((sum, item) => {
                    let price = 0;
                    // Handle different price formats
                    if (item.numericPrice) {
                        price = item.numericPrice;
                    } else if (item.price) {
                        // Extract numeric value from price string
                        price = parseInt(item.price.replace(/[^\d]/g, '')) || 0;
                    }
                    return sum + (price * (item.quantity || 1));
                }, 0);
                cartTotalElement.textContent = total.toLocaleString('vi-VN') + ' VNĐ';
                console.log('💰 Early cart total updated:', total, 'from items:', storedCartItems);
            } else {
                cartTotalElement.textContent = '0 VNĐ';
            }
        }
        
        // Enable/disable checkout button
        const checkoutBtn = document.getElementById('checkoutBtn');
        if (checkoutBtn) {
            checkoutBtn.disabled = storedCartItems.length === 0;
        }
    };
    
    console.log('✅ Early updateCartUI function defined');
}

// Define early guest cart management functions
function defineGuestCartFunctions() {
    // Update guest cart item quantity
    window.updateGuestCartQuantity = function(itemId, newQuantity) {
        console.log('🔄 Updating guest cart quantity:', itemId, newQuantity);
        
        if (newQuantity <= 0) {
            removeGuestCartItem(itemId);
            return;
        }
        
        // Get current cart from localStorage
        let cartItems = JSON.parse(localStorage.getItem('techHavenCart')) || [];
        
        // Find and update the item
        const itemIndex = cartItems.findIndex(item => String(item.id) === String(itemId));
        if (itemIndex !== -1) {
            cartItems[itemIndex].quantity = newQuantity;
            
            // Update localStorage
            localStorage.setItem('techHavenCart', JSON.stringify(cartItems));
            
            // Recalculate cart count
            const cartCount = cartItems.reduce((total, item) => total + (item.quantity || 1), 0);
            localStorage.setItem('techHavenCartCount', cartCount.toString());
            
            // Update UI
            if (typeof updateCartUI === 'function') {
                updateCartUI();
            }
            
            console.log('✅ Guest cart quantity updated');
        }
    };
    
    // Remove guest cart item
    window.removeGuestCartItem = function(itemId) {
        console.log('🗑️ Removing guest cart item:', itemId);
        
        // Get current cart from localStorage
        let cartItems = JSON.parse(localStorage.getItem('techHavenCart')) || [];
        
        // Remove the item
        cartItems = cartItems.filter(item => String(item.id) !== String(itemId));
        
        // Update localStorage
        localStorage.setItem('techHavenCart', JSON.stringify(cartItems));
        
        // Recalculate cart count
        const cartCount = cartItems.reduce((total, item) => total + (item.quantity || 1), 0);
        localStorage.setItem('techHavenCartCount', cartCount.toString());
        
        // Update UI
        if (typeof updateCartUI === 'function') {
            updateCartUI();
        }
        
        console.log('✅ Guest cart item removed');
    };
    
    console.log('✅ Guest cart functions defined');
}

// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
    // Mark that script.js has been loaded
    window.scriptJsLoaded = true;
    console.log('✅ Script.js loaded successfully');
    
    // Define addToCart IMMEDIATELY to prevent overwriting by other scripts
    defineAddToCartFunction();
    
    // Define early updateCartUI to prevent undefined errors
    defineEarlyUpdateCartUI();
    
    // Define guest cart management functions
    defineGuestCartFunctions();
    
    // Only run loading screen on index page
    if (!document.body.classList.contains('index-page')) {
        // Skip loading screen for non-index pages
        setupNonIndexPage();
        return;
    }
    
    // Cute Loading Screen Controller (only for index page)
    const loadingScreen = document.getElementById('loadingScreen');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const progressPercentage = document.getElementById('progressPercentage');
    
    // Debug: Check if loading elements exist
    console.log('🔍 Loading elements check:', {
        loadingScreen: !!loadingScreen,
        progressFill: !!progressFill,
        progressText: !!progressText,
        progressPercentage: !!progressPercentage
    });
    
    // If loading screen doesn't exist, skip loading animation
    if (!loadingScreen) {
        console.log('⚠️ Loading screen element not found, skipping loading animation');
        return;
    }
    
    // Định nghĩa allElements ở scope cao hơn để completeLoading có thể truy cập
    let allElements;
    
    // Thêm class loading cho body và html ngay lập tức
    document.body.classList.add('loading');
    document.documentElement.classList.add('loading');
    
    // Ẩn tất cả nội dung khác ngay lập tức
    allElements = document.querySelectorAll('body > *:not(.loading-screen)');
    console.log('📊 Found', allElements.length, 'elements to hide during loading');
    allElements.forEach(element => {
        element.style.display = 'none';
        element.style.visibility = 'hidden';
    });
    
    // Đảm bảo loading screen hiển thị trên cùng
    loadingScreen.style.zIndex = '999999';
    loadingScreen.style.position = 'fixed';
    loadingScreen.style.top = '0';
    loadingScreen.style.left = '0';
    loadingScreen.style.width = '100%';
    loadingScreen.style.height = '100%';
    loadingScreen.style.display = 'flex';
    
    // Cute loading messages với emoji
    const cuteMessages = [
        '🤖 Robot đang khởi động...',
        '🔧 Đang lắp ráp linh kiện...',
        '🎮 Chuẩn bị game gear...',
        '✨ Tạo phép màu công nghệ...',
        '🚀 Sắp sẵn sàng rồi...',
        '🎉 Chào mừng đến Tech Haven!'
    ];
    
    let progress = 0;
    let currentMessageIndex = 0;
    
    // Detect mobile device
    const isMobile = window.innerWidth <= 768 || /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    function updateCuteProgress() {
        console.log('🔄 Progress update called, current progress:', progress);
        
        // Check if elements still exist before updating
        if (!progressFill || !progressText || !progressPercentage) {
            console.log('❌ Progress elements not found, stopping animation');
            completeLoading();
            return;
        }
        
        // Tăng progress nhanh hơn cho loading speed
        const progressIncrement = isMobile ? Math.random() * 12 + 8 : Math.random() * 20 + 10;
        progress += progressIncrement; 
        
        if (progress >= 100) {
            progress = 100;
            progressFill.style.width = '100%';
            progressPercentage.textContent = '100%';
            progressText.textContent = cuteMessages[5];
            
            console.log('🎯 Progress reached 100%, completing loading...');
            
            // Đơn giản hóa completion animation
            setTimeout(() => {
                completeLoading();
            }, 300);
            return;
        }
        
        // Update progress bar và percentage
        progressFill.style.width = progress + '%';
        progressPercentage.textContent = Math.round(progress) + '%';
        
        // Update cute message
        const messageIndex = Math.floor((progress / 100) * (cuteMessages.length - 1));
        if (messageIndex !== currentMessageIndex && messageIndex < cuteMessages.length - 1) {
            currentMessageIndex = messageIndex;
            progressText.textContent = cuteMessages[messageIndex];
            
            // Smooth bounce effect (reduced on mobile)
            if (!isMobile) {
                progressText.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    progressText.style.transform = 'scale(1)';
                }, 200);
            }
        }
        
        // Tiếp tục với timing nhanh hơn
        const nextInterval = isMobile ? Math.random() * 150 + 100 : Math.random() * 250 + 150;
        setTimeout(updateCuteProgress, nextInterval);
    }
    
    // Function để hoàn thành loading
    function completeLoading() {
        console.log('🎉 Completing loading...');
        
        // Hiện lại tất cả nội dung web
        document.body.classList.remove('loading');
        document.documentElement.classList.remove('loading');
        
        // Hiện lại tất cả element
        allElements.forEach(element => {
            element.style.display = '';
            element.style.visibility = '';
        });
        
        // Ẩn loading screen
        if (loadingScreen) {
            loadingScreen.classList.add('hidden');
            loadingScreen.style.display = 'none';
        }
        
        document.body.style.overflow = 'auto';
        console.log('✅ Loading completed');
        
        // Initialize cart state after loading is complete (for index page)
        if (typeof updateCartUI === 'function') {
            updateCartUI();
            console.log('🔄 Initial cart UI update completed after loading');
        }
    }
    
    // Bắt đầu loading ngay lập tức
    const initialDelay = isMobile ? 100 : 200;
    setTimeout(() => {
        updateCuteProgress();
    }, initialDelay);
    
    // Safety fallback - much shorter timeout for faster loading
    const fallbackTimeout = isMobile ? 2000 : 3000;
    setTimeout(() => {
        if (loadingScreen && !loadingScreen.classList.contains('hidden')) {
            console.log('⚠️ Fallback timeout triggered');
            completeLoading();
        }
    }, fallbackTimeout);

    // Mobile Menu Toggle with improved touch handling
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (mobileMenuToggle && navMenu) {
        // Add both click and touch events for better tablet support
        function toggleMenu() {
            navMenu.classList.toggle('active');
            
            // Change hamburger icon
            const icon = mobileMenuToggle.querySelector('i');
            if (navMenu.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
                mobileMenuToggle.setAttribute('aria-expanded', 'true');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
                mobileMenuToggle.setAttribute('aria-expanded', 'false');
            }
        }
        
        // Add click event listener only - touchend preventDefault blocks mobile onclick
        mobileMenuToggle.addEventListener('click', toggleMenu);
        
        // Add keyboard support
        mobileMenuToggle.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                toggleMenu();
            }
        });

        // Close menu when clicking on menu items
        const menuItems = navMenu.querySelectorAll('a');
        menuItems.forEach(item => {
            function closeMenu() {
                navMenu.classList.remove('active');
                const icon = mobileMenuToggle.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
                mobileMenuToggle.setAttribute('aria-expanded', 'false');
            }
            
            // Only use click event to avoid conflicts with mobile onclick
            item.addEventListener('click', closeMenu);
        });

        // Close menu when clicking outside (but not on functional buttons)
        document.addEventListener('click', function(e) {
            // Don't close menu if clicking on:
            // 1. Mobile menu toggle itself
            // 2. Nav menu container
            // 3. Mobile nav icons (search, cart, user buttons)
            // 4. Admin dropdown elements
            
            const isClickOnToggle = mobileMenuToggle.contains(e.target);
            const isClickOnNavMenu = navMenu.contains(e.target);
            const isClickOnMobileIcons = e.target.closest('.mobile-nav-icons');
            const isClickOnAdminDropdown = e.target.closest('.admin-dropdown');
            const isClickOnFunctionalButton = e.target.closest('a[onclick]') || e.target.closest('button[onclick]');
            
            // Only close menu if NOT clicking on any of the above
            if (!isClickOnToggle && !isClickOnNavMenu && !isClickOnMobileIcons && !isClickOnAdminDropdown && !isClickOnFunctionalButton) {
                navMenu.classList.remove('active');
                const icon = mobileMenuToggle.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
                mobileMenuToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    // Banner Carousel - Completely Rewritten
    class BannerCarousel {
        constructor() {
            this.slides = document.querySelectorAll('.banner-slide');
            this.dots = document.querySelectorAll('.banner-dot');
            this.prevBtn = document.querySelector('.banner-prev');
            this.nextBtn = document.querySelector('.banner-next');
            this.currentSlide = 0;
            this.totalSlides = this.slides.length;
            this.isAnimating = false;
            this.autoPlayInterval = null;
            
            this.init();
        }

        init() {
            if (this.slides.length === 0) return;
            
            // Set up event listeners
            this.prevBtn?.addEventListener('click', () => this.prevSlide());
            this.nextBtn?.addEventListener('click', () => this.nextSlide());
            
            this.dots.forEach((dot, index) => {
                dot.addEventListener('click', () => this.goToSlide(index));
            });

            // Keyboard navigation
            document.addEventListener('keydown', (e) => {
                if (e.key === 'ArrowLeft') this.prevSlide();
                if (e.key === 'ArrowRight') this.nextSlide();
            });

            // Touch/Swipe support
            this.setupTouchEvents();

            // Auto-play
            this.startAutoPlay();

            // Pause on hover
            const bannerContainer = document.querySelector('.banner-container');
            bannerContainer?.addEventListener('mouseenter', () => this.stopAutoPlay());
            bannerContainer?.addEventListener('mouseleave', () => this.startAutoPlay());

            // Initialize first slide
            this.updateSlide();
        }

        goToSlide(index) {
            if (this.isAnimating || index === this.currentSlide) return;
            
            this.currentSlide = index;
            this.updateSlide();
            this.resetAutoPlay();
        }

        nextSlide() {
            if (this.isAnimating) return;
            
            this.currentSlide = (this.currentSlide + 1) % this.totalSlides;
            this.updateSlide();
            this.resetAutoPlay();
        }

        prevSlide() {
            if (this.isAnimating) return;
            
            this.currentSlide = (this.currentSlide - 1 + this.totalSlides) % this.totalSlides;
            this.updateSlide();
            this.resetAutoPlay();
        }

        updateSlide() {
            this.isAnimating = true;

            // Update slides
            this.slides.forEach((slide, index) => {
                slide.classList.toggle('active', index === this.currentSlide);
            });

            // Update dots
            this.dots.forEach((dot, index) => {
                dot.classList.toggle('active', index === this.currentSlide);
            });

            // Reset animation flag after transition
            setTimeout(() => {
                this.isAnimating = false;
            }, 600);
        }

        startAutoPlay() {
            this.autoPlayInterval = setInterval(() => {
                this.nextSlide();
            }, 5000);
        }

        stopAutoPlay() {
            if (this.autoPlayInterval) {
                clearInterval(this.autoPlayInterval);
                this.autoPlayInterval = null;
            }
        }

        resetAutoPlay() {
            this.stopAutoPlay();
            this.startAutoPlay();
        }

        setupTouchEvents() {
            const container = document.querySelector('.banner-container');
            if (!container) return;

            let startX = 0;
            let endX = 0;

            container.addEventListener('touchstart', (e) => {
                startX = e.touches[0].clientX;
            });

            container.addEventListener('touchend', (e) => {
                endX = e.changedTouches[0].clientX;
                const diff = startX - endX;
                const threshold = 50;

                if (Math.abs(diff) > threshold) {
                    if (diff > 0) {
                        this.nextSlide();
                    } else {
                        this.prevSlide();
                    }
                }
            });
        }
    }

    // Initialize banner carousel
    const bannerCarousel = new BannerCarousel();

    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Add smooth transition effect
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });

    // Product card hover effects
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });

    // Add to cart functionality handled by onclick attributes in HTML
    // Removed addEventListener to prevent double calls
    /*
    const addToCartBtns = document.querySelectorAll('.add-to-cart');
    addToCartBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Animation effect
            this.style.transform = 'scale(0.9)';
            this.textContent = 'ADDED!';
            this.style.background = 'linear-gradient(135deg, #10b981, #059669)';
            
            setTimeout(() => {
                this.style.transform = 'scale(1)';
                this.textContent = 'ADD TO CART';
                this.style.background = 'linear-gradient(135deg, #f472b6, #ec4899)';
            }, 1500);
        });
    });
    */

    // Build options functionality
    const buildOptions = document.querySelectorAll('.build-option');
    buildOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            buildOptions.forEach(opt => opt.classList.remove('active'));
            
            // Add active class to clicked option
            this.classList.add('active');
            
            // Add click animation
            this.style.transform = 'scale(0.9)';
            setTimeout(() => {
                this.style.transform = this.classList.contains('active') ? 'scale(1.1)' : 'scale(1)';
            }, 150);
        });
    });

    // Shop Now button functionality
    const shopBtn = document.querySelector('.shop-btn');
    if (shopBtn) {
        shopBtn.addEventListener('click', function() {
            // Scroll to featured products section
            const featuredSection = document.querySelector('.featured-products');
            if (featuredSection) {
                featuredSection.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    }

    // Header scroll effect
    const header = document.querySelector('.header');
    let lastScrollY = window.scrollY;

    window.addEventListener('scroll', () => {
        const currentScrollY = window.scrollY;
        
        if (currentScrollY > 100) {
            header.style.background = 'rgba(255, 255, 255, 0.98)';
            header.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.15)';
        } else {
            header.style.background = 'rgba(255, 255, 255, 0.95)';
            header.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.1)';
        }
        
        lastScrollY = currentScrollY;
    });

    // Parallax effect for hero section (disabled to prevent overlap)
    // window.addEventListener('scroll', () => {
    //     const scrolled = window.pageYOffset;
    //     const parallax = document.querySelector('.hero');
    //     if (parallax) {
    //         const speed = scrolled * 0.5;
    //         parallax.style.transform = `translateY(${speed}px)`;
    //     }
    // });

    // Animation on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const animateElements = document.querySelectorAll('.product-card, .build-option');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });

    // Mobile menu icons functionality handled by onclick attributes in HTML

    // Add loading animation
    window.addEventListener('load', function() {
        document.body.classList.add('loaded');
        
        // Remove any conflicting transforms
        const hero = document.querySelector('.hero');
        if (hero) {
            hero.style.transform = 'none';
        }
        
        // Animate elements on page load
        const heroContent = document.querySelector('.hero-content');
        if (heroContent) {
            heroContent.style.opacity = '0';
            heroContent.style.transform = 'translateY(50px)';
            setTimeout(() => {
                heroContent.style.transition = 'opacity 1s ease, transform 1s ease';
                heroContent.style.opacity = '1';
                heroContent.style.transform = 'translateY(0)';
            }, 300);
        }
    });

    // =====================================
    // SMART CART MANAGER CLASS
    // =====================================
    
    // Smart Cart State Manager - automatically switches between localStorage and Firebase
    class SmartCartManager {
        constructor() {
            this.isLoggedIn = false;
            this.lastUpdateSource = 'localStorage';
            this.cartData = {
                items: [],
                count: 0,
                total: 0
            };
            console.log('🧠 SmartCartManager initialized');
        }
        
        // Update authentication status and trigger cart refresh
        setAuthStatus(isLoggedIn, user = null) {
            console.log('🔄 SmartCartManager: Auth status changed:', isLoggedIn ? 'LOGGED IN' : 'LOGGED OUT');
            const wasLoggedIn = this.isLoggedIn;
            this.isLoggedIn = isLoggedIn;
            window.currentUser = user;
            
            if (wasLoggedIn !== isLoggedIn) {
                console.log('🔄 Auth status changed, refreshing cart...');
                this.refreshCartData();
            }
        }
        
        // Get cart data from appropriate source
        async getCartData() {
            if (this.isLoggedIn && window.currentUser) {
                console.log('👤 SmartCartManager: Getting cart from Firebase for user:', window.currentUser.uid);
                try {
                    const response = await fetch(`/api/cart?uid=${window.currentUser.uid}`);
                    if (response.ok) {
                        const data = await response.json();
                        console.log('📦 Firebase cart response:', data);
                        if (data.success) {
                            this.lastUpdateSource = 'firebase';
                            return {
                                items: data.cartItems || [],
                                count: data.itemCount || 0,
                                total: data.total || 0
                            };
                        }
                    }
                } catch (error) {
                    console.warn('⚠️ Firebase cart load failed, falling back to localStorage:', error);
                }
            }
            
            // Fallback to localStorage
            console.log('💾 SmartCartManager: Getting cart from localStorage');
            const localItems = JSON.parse(localStorage.getItem('techHavenCart')) || [];
            const localCount = parseInt(localStorage.getItem('techHavenCartCount')) || 0;
            const localTotal = localItems.reduce((sum, item) => sum + ((item.numericPrice || 0) * (item.quantity || 1)), 0);
            
            this.lastUpdateSource = 'localStorage';
            return {
                items: localItems,
                count: localCount,
                total: localTotal
            };
        }
        
        // Refresh cart data and update UI
        async refreshCartData() {
            console.log('🔄 SmartCartManager: Refreshing cart data...');
            this.cartData = await this.getCartData();
            console.log('📊 SmartCartManager: Cart data refreshed:', this.cartData);
            this.updateCartIcon();
            return this.cartData;
        }
        
        // Update cart icon with visual indicator of data source
        updateCartIcon() {
            const cartBadge = document.getElementById('cartBadge');
            const cartIcon = document.querySelector('#cartIcon i.fas.fa-shopping-cart');
            const cartIconWrapper = document.getElementById('cartIcon');
            const cartStateTooltip = document.getElementById('cartStateTooltip');
            const mobileCartCount = document.getElementById('mobileCartCount');
            
            console.log('🎨 SmartCartManager: Updating cart icon:', {
                count: this.cartData.count,
                source: this.lastUpdateSource,
                isLoggedIn: this.isLoggedIn,
                elements: {
                    cartBadge: !!cartBadge,
                    cartIcon: !!cartIcon,
                    cartIconWrapper: !!cartIconWrapper,
                    cartStateTooltip: !!cartStateTooltip
                }
            });
            
            // Update cart badge
            if (cartBadge) {
                cartBadge.textContent = this.cartData.count;
                cartBadge.style.display = this.cartData.count > 0 ? 'flex' : 'none';
                
                // Add visual indicator for data source
                cartBadge.classList.remove('firebase-data', 'local-data');
                cartBadge.classList.add(this.lastUpdateSource === 'firebase' ? 'firebase-data' : 'local-data');
                cartBadge.title = this.lastUpdateSource === 'firebase' ? 'Dữ liệu từ Cloud' : 'Dữ liệu cục bộ';
            }
            
            // Update cart icon wrapper classes
            if (cartIconWrapper) {
                cartIconWrapper.classList.remove('has-firebase-data', 'has-local-data');
                cartIconWrapper.classList.add(this.lastUpdateSource === 'firebase' ? 'has-firebase-data' : 'has-local-data');
            }
            
            // Update tooltip
            if (cartStateTooltip) {
                const tooltip = this.lastUpdateSource === 'firebase' 
                    ? `☁️ Dữ liệu Cloud (${this.cartData.count} sản phẩm)`
                    : `💾 Dữ liệu cục bộ (${this.cartData.count} sản phẩm)`;
                cartStateTooltip.textContent = tooltip;
            }
            
            // Update mobile cart count
            if (mobileCartCount) {
                mobileCartCount.textContent = this.cartData.count;
                mobileCartCount.classList.remove('firebase-data', 'local-data');
                mobileCartCount.classList.add(this.lastUpdateSource === 'firebase' ? 'firebase-data' : 'local-data');
            }
            
            // Update cart icon color to indicate data source
            if (cartIcon) {
                cartIcon.classList.remove('firebase-data', 'local-data');
                cartIcon.classList.add(this.lastUpdateSource === 'firebase' ? 'firebase-data' : 'local-data');
                cartIcon.title = this.lastUpdateSource === 'firebase' ? 'Giỏ hàng Cloud' : 'Giỏ hàng cục bộ';
            }
            
            // Update global cartItems and cartCount for compatibility
            cartItems.length = 0;
            cartItems.push(...this.cartData.items);
            cartCount = this.cartData.count;
            
            console.log('✅ SmartCartManager: Cart icon updated successfully');
        }
    }
    
    // Initialize Smart Cart Manager
    const smartCart = new SmartCartManager();
    window.smartCart = smartCart;
    
    console.log('🧠 SmartCartManager class created and initialized');

    // =====================================
    // SHOPPING CART FUNCTIONALITY
    // =====================================

    // Get authentication token for API calls
    async function getAuthToken() {
        if (window.currentUser) {
            // For Firebase Auth users
            if (window.currentUser.provider === 'firebase' && window.firebase && window.firebase.auth && window.firebase.auth().currentUser) {
                try {
                    return await window.firebase.auth().currentUser.getIdToken();
                } catch (error) {
                    console.warn('⚠️ Could not get Firebase ID token:', error);
                }
            }
            
            // For manual users, create a simple token with user info
            if (window.currentUser.provider === 'manual' || !window.currentUser.provider) {
                return btoa(JSON.stringify({
                    uid: window.currentUser.uid,
                    email: window.currentUser.email,
                    provider: 'manual',
                    timestamp: Date.now()
                }));
            }
        }
        
        return null;
    }

    // Note: addToCart function is defined early at the top of the file to prevent overwriting
    // This comment marks where the original function was located

    // Load cart from database (for logged users)
    async function loadCartFromDatabase() {
        if (!window.currentUser) {
            console.log('No user logged in, skipping database cart load');
            return;
        }

        try {
            console.log('🔄 Loading cart from database...');
            const response = await fetch(`/api/cart?uid=${window.currentUser.uid}`);
            
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.cartItems) {
                    // Filter and normalize cart items
                    const validCartItems = data.cartItems.filter(item => {
                        const isValid = item && 
                            (item.productName || item.name) && 
                            (item.productName !== 'undefined' && item.name !== 'undefined') && 
                            item.productId && 
                            item.productId !== 'undefined' && 
                            (item.numericPrice || item.price || item.productPrice) &&
                            !isNaN(parseFloat(item.numericPrice || item.price || item.productPrice)) &&
                            item.quantity > 0;
                        
                        if (!isValid) {
                            console.warn('🗑️ Filtering out invalid cart item:', item);
                        }
                        return isValid;
                    }).map(item => {
                        // Normalize the item structure for consistent frontend usage
                        return {
                            id: item.id || item.cartId,
                            cartId: item.cartId || item.id,
                            productId: item.productId,
                            name: item.productName || item.name,
                            productName: item.productName || item.name,
                            price: item.productPrice || item.price || (item.numericPrice + ' VNĐ'),
                            productPrice: item.productPrice || item.price,
                            numericPrice: parseFloat(item.numericPrice || item.price || item.productPrice) || 0,
                            image: item.productImage || item.image,
                            productImage: item.productImage || item.image,
                            quantity: item.quantity || 1
                        };
                    });
                    
                    console.log('✅ Normalized cart items:', validCartItems.length, validCartItems);
                    
                    // Update global cartItems with filtered and normalized database data
                    cartItems.length = 0; // Clear existing items
                    cartItems.push(...validCartItems);
                    
                    // Recalculate cart count
                    cartCount = cartItems.reduce((total, item) => total + (item.quantity || 0), 0);
                    
                    console.log(`✅ Cart loaded from database: ${cartItems.length} valid items, total count: ${cartCount}`);
                    updateCartUI();
                    saveCartToStorage(); // Update localStorage with fresh data
                } else {
                    // Empty cart
                    cartItems.length = 0;
                    cartCount = 0;
                    updateCartUI();
                    saveCartToStorage();
                }
            } else {
                throw new Error('Failed to load cart from database');
            }
        } catch (error) {
            console.error('❌ Error loading cart from database:', error);
            throw error;
        }
    }

    // Sync cart from database API (fallback function)
    async function syncCartFromAPI() {
        if (!window.currentUser) {
            console.log('No user logged in, skipping cart sync');
            return;
        }

        try {
            console.log('🔄 Syncing cart from database API...');
            const response = await fetch(`/api/cart?uid=${window.currentUser.uid}`);
            
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.cartItems) {
                    // Update global cartItems with database data
                    cartItems.length = 0; // Clear existing items
                    cartItems.push(...data.cartItems);
                    
                    // Recalculate cart count
                    cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);
                    
                    console.log(`✅ Cart synced from database: ${cartItems.length} items, total count: ${cartCount}`);
                    updateCartUI();
                    saveCartToStorage(); // Update localStorage with fresh data
                }
            } else {
                throw new Error('Failed to load cart from API');
            }
        } catch (error) {
            console.error('❌ Error syncing cart from API:', error);
            throw error;
        }
    }

    // Force refresh cart from database (comprehensive cleanup)
    async function forceRefreshCart() {
        if (!window.currentUser) {
            console.log('❌ No user logged in, cannot force refresh cart');
            return;
        }

        try {
            console.log('🔃 Force refreshing cart from database...');
            
            // First cleanup invalid items in database
            await cleanupInvalidCartItems();
            
            // Then reload from database with fresh data
            await loadCartFromDatabase();
            
            // Clear localStorage to prevent conflicts
            localStorage.removeItem('techHavenCart');
            localStorage.removeItem('techHavenCartCount');
            
            console.log('✅ Cart force refresh completed');
        } catch (error) {
            console.error('❌ Error during force refresh:', error);
        }
    }
    
    // Export force refresh for external use
    window.forceRefreshCart = forceRefreshCart;

    // Synchronize cart when user logs in (merge local + database)
    async function syncCartOnLogin() {
        if (!window.currentUser) {
            console.log('❌ No user logged in, cannot sync cart');
            return;
        }

        console.log('🔄 Synchronizing cart on login for user:', window.currentUser.uid);
        
        // Get local cart items and validate them
        const rawLocalCartItems = JSON.parse(localStorage.getItem('techHavenCart')) || [];
        const localCartItems = rawLocalCartItems.filter(item => {
            const isValid = item && 
                item.id && 
                item.id !== 'undefined' &&
                item.name && 
                item.name !== 'undefined' &&
                (item.numericPrice || item.price) &&
                item.quantity > 0;
            
            if (!isValid) {
                console.warn('🗑️ Filtering out invalid local cart item:', item);
            }
            return isValid;
        });
        
        console.log('📦 Valid local cart items:', localCartItems.length, 'out of', rawLocalCartItems.length);
        
        try {
            // Load existing cart from database
            const response = await fetch(`/api/cart?uid=${window.currentUser.uid}`);
            let databaseCartItems = [];
            
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.cartItems) {
                    databaseCartItems = data.cartItems;
                    console.log('🗄️ Database cart items:', databaseCartItems.length);
                }
            }
            
            // If user has valid local cart items, merge them with database
            if (localCartItems.length > 0) {
                console.log('🔀 Merging valid local cart with database cart...');
                
                for (const localItem of localCartItems) {
                    // Check if item already exists in database
                    const existingItem = databaseCartItems.find(dbItem => 
                        String(dbItem.productId) === String(localItem.id)
                    );
                    
                    if (existingItem) {
                        // Update quantity (add local quantity to database quantity)
                        console.log(`📈 Updating existing item ${localItem.name}: ${existingItem.quantity} + ${localItem.quantity}`);
                        
                        await fetch('/api/cart/update-quantity', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                userId: window.currentUser.uid,
                                productId: localItem.id,
                                quantity: existingItem.quantity + localItem.quantity
                            })
                        });
                    } else {
                        // Add new item to database
                        console.log(`➕ Adding new item ${localItem.name} to database`);
                        
                        await fetch('/api/cart', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                userId: window.currentUser.uid,
                                productId: localItem.id,
                                productName: localItem.name,
                                productPrice: localItem.price,
                                numericPrice: localItem.numericPrice,
                                productImage: localItem.image,
                                quantity: localItem.quantity
                            })
                        });
                    }
                }
                
                // Clear local storage after successful merge
                localStorage.removeItem('techHavenCart');
                localStorage.removeItem('techHavenCartCount');
                console.log('🧹 Cleared local cart after merge');
            }
            
            // Clean up any invalid cart items first
            await cleanupInvalidCartItems();
            
            // Now load the complete cart from database
            await loadCartFromDatabase();
            
            // Force UI refresh after sync
            setTimeout(() => {
                forceCartUIRefresh();
            }, 100);
            
        } catch (error) {
            console.error('❌ Error during cart synchronization:', error);
            // Fallback: just load from database
            try {
                await loadCartFromDatabase();
                setTimeout(() => {
                    forceCartUIRefresh();
                }, 100);
            } catch (fallbackError) {
                console.error('❌ Fallback load also failed:', fallbackError);
            }
        }
    }
    
    // Force cart UI refresh to ensure synchronization
    function forceCartUIRefresh() {
        console.log('🔄 Forcing cart UI refresh...');
        
        // Ensure window.cartItems and cartItems are synchronized
        if (window.cartItems && Array.isArray(window.cartItems)) {
            cartItems.length = 0;
            cartItems.push(...window.cartItems);
        }
        
        // Force update cart UI
        updateCartUI();
        
        // Also update localStorage to ensure persistence
        if (typeof saveCartToStorage === 'function') {
            saveCartToStorage();
        }
        
        console.log('✅ Cart UI refresh completed - Items:', cartItems.length, 'Count:', cartCount);
    }
    
    // Export force refresh for external use
    window.forceCartUIRefresh = forceCartUIRefresh;

    // Clean up invalid cart items from database
    async function cleanupInvalidCartItems() {
        if (!window.currentUser) {
            return;
        }

        try {
            console.log('🧹 Cleaning up invalid cart items...');
            
            // Get current cart from database
            const response = await fetch(`/api/cart?uid=${window.currentUser.uid}`);
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.cartItems) {
                    // Find invalid items
                    const invalidItems = data.cartItems.filter(item => 
                        !item || 
                        !item.productName || 
                        item.productName === 'undefined' || 
                        !item.productId || 
                        item.productId === 'undefined' ||
                        isNaN(item.numericPrice) ||
                        item.quantity <= 0
                    );
                    
                    // Remove invalid items
                    for (const invalidItem of invalidItems) {
                        if (invalidItem.cartId) {
                            console.log('🗑️ Removing invalid cart item:', invalidItem);
                            await fetch(`/api/cart/${invalidItem.cartId}`, {
                                method: 'DELETE'
                            });
                        }
                    }
                    
                    if (invalidItems.length > 0) {
                        console.log(`✅ Cleaned up ${invalidItems.length} invalid cart items`);
                    }
                }
            }
        } catch (error) {
            console.error('❌ Error cleaning up invalid cart items:', error);
        }
    }

    // Save cart to database
    async function saveCartToDatabase() {
        if (!window.currentUser) {
            console.log('No user logged in, skipping cart save to database');
            return;
        }

        try {
            console.log('💾 Saving cart to database...');
            const response = await fetch(`/api/cart/by-uid/${window.currentUser.uid}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    cartItems: cartItems,
                    total: cartItems.reduce((total, item) => total + (item.numericPrice * item.quantity), 0)
                })
            });

            if (!response.ok) {
                throw new Error('Failed to save cart to database');
            }

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.error || 'Unknown error saving cart');
            }

            console.log('✅ Cart successfully saved to database');
        } catch (error) {
            console.error('❌ Error saving cart to database:', error);
            throw error;
        }
    }

    // Remove from cart
    async function removeFromCart(productId) {
        const stringId = String(productId);
        console.log('🗑️ Removing product with ID:', stringId);
        
        // If user is logged in, work with database
        if (window.currentUser && window.currentUser.uid) {
            try {
                let headers = {
                    'Content-Type': 'application/json'
                };
                
                // Add Authorization header only for Firebase Auth users
                if (window.currentUser.provider === 'firebase') {
                    const token = await getAuthToken();
                    if (token) {
                        headers['Authorization'] = `Bearer ${token}`;
                    }
                }
                
                // For manual users, add userId as query parameter
                const url = window.currentUser.provider === 'manual' 
                    ? `/api/cart/product/${stringId}?userId=${window.currentUser.uid}`
                    : `/api/cart/product/${stringId}`;
                
                const response = await fetch(url, {
                    method: 'DELETE',
                    headers: headers
                });
                
                if (response.ok) {
                    console.log('✅ Item removed from database successfully');
                    // Reload cart from database to update UI
                    await loadCartFromDatabase();
                } else {
                    console.error('❌ Failed to remove item from database:', await response.text());
                    showNotification('Có lỗi xảy ra khi xóa sản phẩm!', 'error');
                }
            } catch (error) {
                console.error('❌ Error removing item from database:', error);
                showNotification('Có lỗi xảy ra khi xóa sản phẩm!', 'error');
            }
        } else {
            // For non-logged users, work with local storage
            const itemIndex = cartItems.findIndex(item => 
                String(item.id) === stringId || 
                String(item.productId) === stringId
            );
            
            if (itemIndex > -1) {
                const item = cartItems[itemIndex];
                cartCount -= item.quantity;
                cartItems.splice(itemIndex, 1);
                updateCartUI();
                saveCartToStorage();
                console.log('✅ Item removed from local cart');
            } else {
                console.error('❌ Item not found with ID:', stringId);
            }
        }
    }

    // Update quantity
    async function updateCartQuantity(productId, newQuantity) {
        const stringId = String(productId);
        console.log('Updating quantity for product ID:', stringId, 'to quantity:', newQuantity);
        
        if (newQuantity <= 0) {
            // If quantity is 0 or less, remove the item
            await removeFromCart(stringId);
            return;
        }
        
        // If user is logged in, work with database
        if (window.currentUser) {
            try {
                let headers = {
                    'Content-Type': 'application/json'
                };
                
                let body = {
                    productId: stringId,
                    quantity: newQuantity
                };
                
                // Add Authorization header only for Firebase Auth users
                if (window.currentUser.provider === 'firebase') {
                    const token = await getAuthToken();
                    if (token) {
                        headers['Authorization'] = `Bearer ${token}`;
                    }
                } else {
                    // For manual users, add userId to body
                    body.userId = window.currentUser.uid;
                }
                
                const response = await fetch(`/api/cart/update-quantity`, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify(body)
                });
                
                if (response.ok) {
                    console.log('✅ Quantity updated in database');
                    // Reload cart from database to update UI
                    await loadCartFromDatabase();
                } else {
                    console.error('❌ Failed to update quantity in database');
                    showNotification('Có lỗi xảy ra khi cập nhật số lượng!', 'error');
                }
            } catch (error) {
                console.error('❌ Error updating quantity in database:', error);
                showNotification('Có lỗi xảy ra khi cập nhật số lượng!', 'error');
            }
        } else {
            // For non-logged users, work with local storage
            const item = cartItems.find(item => 
                String(item.id) === stringId || 
                String(item.productId) === stringId
            );
            if (item) {
                const oldQuantity = item.quantity;
                item.quantity = newQuantity;
                cartCount += (item.quantity - oldQuantity);
                updateCartUI();
                saveCartToStorage();
                console.log('✅ Quantity updated in local cart');
            } else {
                console.error('❌ Item not found with ID:', stringId);
            }
        }
    }

    // Remove from cart by cart ID (for database-managed carts)
    async function removeFromCartById(cartId) {
        const stringCartId = String(cartId);
        console.log('🗑️ removeFromCartById called with:', {
            cartId: stringCartId,
            currentUser: window.currentUser ? window.currentUser.uid : 'not logged in'
        });
        
        // If user is logged in, work with database
        if (window.currentUser && window.currentUser.uid) {
            try {
                console.log('🔄 Making API request to remove cart item...');
                const apiUrl = `/api/cart/${stringCartId}`;
                console.log('📡 API URL:', apiUrl);
                
                const response = await fetch(apiUrl, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                console.log('📊 Response status:', response.status);
                console.log('📊 Response ok:', response.ok);

                if (!response.ok) {
                    const errorText = await response.text();
                    console.error('❌ Response error:', errorText);
                    throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                }

                const result = await response.json();
                console.log('📋 API Response result:', result);
                
                if (!result.success) {
                    throw new Error(result.message || 'Failed to remove item from cart');
                }

                console.log('✅ Item successfully removed from database cart');
                
                // Update local cart state
                const initialLength = cartItems.length;
                cartItems = cartItems.filter(item => 
                    String(item.cartId || item.id) !== stringCartId
                );
                
                console.log('📊 Local cart update:', {
                    initialLength: initialLength,
                    newLength: cartItems.length,
                    removedItems: initialLength - cartItems.length
                });
                
                cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);
                console.log('📊 New cart count:', cartCount);
                
                updateCartUI();
                showNotification('Đã xóa sản phẩm khỏi giỏ hàng!', 'success');

            } catch (error) {
                console.error('❌ Error removing item from database:', error);
                console.error('❌ Error stack:', error.stack);
                showNotification('Có lỗi xảy ra khi xóa sản phẩm!', 'error');
            }
        } else {
            console.log('👤 User not logged in, working with local storage');
            // For non-logged users, work with local storage
            const itemIndex = cartItems.findIndex(item => 
                String(item.id) === stringCartId || 
                String(item.cartId) === stringCartId
            );
            if (itemIndex !== -1) {
                const removedItem = cartItems[itemIndex];
                cartCount -= removedItem.quantity;
                cartItems.splice(itemIndex, 1);
                updateCartUI();
                saveCartToStorage();
                console.log('✅ Item removed from local cart');
                showNotification('Đã xóa sản phẩm khỏi giỏ hàng!', 'success');
            } else {
                console.error('❌ Item not found with cart ID:', stringCartId);
            }
        }
    }

    // Update cart quantity by cart ID (for database-managed carts)
    async function updateCartQuantityById(cartId, newQuantity) {
        const stringCartId = String(cartId);
        console.log('🔧 updateCartQuantityById called with:', {
            cartId: stringCartId,
            newQuantity: newQuantity,
            currentUser: window.currentUser ? window.currentUser.uid : 'not logged in'
        });
        
        if (newQuantity <= 0) {
            console.log('⚠️ Quantity is 0 or less, removing item');
            await removeFromCartById(stringCartId);
            return;
        }
        
        // If user is logged in, work with database
        if (window.currentUser) {
            try {
                console.log('🔄 Making API request to update cart quantity...');
                const apiUrl = `/api/cart/${stringCartId}`;
                console.log('📡 API URL:', apiUrl);
                
                const requestBody = { quantity: newQuantity };
                console.log('📦 Request body:', requestBody);
                
                const response = await fetch(apiUrl, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(requestBody)
                });

                console.log('📊 Response status:', response.status);
                console.log('📊 Response ok:', response.ok);

                if (!response.ok) {
                    const errorText = await response.text();
                    console.error('❌ Response error:', errorText);
                    throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                }

                const result = await response.json();
                console.log('📋 API Response result:', result);
                
                if (!result.success) {
                    throw new Error(result.message || 'Failed to update cart quantity');
                }

                console.log('✅ Quantity successfully updated in database');
                
                // Update local cart state
                const item = cartItems.find(item => 
                    String(item.cartId || item.id) === stringCartId
                );
                
                console.log('🔍 Looking for item in local cart with ID:', stringCartId);
                console.log('🛒 Current cartItems:', cartItems.map(item => ({
                    cartId: item.cartId || item.id,
                    name: item.name,
                    quantity: item.quantity
                })));
                
                if (item) {
                    const oldQuantity = item.quantity;
                    item.quantity = newQuantity;
                    cartCount += (item.quantity - oldQuantity);
                    console.log('📊 Updated local item:', {
                        oldQuantity: oldQuantity,
                        newQuantity: newQuantity,
                        newCartCount: cartCount
                    });
                    updateCartUI();
                    console.log('✅ Local cart state updated and UI refreshed');
                } else {
                    console.log('⚠️ Item not found locally, refreshing from server...');
                    await loadCartFromDatabase();
                }

            } catch (error) {
                console.error('❌ Error updating quantity in database:', error);
                console.error('❌ Error stack:', error.stack);
                showNotification('Có lỗi xảy ra khi cập nhật số lượng!', 'error');
            }
        } else {
            console.log('👤 User not logged in, working with local storage');
            // For non-logged users, work with local storage
            const item = cartItems.find(item => 
                String(item.id) === stringCartId || 
                String(item.cartId) === stringCartId
            );
            if (item) {
                const oldQuantity = item.quantity;
                item.quantity = newQuantity;
                cartCount += (item.quantity - oldQuantity);
                updateCartUI();
                saveCartToStorage();
                console.log('✅ Quantity updated in local cart');
            } else {
                console.error('❌ Item not found with cart ID:', stringCartId);
            }
        }
    }

    // Export cart functions for use in other scripts
    // DISABLED: Using simple cart functions from shop.ejs instead
    // window.updateCartQuantityById = updateCartQuantityById;
    // window.removeFromCartById = removeFromCartById;

    // Get product icon
    function getProductIcon(productName) {
        const name = productName.toLowerCase();
        if (name.includes('cpu') || name.includes('core')) return 'fas fa-microchip';
        if (name.includes('gpu') || name.includes('rtx') || name.includes('gtx')) return 'fas fa-memory';
        if (name.includes('laptop')) return 'fas fa-laptop';
        if (name.includes('monitor') || name.includes('màn hình')) return 'fas fa-desktop';
        if (name.includes('keyboard') || name.includes('bàn phím')) return 'fas fa-keyboard';
        if (name.includes('mouse') || name.includes('chuột')) return 'fas fa-mouse';
        if (name.includes('headset') || name.includes('tai nghe')) return 'fas fa-headset';
        if (name.includes('ssd') || name.includes('nvme') || name.includes('hdd')) return 'fas fa-hdd';
        if (name.includes('ram') || name.includes('memory')) return 'fas fa-memory';
        return 'fas fa-cube';
    }

    // Update cart UI
    function updateCartUI() {
        // Use consistent cart data source - prefer window.cartItems if available for cross-script compatibility
        const activeCartItems = window.cartItems || cartItems;
        console.log('🔄 Updating cart UI with', activeCartItems.length, 'items');
        
        // First, filter out any invalid items that might have slipped through
        const validCartItems = activeCartItems.filter(item => {
            const isValid = item && 
                (item.name || item.productName) && 
                (item.name !== 'undefined' && item.productName !== 'undefined') &&
                item.productId && 
                item.productId !== 'undefined' &&
                item.quantity > 0 &&
                (item.numericPrice || item.price || item.productPrice) &&
                !isNaN(parseFloat(item.numericPrice || item.price || item.productPrice));
                
            if (!isValid) {
                console.warn('🗑️ Filtering out invalid item in UI update:', item);
            }
            return isValid;
        });
        
        // Update both cart arrays with filtered items for consistency
        if (validCartItems.length !== activeCartItems.length) {
            console.log(`🧹 Cleaned ${activeCartItems.length - validCartItems.length} invalid items from cart`);
            
            // Update local cartItems
            cartItems.length = 0;
            cartItems.push(...validCartItems);
            
            // Update window.cartItems if it exists
            if (window.cartItems) {
                window.cartItems.length = 0;
                window.cartItems.push(...validCartItems);
            }
            
            // Save cleaned cart to storage
            if (typeof saveCartToStorage === 'function') {
                saveCartToStorage();
            }
        }
        
        // Sync cartCount with valid cart items to ensure consistency
        cartCount = validCartItems.reduce((total, item) => total + (item.quantity || 1), 0);
        
        console.log('📊 Cart UI Update - Items:', validCartItems.length, 'Count:', cartCount);
        
        // Update cart badge
        const cartBadge = document.getElementById('cartBadge');
        const cartCountSpan = document.getElementById('cartCount');
        const mobileCartCount = document.getElementById('mobileCartCount');
        
        if (cartBadge) {
            cartBadge.textContent = cartCount;
            cartBadge.style.display = cartCount > 0 ? 'flex' : 'none';
        }
        
        if (cartCountSpan) {
            cartCountSpan.textContent = cartCount;
        }
        
        if (mobileCartCount) {
            mobileCartCount.textContent = cartCount;
        }

        // Update cart items display using validated items
        const cartItemsContainer = document.getElementById('cartItems');
        if (cartItemsContainer) {
            if (validCartItems.length === 0) {
                cartItemsContainer.innerHTML = `
                    <div class="empty-cart">
                        <i class="fas fa-shopping-cart" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                        <p>Giỏ hàng của bạn đang trống</p>
                        <small>Thêm sản phẩm để bắt đầu mua sắm</small>
                    </div>
                `;
            } else {
                cartItemsContainer.innerHTML = validCartItems.map(item => {
                    // Use cart ID if available, otherwise fall back to product ID
                    const itemId = item.cartId || item.id || item.productId;
                    const productId = item.productId || item.id;
                    
                    console.log('🎯 Generating cart item HTML:', {
                        itemId: itemId,
                        productId: productId,
                        quantity: item.quantity,
                        name: item.name || item.productName
                    });
                    
                    return `
                        <div class="cart-item" data-product-id="${productId}" data-cart-id="${itemId}">
                            <div class="cart-item-image">
                                ${getCartItemImage(item)}
                            </div>
                            <div class="cart-item-details">
                                <div class="cart-item-name">${(item.name || item.productName || 'Unknown Product').toString()}</div>
                                <div class="cart-item-price">${getProductPriceDisplay(item)}</div>
                                <div class="cart-item-controls">
                                    <button class="quantity-btn decrease-qty" data-cart-id="${itemId}" data-current-quantity="${item.quantity}"${!window.currentUser ? ` onclick="updateGuestCartQuantity('${itemId}', ${item.quantity - 1})"` : ''}>
                                        <i class="fas fa-minus"></i>
                                    </button>
                                    <span class="cart-item-quantity">${item.quantity}</span>
                                    <button class="quantity-btn increase-qty" data-cart-id="${itemId}" data-current-quantity="${item.quantity}"${!window.currentUser ? ` onclick="updateGuestCartQuantity('${itemId}', ${item.quantity + 1})"` : ''}>
                                        <i class="fas fa-plus"></i>
                                    </button>
                                    <button class="remove-item" data-cart-id="${itemId}"${!window.currentUser ? ` onclick="removeGuestCartItem('${itemId}')"` : ''}>
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
                
                // Add event listeners for cart controls
                // DISABLED: Using simple cart listeners from shop.ejs instead
                // setupCartEventListeners();
            }
        }

        // Update cart total
        const total = calculateCartTotal();
        const cartTotalElement = document.getElementById('cartTotal');
        if (cartTotalElement) {
            cartTotalElement.textContent = formatPrice(total) + ' VNĐ';
        }

        // Update checkout button using validated cart items
        const checkoutBtn = document.getElementById('checkoutBtn');
        if (checkoutBtn) {
            checkoutBtn.disabled = validCartItems.length === 0;
        }
        
        console.log('✅ Cart UI updated - Badge:', cartCount, 'Items:', validCartItems.length, 'Total:', formatPrice(calculateCartTotal()));
    }

    // Calculate cart total
    function calculateCartTotal() {
        // Use window.cartItems (synced from shop.ejs) if available, fallback to local cartItems
        let activeCartItems = window.cartItems || cartItems;
        
        // Ensure activeCartItems is always an array and filter valid items
        if (!Array.isArray(activeCartItems)) {
            console.warn('⚠️ activeCartItems is not an array, defaulting to empty array');
            activeCartItems = [];
        }
        
        // Filter valid items for calculation
        const validItems = activeCartItems.filter(item => 
            item && 
            item.quantity > 0 && 
            !isNaN(parseFloat(item.numericPrice || item.price || item.productPrice))
        );
        
        return activeCartItems.reduce((total, item) => {
            let price = 0;
            
            // Handle different price field names from different sources
            if (item.numericPrice) {
                price = item.numericPrice;
            } else if (item.productPrice && typeof item.productPrice === 'number') {
                price = item.productPrice;
            } else if (item.price && typeof item.price === 'string') {
                price = parseInt(item.price.replace(/[^\d]/g, ''));
            } else if (item.price && typeof item.price === 'number') {
                price = item.price;
            } else if (item.productPrice && typeof item.productPrice === 'string') {
                price = parseInt(item.productPrice.replace(/[^\d]/g, ''));
            } else {
                console.warn('❌ No valid price found for cart item:', item);
                price = 0;
            }
            
            return total + (price * (item.quantity || 1));
        }, 0);
    }

    // Get cart item image HTML safely
    function getCartItemImage(item) {
        console.log('🖼️ Getting image for cart item:', {
            id: item.id,
            productImage: item.productImage,
            image: item.image,
            imageUrl: item.imageUrl,
            name: item.name,
            productName: item.productName
        });
        
        // Try to get image URL from different possible fields
        let imageUrl = null;
        
        if (item.productImage && (item.productImage.startsWith('http') || item.productImage.startsWith('/'))) {
            imageUrl = item.productImage;
        } else if (item.image && (item.image.startsWith('http') || item.image.startsWith('/'))) {
            imageUrl = item.image;
        } else if (item.imageUrl && (item.imageUrl.startsWith('http') || item.imageUrl.startsWith('/'))) {
            imageUrl = item.imageUrl;
        }
        
        if (imageUrl) {
            console.log('✅ Found image URL:', imageUrl);
            return `<img src="${imageUrl}" alt="${item.name || item.productName || 'Product'}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 8px;">`;
        } else {
            // Fallback to icon based on product name or default
            const iconClass = getProductIcon(item.name || item.productName || 'product');
            console.log('⚠️ No image found, using icon:', iconClass);
            return `<i class="${iconClass}" style="color: ${item.imageColor || '#667eea'}; font-size: 24px;"></i>`;
        }
    }

    // Get product price display text safely
    function getProductPriceDisplay(item) {
        // Try multiple price fields in order of preference
        const priceValue = item.numericPrice || item.productPrice || item.price;
        
        if (priceValue && !isNaN(parseFloat(priceValue))) {
            return new Intl.NumberFormat('vi-VN').format(parseFloat(priceValue)) + ' VNĐ';
        } else if (typeof item.price === 'string' && item.price !== 'undefined' && item.price !== 'NaN ₫' && item.price !== 'NaN VNĐ') {
            return item.price;
        } else if (typeof item.productPrice === 'string' && item.productPrice !== 'undefined' && item.productPrice !== 'NaN ₫' && item.productPrice !== 'NaN VNĐ') {
            return item.productPrice;
        } else {
            console.warn('⚠️ No valid price found for item:', item);
            return '0 VNĐ';
        }
    }

    // Format price
    function formatPrice(price) {
        return new Intl.NumberFormat('vi-VN').format(price);
    }

    // Guest cart management functions
    window.updateGuestCartQuantity = function(itemId, newQuantity) {
        console.log('🔄 Updating guest cart quantity:', itemId, newQuantity);
        
        if (newQuantity <= 0) {
            removeGuestCartItem(itemId);
            return;
        }
        
        const itemIndex = cartItems.findIndex(item => String(item.id) === String(itemId));
        if (itemIndex !== -1) {
            cartItems[itemIndex].quantity = newQuantity;
            cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);
            
            // Save to localStorage
            localStorage.setItem('techHavenCart', JSON.stringify(cartItems));
            localStorage.setItem('techHavenCartCount', cartCount.toString());
            
            // Update UI
            updateCartUI();
            console.log('✅ Guest cart quantity updated');
        }
    };

    window.removeGuestCartItem = function(itemId) {
        console.log('🗑️ Removing guest cart item:', itemId);
        
        const itemIndex = cartItems.findIndex(item => String(item.id) === String(itemId));
        if (itemIndex !== -1) {
            cartItems.splice(itemIndex, 1);
            cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);
            
            // Save to localStorage
            localStorage.setItem('techHavenCart', JSON.stringify(cartItems));
            localStorage.setItem('techHavenCartCount', cartCount.toString());
            
            // Update UI
            updateCartUI();
            console.log('✅ Guest cart item removed');
        }
    };

    // Toggle cart sidebar
    function toggleCart() {
        const cartSidebar = document.getElementById('cartSidebar');
        const cartOverlay = document.getElementById('cartOverlay');
        
        if (cartSidebar && cartOverlay) {
            cartSidebar.classList.toggle('active');
            cartOverlay.classList.toggle('active');
        }
    }
    
    // Export toggleCart immediately for early access from shop.js
    window.toggleCart = toggleCart;

    // Setup cart event listeners using event delegation
    function setupCartEventListeners() {
        console.log('🔧 Setting up cart event listeners');
        
        // Remove any existing cart event listener to prevent duplicates
        const cartItemsContainer = document.getElementById('cartItems');
        if (cartItemsContainer) {
            // Remove existing listeners by cloning the container
            const newContainer = cartItemsContainer.cloneNode(true);
            cartItemsContainer.parentNode.replaceChild(newContainer, cartItemsContainer);
            
            console.log('✅ Cart event listeners container reset');
            
            // Add single event listener using event delegation
            newContainer.addEventListener('click', function(e) {
                console.log('🖱️ Cart button clicked:', e.target);
                e.preventDefault();
                e.stopPropagation();
                
                const target = e.target.closest('button');
                if (!target) {
                    console.log('❌ No button target found');
                    return;
                }
                
                const cartId = target.getAttribute('data-cart-id');
                const productId = target.getAttribute('data-product-id') || target.closest('.cart-item').getAttribute('data-product-id');
                
                console.log('🎯 Button data:', {
                    cartId: cartId,
                    productId: productId,
                    buttonClass: target.className
                });
                
                if (target.classList.contains('remove-item')) {
                    console.log('🗑️ Remove button clicked for cart ID:', cartId);
                    removeFromCartById(cartId);
                } else if (target.classList.contains('decrease-qty')) {
                    const currentQuantity = parseInt(target.getAttribute('data-current-quantity'));
                    const newQuantity = Math.max(0, currentQuantity - 1);
                    console.log('🔽 Decrease quantity clicked:');
                    console.log('  - Cart ID:', cartId);
                    console.log('  - Current quantity:', currentQuantity);
                    console.log('  - New quantity:', newQuantity);
                    
                    if (newQuantity <= 0) {
                        console.log('⚠️ Quantity is 0, removing item');
                        removeFromCartById(cartId);
                    } else {
                        console.log('📉 Updating quantity to:', newQuantity);
                        updateCartQuantityById(cartId, newQuantity);
                    }
                } else if (target.classList.contains('increase-qty')) {
                    const currentQuantity = parseInt(target.getAttribute('data-current-quantity'));
                    const newQuantity = currentQuantity + 1;
                    console.log('🔼 Increase quantity clicked:');
                    console.log('  - Cart ID:', cartId);
                    console.log('  - Current quantity:', currentQuantity);
                    console.log('  - New quantity:', newQuantity);
                    console.log('📈 Updating quantity to:', newQuantity);
                    updateCartQuantityById(cartId, newQuantity);
                } else {
                    console.log('❓ Unknown button clicked:', target.className);
                }
            });
            
            console.log('✅ Cart event listeners attached successfully');
        } else {
            console.error('❌ Cart items container not found!');
        }
    }
    
    // Export setupCartEventListeners for use in other scripts
    // DISABLED: Using simple cart listeners from shop.ejs instead
    // window.setupCartEventListeners = setupCartEventListeners;

    // Show cart notification
    function showCartNotification(productName) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'cart-notification';
        notification.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>Đã thêm "${productName}" vào giỏ hàng!</span>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            z-index: 10000;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            max-width: 300px;
            font-weight: 500;
        `;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Auto remove
        setTimeout(() => {
            notification.style.transform = 'translateX(400px)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Proceed to checkout
    function proceedToCheckout() {
        console.log('🛒 proceedToCheckout called from script.js');
        
        // Sync cart state from localStorage if needed (for guest users)
        if (!window.currentUser) {
            const savedCart = localStorage.getItem('techHavenCart');
            if (savedCart) {
                try {
                    const parsedCart = JSON.parse(savedCart);
                    cartItems = parsedCart;
                    cartCount = cartItems.reduce((total, item) => total + (item.quantity || 1), 0);
                    console.log('🔄 Synced cart from localStorage:', cartItems.length, 'items');
                } catch (e) {
                    console.error('❌ Failed to sync cart from localStorage:', e);
                }
            }
        }
        
        // Use window.cartItems (synced from shop.ejs) if available, fallback to local cartItems
        const activeCartItems = window.cartItems || cartItems;
        console.log('🛒 local cartItems.length:', cartItems.length);
        console.log('🛒 window.cartItems.length:', window.cartItems ? window.cartItems.length : 'undefined');
        console.log('🛒 using activeCartItems.length:', activeCartItems.length);
        
        if (activeCartItems.length === 0) {
            console.log('❌ Cart is empty, checkout aborted');
            alert('Giỏ hàng của bạn đang trống!');
            return;
        }
        
        // Close cart sidebar and overlay completely to avoid overlapping
        const cartSidebar = document.getElementById('cartSidebar');
        const cartOverlay = document.getElementById('cartOverlay');
        if (cartSidebar) {
            cartSidebar.classList.remove('active');
            console.log('🔄 Cart sidebar closed before opening checkout');
        }
        if (cartOverlay) {
            cartOverlay.classList.remove('active');
            console.log('🔄 Cart overlay closed before opening checkout');
        }
        
        const checkoutModal = document.getElementById('checkoutModal');
        console.log('🔍 checkoutModal element:', checkoutModal);
        
        if (checkoutModal) {
            console.log('✅ Modal found, adding active class');
            checkoutModal.classList.add('active');
            console.log('🔍 Modal classes after add:', checkoutModal.className);
            console.log('🔍 Modal style display:', checkoutModal.style.display);
            console.log('🔍 Modal computed display:', window.getComputedStyle(checkoutModal).display);
            
            updateOrderSummary();
            // Auto-fill user information if logged in
            fillUserInformationIfLoggedIn();
        } else {
            console.error('❌ checkoutModal element not found in DOM!');
        }
    }

    // Close checkout modal
    function closeCheckoutModal() {
        const checkoutModal = document.getElementById('checkoutModal');
        if (checkoutModal) {
            checkoutModal.classList.remove('active');
            console.log('🔄 Checkout modal closed');
        }
        
        // Also remove any remaining overlay effects
        const overlays = document.querySelectorAll('.modal-overlay.active');
        overlays.forEach(overlay => {
            if (overlay.id === 'checkoutModal') {
                overlay.classList.remove('active');
                console.log('🔄 Checkout modal overlay removed');
            }
        });
        
        // Ensure body scroll is restored
        document.body.style.overflow = '';
    }

    // Update order summary
    function updateOrderSummary() {
        const orderSummaryItems = document.getElementById('orderSummaryItems');
        const subtotalAmount = document.getElementById('subtotalAmount');
        const finalTotal = document.getElementById('finalTotal');
        
        // Use window.cartItems (synced from shop.ejs) if available, fallback to local cartItems
        const activeCartItems = window.cartItems || cartItems;
        console.log('📋 updateOrderSummary - using activeCartItems.length:', activeCartItems.length);
        
        if (orderSummaryItems) {
            console.log('📦 Cart items for order summary:', activeCartItems);
            orderSummaryItems.innerHTML = activeCartItems.map(item => {
                console.log('🛒 Processing cart item:', item);
                
                // Get safe price value
                let priceValue = 0;
                if (item.numericPrice && typeof item.numericPrice === 'number') {
                    priceValue = item.numericPrice;
                } else if (item.productPrice && typeof item.productPrice === 'number') {
                    priceValue = item.productPrice;
                } else if (item.price && typeof item.price === 'string') {
                    priceValue = parseInt(item.price.replace(/[^\d]/g, '')) || 0;
                } else if (item.price && typeof item.price === 'number') {
                    priceValue = item.price;
                } else if (item.productPrice && typeof item.productPrice === 'string') {
                    priceValue = parseInt(item.productPrice.replace(/[^\d]/g, '')) || 0;
                } else {
                    console.warn('❌ No valid price found for item:', item);
                    priceValue = 0;
                }
                
                const quantity = item.quantity || 1;
                const itemTotal = priceValue * quantity;
                
                console.log(`💰 Item: ${item.name}, Price: ${priceValue}, Quantity: ${quantity}, Total: ${itemTotal}`);
                
                return `
                    <div class="order-item">
                        <span class="order-item-name">${item.name || 'Unknown Product'} x${quantity}</span>
                        <span class="order-item-price">${formatPrice(itemTotal)} VNĐ</span>
                    </div>
                `;
            }).join('');
        }
        
        const subtotal = calculateCartTotal();
        const shipping = subtotal > 0 ? 50000 : 0;
        const total = subtotal + shipping;
        
        if (subtotalAmount) subtotalAmount.textContent = formatPrice(subtotal) + ' VNĐ';
        if (finalTotal) finalTotal.textContent = formatPrice(total) + ' VNĐ';
        
        // Update shipping amount
        const shippingAmount = document.getElementById('shippingAmount');
        if (shippingAmount) shippingAmount.textContent = formatPrice(shipping) + ' VNĐ';
    }

    // Complete order
    function completeOrder() {
        console.log('🛒 Completing order...');
        
        // Check if user is logged in or OTP verified
        if (!window.currentUser && !window.otpVerificationResult) {
            console.log('🔐 Guest user detected - requiring OTP verification');
            
            // Get customer email from form
            const customerEmailEl = document.getElementById('customerEmail');
            const customerEmail = customerEmailEl ? customerEmailEl.value : '';
            
            if (!customerEmail) {
                alert('Vui lòng nhập email để tiếp tục');
                customerEmailEl?.focus();
                return;
            }
            
            // Show OTP modal for guest checkout
            if (typeof window.showOtpModal === 'function') {
                window.showOtpModal(customerEmail);
            } else {
                alert('Tính năng xác thực OTP không khả dụng');
            }
            return;
        }
        
        // Get form elements with error handling
        const customerNameEl = document.getElementById('customerName');
        const customerPhoneEl = document.getElementById('customerPhone');
        const customerEmailEl = document.getElementById('customerEmail');
        const paymentMethodEl = document.querySelector('input[name="paymentMethod"]:checked');

        // Check if basic elements exist
        if (!customerNameEl || !customerPhoneEl || !customerEmailEl) {
            console.error('Basic form elements are missing!');
            alert('Có lỗi xảy ra với form. Vui lòng thử lại!');
            return;
        }

        // Get basic values
        const customerName = customerNameEl.value;
        const customerPhone = customerPhoneEl.value;
        const customerEmail = customerEmailEl.value;
        const paymentMethod = paymentMethodEl ? paymentMethodEl.value : 'cash';
        
        // Check shipping address - either selected or new input
        const selectedAddressDisplay = document.getElementById('selectedAddressDisplay');
        const isUsingSelectedAddress = selectedAddressDisplay && selectedAddressDisplay.style.display !== 'none';
        
        let shippingAddress, shippingCity, shippingDistrict;
        
        if (isUsingSelectedAddress) {
            // User is using a pre-selected address
            const selectedAddressText = document.getElementById('selectedAddressText');
            if (selectedAddressText) {
                const addressText = selectedAddressText.textContent || selectedAddressText.innerText;
                // Extract address info from the display text
                const addressLines = addressText.split('\n').map(line => line.trim()).filter(line => line);
                if (addressLines.length >= 2) {
                    shippingAddress = addressLines[0].replace(/<\/?strong>/g, '');
                    const cityDistrict = addressLines[1];
                    const parts = cityDistrict.split(',').map(part => part.trim());
                    if (parts.length >= 2) {
                        shippingDistrict = parts[0];
                        shippingCity = parts[1];
                    } else {
                        shippingCity = cityDistrict;
                        shippingDistrict = '';
                    }
                } else {
                    shippingAddress = addressText.replace(/<\/?strong>/g, '');
                    shippingCity = 'N/A';
                    shippingDistrict = 'N/A';
                }
                console.log('📍 Using selected address:', { shippingAddress, shippingCity, shippingDistrict });
            } else {
                alert('Không thể lấy thông tin địa chỉ đã chọn. Vui lòng thử lại!');
                return;
            }
        } else {
            // User is entering new address
            const shippingAddressEl = document.getElementById('newShippingAddress');
            const shippingCityEl = document.getElementById('newShippingCity');
            const shippingDistrictEl = document.getElementById('newShippingDistrict');
            
            if (!shippingAddressEl || !shippingCityEl || !shippingDistrictEl) {
                console.error('New address form elements are missing!');
                alert('Có lỗi xảy ra với form địa chỉ. Vui lòng thử lại!');
                return;
            }
            
            shippingAddress = shippingAddressEl.value;
            shippingCity = shippingCityEl.value;
            shippingDistrict = shippingDistrictEl.value;
            
            console.log('📝 Using new address:', { shippingAddress, shippingCity, shippingDistrict });
        }
        
        // Validate required fields
        if (!customerName || !customerPhone || !customerEmail || !shippingAddress || !shippingCity) {
            alert('Vui lòng điền đầy đủ thông tin!');
            return;
        }
        
        // Simulate order processing
        const loadingOverlay = document.createElement('div');
        loadingOverlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10001;
            color: white;
            font-size: 1.2rem;
        `;
        loadingOverlay.innerHTML = `
            <div style="text-align: center;">
                <div style="width: 50px; height: 50px; border: 3px solid #fff; border-top: 3px solid transparent; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 1rem;"></div>
                <div>Đang xử lý đơn hàng...</div>
            </div>
        `;
        
        // Add spin animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
        
        document.body.appendChild(loadingOverlay);
        
        // Simulate processing time
        setTimeout(async () => {
            document.body.removeChild(loadingOverlay);
            document.head.removeChild(style);

            // Track coupon usage if coupon was applied
            const appliedCoupon = window.currentAppliedCoupon;
            if (appliedCoupon) {
                try {
                    // Get user token and user ID from current user or OTP verification
                    let token = null;
                    let userId = null;
                    
                    if (window.currentUser && window.currentUser.uid) {
                        userId = window.currentUser.uid;
                        
                        // Try to get Firebase ID token if available
                        if (window.getIdToken && typeof window.getIdToken === 'function') {
                            try {
                                token = await window.getIdToken();
                            } catch (error) {
                                console.warn('Could not get Firebase token, using fallback auth');
                            }
                        }
                        
                        // Fallback to stored auth tokens
                        if (!token) {
                            token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken') || 'fallback-token';
                        }
                    } else if (window.otpVerificationResult && window.otpVerificationResult.userId) {
                        // Use OTP verified user
                        userId = window.otpVerificationResult.userId;
                        token = window.otpVerificationResult.customToken || 'otp-verified-token';
                        console.log('💾 Using OTP verified user for coupon:', userId);
                    }
                    
                    if (token && userId) {
                        console.log('💾 Saving coupon usage for user:', userId);
                        
                        // Use window.cartItems (synced from shop.ejs) if available, fallback to local cartItems
                        const activeCartItems = window.cartItems || cartItems;
                        console.log('📝 completeOrder - using activeCartItems.length:', activeCartItems.length);
                        
                        const orderData = {
                            customerName,
                            customerPhone,
                            customerEmail,
                            shippingAddress,
                            shippingCity,
                            shippingDistrict,
                            paymentMethod,
                            cartItems: activeCartItems,
                            orderTotal: calculateCartTotal() + 50000,
                            orderDate: new Date().toISOString()
                        };
                        
                        const response = await fetch('/api/coupon-usage', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': `Bearer ${token}`
                            },
                            body: JSON.stringify({
                                couponId: appliedCoupon.id,
                                userId: userId,
                                orderData: orderData
                            })
                        });

                        if (response.ok) {
                            const usageResult = await response.json();
                            console.log('✅ Coupon usage saved successfully:', usageResult);
                            
                            // Store couponUserId for bill creation
                            if (usageResult.couponUserId) {
                                window.currentCouponUserId = usageResult.couponUserId;
                                console.log('💾 Stored couponUserId:', usageResult.couponUserId);
                            }
                        } else {
                            const errorData = await response.json();
                            console.warn('⚠️ Failed to save coupon usage:', errorData.error);
                        }
                    } else {
                        console.warn('⚠️ No user token or ID found, cannot save coupon usage');
                    }
                } catch (error) {
                    console.warn('⚠️ Error saving coupon usage:', error);
                }

                // Clear applied coupon
                window.currentAppliedCoupon = null;
            }
            
            // Process order completion - clear cart and update stock
            try {
                const userId = window.currentUser?.uid;
                if (userId && cartItems.length > 0) {
                    console.log('🛒 Processing order completion...');
                    
                    // Prepare order items with product IDs and quantities
                    const orderItems = cartItems.map(item => ({
                        productId: item.id,
                        quantity: item.quantity || 1,
                        name: item.name,
                        price: item.price
                    }));
                    
                    const response = await fetch('/api/order/complete', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            userId: userId,
                            orderItems: orderItems
                        })
                    });
                    
                    if (response.ok) {
                        const result = await response.json();
                        console.log('✅ Order completion processed:', result.message);
                        console.log(`📦 Processed ${result.itemsProcessed} items`);
                    } else {
                        const errorData = await response.json();
                        console.warn('⚠️ Failed to process order completion:', errorData.error);
                    }
                } else {
                    console.log('ℹ️ Skipping order completion: no user or empty cart');
                }
            } catch (error) {
                console.warn('⚠️ Error processing order completion:', error);
            }
            
            // Show success notification with better styling
            const successNotification = document.createElement('div');
            successNotification.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: linear-gradient(135deg, #4CAF50, #45a049);
                color: white;
                padding: 30px 40px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                z-index: 10002;
                text-align: center;
                font-family: 'Inter', sans-serif;
                max-width: 400px;
                width: 90%;
            `;
            
            const orderTotal = calculateCartTotal() + 50000;
            const orderNumber = `TH${Date.now()}`;
            
            successNotification.innerHTML = `
                <div style="font-size: 3rem; margin-bottom: 1rem;">🎉</div>
                <h3 style="margin: 0 0 1rem 0; font-size: 1.5rem; font-weight: 600;">Thanh toán thành công!</h3>
                <p style="margin: 0.5rem 0; opacity: 0.9;">Mã đơn hàng: <strong>${orderNumber}</strong></p>
                <p style="margin: 0.5rem 0; opacity: 0.9;">Tổng tiền: <strong>${formatPrice(orderTotal)} VNĐ</strong></p>
                <p style="margin: 1rem 0 0 0; font-size: 0.9rem; opacity: 0.8;">Chúng tôi sẽ liên hệ với bạn trong vòng 24h để xác nhận đơn hàng.</p>
                <button onclick="this.parentElement.remove()" style="
                    margin-top: 1.5rem;
                    padding: 10px 20px;
                    background: rgba(255,255,255,0.2);
                    border: 1px solid rgba(255,255,255,0.3);
                    border-radius: 8px;
                    color: white;
                    cursor: pointer;
                    font-size: 0.9rem;
                    transition: all 0.3s ease;
                " onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.2)'">
                    Đóng
                </button>
            `;
            
            document.body.appendChild(successNotification);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (successNotification.parentElement) {
                    successNotification.remove();
                }
            }, 5000);
            
            // Create bill before clearing cart
            const finalOrderTotal = calculateCartTotal() + 50000; // Include shipping
            // Use window.cartItems (synced from shop.ejs) if available, fallback to local cartItems
            const activeCartItemsForBill = window.cartItems || cartItems;
            console.log('📝 createBill - using activeCartItemsForBill.length:', activeCartItemsForBill.length);
            
            await createBill({
                userId: window.currentUser?.uid || window.otpVerificationResult?.userId || 'guest',
                products: activeCartItemsForBill.map(item => ({
                    id: item.id,
                    name: item.name,
                    price: item.price,
                    quantity: item.quantity || 1
                })),
                totalAmount: finalOrderTotal,
                couponUserId: appliedCoupon ? (window.currentCouponUserId || appliedCoupon.couponUserId) : null,
                customerInfo: {
                    name: customerName,
                    phone: customerPhone,
                    email: customerEmail,
                    address: shippingAddress,
                    city: shippingCity,
                    district: shippingDistrict,
                    paymentMethod: paymentMethod
                },
                // Add individual customer fields for easier access
                name: customerName,
                email: customerEmail,
                phone: customerPhone,
                address: `${shippingAddress}, ${shippingDistrict}, ${shippingCity}`
            });
            
            // Reset cart and close modal
            cartItems = [];
            cartCount = 0;
            
            // Also clear synced cart data
            if (window.cartItems) {
                window.cartItems = [];
            }
            if (window.cart) {
                window.cart = [];
            }
            
            // Clear cart in Firebase if user is logged in
            if (window.currentUser && window.clearCartInFirebase) {
                try {
                    const token = await window.getIdToken();
                    if (token) {
                        await window.clearCartInFirebase(token);
                        console.log('🔥 Cart cleared in Firebase');
                    }
                } catch (error) {
                    console.error('❌ Error clearing cart in Firebase:', error);
                }
            }
            
            updateCartUI();
            saveCartToStorage();
            
            // Sync cart everywhere to ensure all systems are updated
            if (window.syncCartEverywhere) {
                window.syncCartEverywhere();
            }
            
            closeCheckoutModal();
            
            // Reset form
            if (document.getElementById('customerName')) document.getElementById('customerName').value = '';
            if (document.getElementById('customerPhone')) document.getElementById('customerPhone').value = '';
            if (document.getElementById('customerEmail')) document.getElementById('customerEmail').value = '';
            
            // Reset new address form if exists
            if (document.getElementById('newShippingAddress')) document.getElementById('newShippingAddress').value = '';
            if (document.getElementById('newShippingCity')) document.getElementById('newShippingCity').value = '';
            if (document.getElementById('newShippingDistrict')) document.getElementById('newShippingDistrict').value = '';
            
        }, 2000);
    }

    // Create bill function
    async function createBill(billData) {
        try {
            console.log('📋 Creating bill with data:', billData);
            
            const response = await fetch('/api/bills', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(billData)
            });
            
            if (response.ok) {
                const result = await response.json();
                console.log('✅ Bill created successfully with ID:', result.billId);
                return result;
            } else {
                const errorData = await response.json();
                console.error('❌ Failed to create bill:', errorData.error);
                throw new Error(errorData.error || 'Failed to create bill');
            }
        } catch (error) {
            console.error('❌ Error creating bill:', error);
            // Don't throw error to prevent breaking checkout flow
            // Just log the error and continue
            return null;
        }
    }

    // Build PC function
    function proceedToBuild() {
        alert('🔧 Tính năng xây dựng PC sẽ sớm có mặt!\n\nBạn có thể liên hệ hotline 1800-1234 để được tư vấn trực tiếp từ chuyên gia của chúng tôi.');
    }

    // Search function
    function toggleSearch() {
        const searchOverlay = document.getElementById('searchOverlay');
        const searchInput = document.getElementById('searchInput');
        
        if (searchOverlay) {
            searchOverlay.classList.toggle('active');
            if (searchOverlay.classList.contains('active') && searchInput) {
                searchInput.focus();
            }
        }
    }

    // Search functionality
    let searchProducts = [
        { id: 1, name: "RTX 4070 Graphics Card", price: "18.990.000", category: "VGA", image: "/images/gpu1.jpg" },
        { id: 2, name: "MSI Katana 17 B13V", price: "28.990.000", category: "Laptop", image: "/images/laptop.jpg" },
        { id: 3, name: "Acer Predator Helios 300", price: "32.990.000", category: "Laptop", image: "/images/laptop.jpg" },
        { id: 4, name: "HP Omen 16-k0000", price: "26.990.000", category: "Laptop", image: "/images/laptop.jpg" },
        { id: 5, name: "Gaming Desktop PC", price: "45.990.000", category: "PC", image: "/images/pc-hero.png" },
        { id: 6, name: "Mechanical Gaming Keyboard", price: "2.490.000", category: "Phụ kiện", image: "/images/keyboard.jpg" },
        { id: 7, name: "Gaming Mouse Pro", price: "1.990.000", category: "Phụ kiện", image: "/images/keyboard.jpg" },
        { id: 8, name: "RTX 4080 Graphics Card", price: "24.990.000", category: "VGA", image: "/images/gpu2.jpg" }
    ];

    function performSearch() {
        const query = document.getElementById('searchInput').value.toLowerCase().trim();
        const suggestionsContainer = document.getElementById('searchSuggestions');
        
        if (!query) {
            suggestionsContainer.innerHTML = '';
            return;
        }

        const filteredProducts = searchProducts.filter(product => 
            product.name.toLowerCase().includes(query) ||
            product.category.toLowerCase().includes(query)
        );

        displaySearchSuggestions(filteredProducts);
    }

    function displaySearchSuggestions(products) {
        const suggestionsContainer = document.getElementById('searchSuggestions');
        
        if (products.length === 0) {
            suggestionsContainer.innerHTML = `
                <div class="suggestion-item">
                    <i class="fas fa-search"></i>
                    <div class="suggestion-text">
                        <h4>Không tìm thấy sản phẩm</h4>
                        <p>Thử từ khóa khác hoặc duyệt danh mục sản phẩm</p>
                    </div>
                </div>
            `;
            return;
        }

        const suggestionsHTML = products.map(product => `
            <div class="suggestion-item" onclick="selectProduct(${product.id})">
                <i class="fas fa-${getProductIcon(product.category)}"></i>
                <div class="suggestion-text">
                    <h4>${product.name}</h4>
                    <p>${new Intl.NumberFormat('vi-VN').format(product.price)} VNĐ - ${product.category}</p>
                </div>
            </div>
        `).join('');

        suggestionsContainer.innerHTML = suggestionsHTML;
    }

    function getProductIcon(category) {
        const icons = {
            'Laptop': 'laptop',
            'VGA': 'memory',
            'PC': 'desktop',
            'Phụ kiện': 'keyboard'
        };
        return icons[category] || 'cube';
    }

    function selectProduct(productId) {
        // Navigate to product detail page or add to cart
        window.location.href = `/product/${productId}`;
    }

    // Initialize search event listeners
    function initializeSearch() {
        const searchInput = document.getElementById('searchInput');
        const searchBtn = document.querySelector('.search-btn');
        const searchOverlay = document.getElementById('searchOverlay');

        if (searchInput) {
            searchInput.addEventListener('input', performSearch);
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    performSearch();
                }
            });
        }

        if (searchBtn) {
            searchBtn.addEventListener('click', performSearch);
        }

        // Close search when clicking outside
        if (searchOverlay) {
            searchOverlay.addEventListener('click', function(e) {
                if (e.target === searchOverlay) {
                    toggleSearch();
                }
            });
        }

        // Close search with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && searchOverlay && searchOverlay.classList.contains('active')) {
                toggleSearch();
            }
        });
    }

    // Save cart to localStorage and Firebase (if user is logged in)
    function saveCartToStorage() {
        // Always save to localStorage
        localStorage.setItem('techHavenCart', JSON.stringify(cartItems));
        localStorage.setItem('techHavenCartCount', cartCount.toString());
        
        // Also save to Firebase if user is authenticated
        saveCartToFirebase();
    }
    
    // Save cart to Firebase Firestore
    async function saveCartToFirebase() {
        if (!window.currentUser) {
            console.log('👤 No authenticated user - cart saved locally only');
            return;
        }
        
        try {
            console.log('🔄 Saving cart to Firebase...');
            console.log('Cart items to save:', cartItems);
            
            // Check if user is manual (no Firebase ID token) or Google user
            let idToken = null;
            let isManualUser = false;
            
            if (window.getIdToken) {
                try {
                    idToken = await window.getIdToken();
                } catch (error) {
                    console.log('⚠️ Could not get Firebase ID token, treating as manual user');
                }
            }
            
            if (!idToken && window.currentUser.provider === 'manual') {
                isManualUser = true;
                console.log('🔑 Using manual user cart endpoint for user:', window.currentUser.uid);
            } else if (!idToken) {
                console.warn('⚠️ No ID token available and not manual user');
                return;
            }
            
            if (isManualUser) {
                // Use manual user cart endpoint
                const response = await fetch(`/api/cart/by-uid/${window.currentUser.uid}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        items: cartItems.map(item => ({
                            productId: String(item.id),
                            quantity: item.quantity
                        }))
                    })
                });
                
                if (response.ok) {
                    console.log('✅ Cart saved to Firebase (manual user)');
                } else {
                    const error = await response.text();
                    console.error('❌ Failed to save cart (manual user):', error);
                }
            } else {
                // Clear existing cart first (optional - you can skip this if you want to merge)
                // await clearCartInFirebase(idToken);
                
                // Add each item individually to Firebase (Google user)
                for (const item of cartItems) {
                    const response = await fetch('/api/cart', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${idToken}`
                        },
                        body: JSON.stringify({
                            userId: window.currentUser.uid,
                            productId: String(item.id),
                            productName: item.name,
                            productPrice: item.numericPrice,
                            productImage: item.image,
                            quantity: item.quantity
                        })
                    });
                    
                    if (response.ok) {
                        console.log(`✅ Saved item "${item.name}" to Firebase`);
                    } else {
                        const error = await response.text();
                        console.error(`❌ Failed to save item "${item.name}":`, error);
                    }
                }
                
                console.log('✅ All cart items saved to Firebase');
            }
        } catch (error) {
            console.error('❌ Error saving cart to Firebase:', error);
        }
    }

    // Clear cart function (for testing)
    function clearCart() {
        cartItems = [];
        cartCount = 0;
        updateCartUI();
        saveCartToStorage();
        console.log('Cart cleared');
    }

    // Load cart from localStorage and Firebase (if user is logged in)
    function loadCartFromStorage() {
        // First load from localStorage (immediate)
        const savedCart = localStorage.getItem('techHavenCart');
        const savedCount = localStorage.getItem('techHavenCartCount');
        
        console.log('📦 Loading cart from storage:', {
            savedCart: savedCart,
            savedCount: savedCount,
            currentItems: cartItems.length,
            currentCount: cartCount
        });
        
        if (savedCart) {
            try {
                cartItems = JSON.parse(savedCart);
                console.log('✅ Parsed cart items:', cartItems);
            } catch (e) {
                console.error('❌ Failed to parse saved cart:', e);
                cartItems = [];
            }
        }
        
        if (savedCount) {
            cartCount = parseInt(savedCount) || 0;
        } else {
            // Recalculate count from items if no saved count
            cartCount = cartItems.reduce((total, item) => total + (item.quantity || 1), 0);
        }
        
        console.log('📊 Final cart state after loading:', {
            items: cartItems.length,
            count: cartCount,
            itemsArray: cartItems
        });
        
        // Force update UI
        updateCartUI();
        
        // Then try to load from Firebase (if user is authenticated)
        if (typeof loadCartFromFirebase === 'function') {
            loadCartFromFirebase();
        }
    }
    
    // Clear cart in Firebase (optional helper function)
    async function clearCartInFirebase(idToken) {
        try {
            const response = await fetch(`/api/cart/user/${encodeURIComponent(window.currentUser.uid)}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${idToken}`
                }
            });
            
            if (response.ok) {
                console.log('✅ Firebase cart cleared');
            } else {
                console.log('ℹ️ Could not clear Firebase cart (maybe empty)');
            }
        } catch (error) {
            console.error('❌ Error clearing Firebase cart:', error);
        }
    }
    
    // Load cart from Firebase Firestore
    async function loadCartFromFirebase() {
        if (!window.currentUser) {
            console.log('👤 No authenticated user - using local cart only');
            return;
        }
        
        try {
            console.log('🔄 Loading cart from Firebase...');
            
            // Check if user is manual (no Firebase ID token) or Google user
            let idToken = null;
            let isManualUser = false;
            
            if (window.getIdToken) {
                try {
                    idToken = await window.getIdToken();
                } catch (error) {
                    console.log('⚠️ Could not get Firebase ID token, treating as manual user');
                }
            }
            
            if (!idToken && window.currentUser.provider === 'manual') {
                isManualUser = true;
                console.log('🔑 Using manual user cart endpoint for user:', window.currentUser.uid);
            } else if (!idToken) {
                console.warn('⚠️ No ID token available and not manual user');
                return;
            }
            
            let response;
            if (isManualUser) {
                // Use manual user cart endpoint
                response = await fetch(`/api/cart/by-uid/${window.currentUser.uid}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            } else {
                // Use regular cart endpoint
                response = await fetch(`/api/cart?uid=${encodeURIComponent(window.currentUser.uid)}`, {
                    method: 'GET',
                    headers: {
                        'Authorization': `Bearer ${idToken}`
                    }
                });
            }
            
            if (response.ok) {
                const result = await response.json();
                console.log('✅ Cart loaded from Firebase:', result);
                
                let firebaseCartItems = [];
                
                if (isManualUser && result.success && result.cart && result.cart.items) {
                    // Manual user cart format
                    firebaseCartItems = result.cart.items;
                } else if (result.cartItems && result.cartItems.length > 0) {
                    // Google user cart format
                    firebaseCartItems = result.cartItems;
                }
                
                if (firebaseCartItems.length > 0) {
                    // Firebase cart now only contains productId and quantity
                    // We need to fetch product details for each item
                    const enrichedCartItems = [];
                    
                    for (const item of firebaseCartItems) {
                        try {
                            // Try to fetch product details from API
                            const productResponse = await fetch(`/api/products/${item.productId}`);
                            let productData = null;
                            
                            if (productResponse.ok) {
                                const productResult = await productResponse.json();
                                if (productResult.success && productResult.product) {
                                    productData = productResult.product;
                                }
                            }
                            
                            // Create cart item with fetched product data or fallback
                            enrichedCartItems.push({
                                id: item.productId,
                                name: productData?.name || `Product ${item.productId}`,
                                price: formatPrice(productData?.price || 0),
                                numericPrice: productData?.price || 0,
                                quantity: item.quantity,
                                image: productData?.images?.[0] || productData?.imageUrl || getProductIcon(productData?.name || 'product'),
                                imageColor: '#667eea' // Default color for Firebase items
                            });
                            
                        } catch (productError) {
                            console.warn('⚠️ Could not fetch product details for', item.productId, '- using fallback data');
                            // Use fallback data if product fetch fails
                            enrichedCartItems.push({
                                id: item.productId,
                                name: `Product ${item.productId}`,
                                price: formatPrice(0),
                                numericPrice: 0,
                                quantity: item.quantity,
                                image: getProductIcon('product'),
                                imageColor: '#667eea'
                            });
                        }
                    }
                    
                    cartItems = enrichedCartItems;
                    cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);
                    
                    // Update UI and save to localStorage
                    updateCartUI();
                    localStorage.setItem('techHavenCart', JSON.stringify(cartItems));
                    localStorage.setItem('techHavenCartCount', cartCount.toString());
                    
                    console.log('🔄 Cart synced from Firebase to local storage with', cartItems.length, 'items');
                }
            } else {
                const errorText = await response.text();
                console.log('ℹ️ No cart found in Firebase or error loading:', errorText);
            }
        } catch (error) {
            console.error('❌ Error loading cart from Firebase:', error);
        }
    }

    // Function for non-index pages
    function setupNonIndexPage() {
        // Load cart from storage
        loadCartFromStorage();
        
        // Force initial cart UI update for guest users
        setTimeout(() => {
            console.log('🔄 Forcing initial cart UI update for guest users');
            updateCartUI();
        }, 100);
        
        // Setup common functionality
        setupProductNavigation();
        
        // Make functions global
        window.addToCart = addToCart;
        window.removeFromCart = removeFromCart;
        window.updateCartQuantity = updateCartQuantity;
        window.toggleCart = toggleCart;
        window.toggleSearch = toggleSearch;
        window.proceedToCheckout = proceedToCheckout;
        window.closeCheckoutModal = closeCheckoutModal;
        window.completeOrder = completeOrder;
        window.proceedToBuild = proceedToBuild;
        window.saveCartToStorage = saveCartToStorage;
        window.selectProduct = selectProduct;
        window.performSearch = performSearch;
        window.loadCartFromStorage = loadCartFromStorage;
        window.loadCartFromFirebase = loadCartFromFirebase;
        window.saveCartToFirebase = saveCartToFirebase;
        
        // Setup event listeners for common elements
        setupCommonEventListeners();
    }

    // Product section navigation
    function setupProductNavigation() {
        const navArrows = document.querySelectorAll('.nav-arrow');
        
        navArrows.forEach(arrow => {
            arrow.addEventListener('click', function() {
                const section = this.dataset.section;
                const container = document.getElementById(`${section}-container`);
                const scrollAmount = 300;
                
                if (container) {
                    if (this.classList.contains('prev')) {
                        container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
                    } else {
                        container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
                    }
                }
            });
        });
    }

    // Common event listeners
    function setupCommonEventListeners() {
        // Close cart when clicking overlay
        document.addEventListener('click', function(e) {
            if (e.target.id === 'cartOverlay') {
                toggleCart();
            }
        });

        // Close modal when clicking overlay
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal-overlay')) {
                closeCheckoutModal();
            }
        });

        // Mobile menu toggle
        const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
        if (mobileMenuToggle) {
            mobileMenuToggle.addEventListener('click', function() {
                const navMenu = document.querySelector('.nav-menu');
                if (navMenu) {
                    navMenu.classList.toggle('active');
                }
            });
        }
    }

    // Add enhanced updateCartIcon method to SmartCartManager if it exists
    if (window.smartCart && window.smartCart.updateCartIcon) {
        const originalUpdateCartIcon = window.smartCart.updateCartIcon;
        window.smartCart.updateCartIcon = function() {
            const cartBadge = document.getElementById('cartBadge');
            const cartIcon = document.querySelector('#cartIcon i.fas.fa-shopping-cart');
            const cartIconWrapper = document.getElementById('cartIcon');
            const cartStateTooltip = document.getElementById('cartStateTooltip');
            const mobileCartCount = document.getElementById('mobileCartCount');
            
            console.log('🎨 Enhanced SmartCartManager: Updating cart icon:', {
                count: this.cartData.count,
                source: this.lastUpdateSource,
                isLoggedIn: this.isLoggedIn
            });
            
            // Update cart badge
            if (cartBadge) {
                cartBadge.textContent = this.cartData.count;
                cartBadge.style.display = this.cartData.count > 0 ? 'flex' : 'none';
                
                // Add visual indicator for data source
                cartBadge.classList.remove('firebase-data', 'local-data');
                cartBadge.classList.add(this.lastUpdateSource === 'firebase' ? 'firebase-data' : 'local-data');
                cartBadge.title = this.lastUpdateSource === 'firebase' ? 'Dữ liệu từ Cloud' : 'Dữ liệu cục bộ';
            }
            
            // Update cart icon wrapper classes
            if (cartIconWrapper) {
                cartIconWrapper.classList.remove('has-firebase-data', 'has-local-data');
                cartIconWrapper.classList.add(this.lastUpdateSource === 'firebase' ? 'has-firebase-data' : 'has-local-data');
            }
            
            // Update tooltip
            if (cartStateTooltip) {
                const tooltip = this.lastUpdateSource === 'firebase' 
                    ? `☁️ Dữ liệu Cloud (${this.cartData.count} sản phẩm)`
                    : `💾 Dữ liệu cục bộ (${this.cartData.count} sản phẩm)`;
                cartStateTooltip.textContent = tooltip;
            }
            
            // Update mobile cart count
            if (mobileCartCount) {
                mobileCartCount.textContent = this.cartData.count;
                mobileCartCount.classList.remove('firebase-data', 'local-data');
                mobileCartCount.classList.add(this.lastUpdateSource === 'firebase' ? 'firebase-data' : 'local-data');
            }
            
            // Update cart icon color to indicate data source
            if (cartIcon) {
                cartIcon.classList.remove('firebase-data', 'local-data');
                cartIcon.classList.add(this.lastUpdateSource === 'firebase' ? 'firebase-data' : 'local-data');
                cartIcon.title = this.lastUpdateSource === 'firebase' ? 'Giỏ hàng Cloud' : 'Giỏ hàng cục bộ';
            }
            
            // Update global cartItems and cartCount for compatibility
            cartItems.length = 0;
            cartItems.push(...this.cartData.items);
            cartCount = this.cartData.count;
        };
    }

    // Initialize SmartCartManager on page load
    setTimeout(async () => {
        if (window.smartCart) {
            // Check if user is already logged in
            const storedUser = localStorage.getItem('techHavenUser');
            if (storedUser) {
                try {
                    const user = JSON.parse(storedUser);
                    console.log('🔄 Found stored user, updating SmartCartManager:', user.name);
                    window.smartCart.setAuthStatus(true, user);
                } catch (error) {
                    console.warn('⚠️ Invalid stored user data');
                }
            } else {
                console.log('🔄 No stored user, refreshing cart from localStorage');
                await window.smartCart.refreshCartData();
            }
        }
    }, 1000);
    
    // Initialize all functions (only for index page)
    if (document.body.classList.contains('index-page')) {
        // Load cart from storage
        loadCartFromStorage();
        
        setupProductNavigation();
        setupCommonEventListeners();
        initializeSearch();
    } else {
        // Initialize search for other pages too
        setTimeout(initializeSearch, 100);
    }
    
    // Make functions global for all pages
    window.addToCart = addToCart;
    window.removeFromCart = removeFromCart;
    window.updateCartQuantity = updateCartQuantity;
    window.toggleCart = toggleCart;
    window.toggleSearch = toggleSearch;
    window.proceedToCheckout = proceedToCheckout;
    window.closeCheckoutModal = closeCheckoutModal;
    window.completeOrder = completeOrder;
    window.proceedToBuild = proceedToBuild;
    window.saveCartToStorage = saveCartToStorage;
    window.loadCartFromStorage = loadCartFromStorage;
    window.loadCartFromFirebase = loadCartFromFirebase;
    window.saveCartToFirebase = saveCartToFirebase;
    window.clearCart = clearCart;

    // Initialize mobile menu toggle for all pages
    setupCommonEventListeners();
});

// Navigate to product detail page
function goToProductDetail(productId) {
    console.log('Navigating to product detail:', productId);
    window.location.href = `/product/${productId}`;
}

// Admin Dropdown Functionality
function initializeAdminDropdown() {
    const adminDropdown = document.querySelector('.admin-dropdown');
    if (!adminDropdown) return;

    const dropdownToggle = adminDropdown.querySelector('.dropdown-toggle');
    const dropdownMenu = adminDropdown.querySelector('.dropdown-menu');

    if (!dropdownToggle || !dropdownMenu) return;
    
    console.log('🔧 Initializing admin dropdown...');

    // Remove any existing event listeners by cloning the element
    const newToggle = dropdownToggle.cloneNode(true);
    dropdownToggle.parentNode.replaceChild(newToggle, dropdownToggle);
    
    // Get the new toggle reference
    const toggle = adminDropdown.querySelector('.dropdown-toggle');

    // Handle click/touch events for dropdown toggle
    function toggleDropdown(e) {
        e.preventDefault();
        e.stopPropagation();
        
        console.log('📱 Admin dropdown toggle activated');
        
        // Close other dropdowns
        document.querySelectorAll('.admin-dropdown.active').forEach(dropdown => {
            if (dropdown !== adminDropdown) {
                dropdown.classList.remove('active');
            }
        });
        
        // Toggle current dropdown
        const isActive = adminDropdown.classList.contains('active');
        adminDropdown.classList.toggle('active');
        
        console.log(`Dropdown ${isActive ? 'closed' : 'opened'}`);
    }

    // Add both click and touch events for better mobile support
    toggle.addEventListener('click', toggleDropdown);
    toggle.addEventListener('touchend', function(e) {
        // Prevent both touchend and click from firing
        e.preventDefault();
        toggleDropdown(e);
    });
    
    // Add visual feedback for touch devices
    toggle.addEventListener('touchstart', function(e) {
        e.preventDefault();
        toggle.style.transform = 'scale(0.95)';
        toggle.style.opacity = '0.8';
    });
    
    toggle.addEventListener('touchend', function() {
        setTimeout(() => {
            toggle.style.transform = '';
            toggle.style.opacity = '';
        }, 150);
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!adminDropdown.contains(e.target)) {
            adminDropdown.classList.remove('active');
        }
    });
    
    // Handle touch outside for mobile
    document.addEventListener('touchend', function(e) {
        if (!adminDropdown.contains(e.target)) {
            adminDropdown.classList.remove('active');
        }
    });

    // Close dropdown on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            adminDropdown.classList.remove('active');
        }
    });

    // Handle dropdown menu clicks
    dropdownMenu.addEventListener('click', function(e) {
        const link = e.target.closest('a');
        if (link && link.getAttribute('href') !== '#') {
            // Allow normal navigation for actual links
            adminDropdown.classList.remove('active');
        }
    });
    
    // Add touch support for menu items
    const menuLinks = dropdownMenu.querySelectorAll('a');
    menuLinks.forEach(link => {
        link.addEventListener('touchstart', function() {
            this.style.transform = 'translateX(10px)';
            this.style.background = 'rgba(107, 70, 193, 0.1)';
        });
        
        link.addEventListener('touchend', function() {
            setTimeout(() => {
                this.style.transform = '';
                this.style.background = '';
            }, 200);
        });
    });
    
    console.log('✅ Admin dropdown initialized with mobile support');
}

// Initialize admin dropdown after DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Add small delay to ensure all elements are rendered
    setTimeout(initializeAdminDropdown, 100);
});

// Make navigation function globally available
window.goToProductDetail = goToProductDetail;

// =====================================
// PRODUCT VIEW TOGGLE FUNCTIONALITY
// =====================================

// Initialize view toggle functionality
function initializeViewToggle() {
    const viewButtons = document.querySelectorAll('.view-btn');
    const productsGrid = document.querySelector('.products-grid');
    
    if (!viewButtons.length || !productsGrid) return;
    
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const viewType = this.getAttribute('data-view');
            
            // Remove active class from all buttons
            viewButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Toggle grid classes
            if (viewType === 'list') {
                productsGrid.classList.add('list-view');
                // Store user preference
                localStorage.setItem('productViewMode', 'list');
            } else {
                productsGrid.classList.remove('list-view');
                // Store user preference
                localStorage.setItem('productViewMode', 'grid');
            }
            
            console.log(`📊 Switched to ${viewType} view`);
        });
    });
    
    // Load saved view preference
    const savedView = localStorage.getItem('productViewMode') || 'grid';
    if (savedView === 'list') {
        const listButton = document.querySelector('.view-btn[data-view="list"]');
        const gridButton = document.querySelector('.view-btn[data-view="grid"]');
        
        if (listButton && gridButton) {
            gridButton.classList.remove('active');
            listButton.classList.add('active');
            productsGrid.classList.add('list-view');
        }
    }
}

// Initialize view toggle when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(initializeViewToggle, 100); // Small delay to ensure all elements are rendered
});

// =====================================
// LOGIN MODAL FUNCTIONALITY
// =====================================

let isLoginMode = true;

// Open login modal
function openLoginModal() {
    console.log('🔓 Mở login modal...');
    
    // Wait for DOM to be ready if it's not yet
    if (document.readyState === 'loading') {
        console.log('⏳ DOM đang load, đợi...');
        document.addEventListener('DOMContentLoaded', openLoginModal);
        return;
    }
    
    // Ensure modal exists (create if needed)
    const modal = ensureModalExists();
    
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Reset to login mode
        isLoginMode = true;
        showLoginForm();
        
        console.log('✅ Login modal đã mở');
        
        // Setup modal sau khi mở
        setTimeout(() => {
            setupLoginModal();
        }, 300);
        
    } else {
        console.error('❌ Không thể tạo login modal!');
        alert('Lỗi: Không thể mở modal đăng nhập!');
    }
}

// Close login modal
function closeLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
        // Clear form data
        clearForms();
    }
}

// Toggle between login and register
function toggleAuthMode() {
    isLoginMode = !isLoginMode;
    if (isLoginMode) {
        showLoginForm();
    } else {
        showRegisterForm();
    }
}

// Show login form
function showLoginForm() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const modalTitle = document.getElementById('modalTitle');
    const toggleText = document.getElementById('toggleText');
    
    if (loginForm) loginForm.style.display = 'block';
    if (registerForm) registerForm.style.display = 'none';
    if (modalTitle) modalTitle.textContent = 'Đăng Nhập';
    if (toggleText) {
        toggleText.innerHTML = 'Chưa có tài khoản? <a href="#" onclick="toggleAuthMode()">Đăng ký ngay</a>';
    }
    
    isLoginMode = true;
}

// Show register form
function showRegisterForm() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const modalTitle = document.getElementById('modalTitle');
    const toggleText = document.getElementById('toggleText');
    
    if (loginForm) loginForm.style.display = 'none';
    if (registerForm) registerForm.style.display = 'block';
    if (modalTitle) modalTitle.textContent = 'Đăng Ký';
    if (toggleText) {
        toggleText.innerHTML = 'Đã có tài khoản? <a href="#" onclick="toggleAuthMode()">Đăng nhập ngay</a>';
    }
    
    isLoginMode = false;
}

// Handle forgot password
function handleForgotPassword() {
    const email = document.getElementById('loginEmail').value;
    
    if (!email) {
        showNotification('Vui lòng nhập email trước khi reset mật khẩu', 'error');
        return;
    }
    
    if (!isValidEmail(email)) {
        showNotification('Email không hợp lệ', 'error');
        return;
    }
    
    // Show loading message
    showNotification('Đang gửi email reset mật khẩu...', 'info');
    
    // Send password reset email using Firebase Auth
    firebase.auth().sendPasswordResetEmail(email)
        .then(() => {
            console.log('✅ Password reset email sent to:', email);
            showNotification('Email reset mật khẩu đã được gửi! Vui lòng kiểm tra hộp thư của bạn.', 'success');
            showForgotPasswordModal(email);
        })
        .catch((error) => {
            console.error('❌ Password reset error:', error);
            let errorMessage = 'Có lỗi xảy ra khi gửi email reset mật khẩu';
            
            if (error.code === 'auth/user-not-found') {
                errorMessage = 'Không tìm thấy tài khoản với email này';
            } else if (error.code === 'auth/invalid-email') {
                errorMessage = 'Email không hợp lệ';
            } else if (error.code === 'auth/too-many-requests') {
                errorMessage = 'Quá nhiều yêu cầu. Vui lòng thử lại sau';
            }
            
            showNotification(errorMessage, 'error');
        });
}

// Show forgot password confirmation modal
function showForgotPasswordModal(email) {
    // Create modal overlay
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
    `;
    
    // Create modal content
    const modal = document.createElement('div');
    modal.className = 'forgot-password-modal';
    modal.style.cssText = `
        background: white;
        padding: 30px;
        border-radius: 10px;
        max-width: 500px;
        margin: 20px;
        text-align: center;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    `;
    
    modal.innerHTML = `
        <div style="font-size: 60px; margin-bottom: 20px;">🔒</div>
        <h3 style="color: #333; margin-bottom: 15px;">Email Reset Mật Khẩu Đã Gửi</h3>
        <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
            Chúng tôi đã gửi email chứa liên kết reset mật khẩu đến <strong>${email}</strong>. 
            Vui lòng kiểm tra hộp thư và click vào liên kết để đặt lại mật khẩu mới.
        </p>
        <div style="margin: 20px 0;">
            <button onclick="resendPasswordReset('${email}')" style="
                background: #007bff; 
                color: white; 
                border: none; 
                padding: 10px 20px; 
                border-radius: 5px; 
                cursor: pointer;
                margin-right: 10px;
            ">
                📧 Gửi Lại Email
            </button>
            <button onclick="closeForgotPasswordModal()" style="
                background: #6c757d; 
                color: white; 
                border: none; 
                padding: 10px 20px; 
                border-radius: 5px; 
                cursor: pointer;
            ">
                Đóng
            </button>
        </div>
        <p style="font-size: 12px; color: #999; margin-top: 15px;">
            Không thấy email? Kiểm tra thư mục spam hoặc click "Gửi Lại Email"
        </p>
    `;
    
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    
    // Make close function global
    window.closeForgotPasswordModal = function() {
        if (overlay && overlay.parentNode) {
            overlay.parentNode.removeChild(overlay);
        }
    };
    
    // Make resend function global
    window.resendPasswordReset = function(email) {
        handleForgotPassword();
    };
    
    // Close on overlay click
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            closeForgotPasswordModal();
        }
    });
}

// Clear all form data
function clearForms() {
    // Clear login form
    const loginEmail = document.getElementById('loginEmail');
    const loginPassword = document.getElementById('loginPassword');
    const rememberMe = document.getElementById('rememberMe');
    
    if (loginEmail) loginEmail.value = '';
    if (loginPassword) loginPassword.value = '';
    if (rememberMe) rememberMe.checked = false;
    
    // Clear register form
    const registerName = document.getElementById('registerName');
    const registerEmail = document.getElementById('registerEmail');
    const registerPhone = document.getElementById('registerPhone');
    const registerPassword = document.getElementById('registerPassword');
    const confirmPassword = document.getElementById('confirmPassword');
    const agreeTerms = document.getElementById('agreeTerms');
    
    if (registerName) registerName.value = '';
    if (registerEmail) registerEmail.value = '';
    if (registerPhone) registerPhone.value = '';
    if (registerPassword) registerPassword.value = '';
    if (confirmPassword) confirmPassword.value = '';
    if (agreeTerms) agreeTerms.checked = false;
}

// Handle login
function handleLogin() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const rememberMe = document.getElementById('rememberMe').checked;
    
    // Basic validation
    if (!email || !password) {
        showNotification('Vui lòng nhập đầy đủ email và mật khẩu!', 'error');
        return;
    }
    
    if (!isValidEmail(email)) {
        showNotification('Email không hợp lệ!', 'error');
        return;
    }
    
    // Show loading message
    showNotification('Đang đăng nhập...', 'info');
    
    // Send login request to backend
    fetch('/api/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            email: email,
            password: password
        })
    })
    .then(response => response.json())
    .then(async data => {
        if (data.success) {
            showNotification('Đăng nhập thành công!', 'success');
            closeLoginModal();
            clearForms();
            
            // Store user data in localStorage
            localStorage.setItem('techHavenUser', JSON.stringify(data.user));
            
            // If remember me is checked, store longer
            if (rememberMe) {
                localStorage.setItem('techHavenRememberMe', 'true');
            }
            
            // IMPORTANT: Sign in user to Firebase Auth client-side for manual users
            // This enables getIdToken() to work properly for address management
            try {
                if (window.signInWithEmailAndPassword) {
                    console.log('🔐 Signing in manual user to Firebase Auth client-side...');
                    await window.signInWithEmailAndPassword(email, password);
                    console.log('✅ Manual user signed in to Firebase Auth client-side');
                } else if (window.firebase && window.firebase.auth) {
                    console.log('🔐 Using Firebase v8 to sign in manual user...');
                    await window.firebase.auth().signInWithEmailAndPassword(email, password);
                    console.log('✅ Manual user signed in to Firebase Auth v8');
                }
            } catch (authError) {
                console.warn('⚠️ Could not sign in to Firebase Auth client-side:', authError);
                // Don't fail the whole login, just log warning
            }
            
            // Update UI to show logged in state
            updateUIForLoggedInUser(data.user);
            
            console.log('✅ Login successful:', data.user);
        } else {
            if (data.requiresVerification) {
                // Email not verified - show loading screen
                closeLoginModal();
                clearForms();
                showEmailVerificationLoadingScreen(data.email || email, { email: data.email || email });
                showNotification('Email chưa được xác thực. Vui lòng kiểm tra email và click vào link xác thực.', 'warning');
            } else {
                showNotification(data.error || 'Đăng nhập thất bại!', 'error');
            }
        }
    })
    .catch(error => {
        console.error('❌ Login error:', error);
        showNotification('Có lỗi xảy ra. Vui lòng thử lại!', 'error');
    });
}

// Handle register
function handleRegister() {
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const phone = document.getElementById('registerPhone').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const agreeTerms = document.getElementById('agreeTerms').checked;
    
    // Basic validation
    if (!name || !email || !phone || !password || !confirmPassword) {
        showNotification('Vui lòng điền đầy đủ thông tin!', 'error');
        return;
    }
    
    if (!isValidEmail(email)) {
        showNotification('Email không hợp lệ!', 'error');
        return;
    }
    
    if (!isValidPhone(phone)) {
        showNotification('Số điện thoại không hợp lệ! Vui lòng nhập số điện thoại Việt Nam (VD: 0901234567)', 'error');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Mật khẩu phải có ít nhất 6 ký tự!', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showNotification('Mật khẩu xác nhận không khớp!', 'error');
        return;
    }
    
    if (!agreeTerms) {
        showNotification('Vui lòng đồng ý với điều khoản dịch vụ!', 'error');
        return;
    }
    
    // Show loading message
    showNotification('Đang tạo tài khoản...', 'info');
    
    // Send registration request to backend
    fetch('/api/auth/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: name,
            email: email,
            phone: phone,
            password: password
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log('📋 Registration API Response:', data);
        if (data.success) {
            if (data.requiresVerification) {
                // User created but needs email verification
                console.log('✅ Registration successful:', data.user);
                
                // Close login modal and clear forms first
                closeLoginModal();
                clearForms();
                
                // Show email verification loading screen
                const userData = data.user || { email: email, uid: data.uid };
                showEmailVerificationLoadingScreen(email, userData);
                
                // Send email verification using Firebase client SDK
                sendEmailVerificationToUser(email, password)
                    .then(() => {
                        console.log('📧 Email verification sent successfully');
                        showNotification('Email xác thực đã được gửi thành công!', 'success');
                    })
                    .catch((error) => {
                        console.error('❌ Error sending email verification:', error);
                        showNotification('Có lỗi khi gửi email xác thực. Vui lòng thử lại.', 'warning');
                    });
                
            } else {
                // Old flow for backward compatibility
                showNotification('Đăng ký thành công!', 'success');
                closeLoginModal();
                clearForms();
                
                // Store user data in localStorage
                localStorage.setItem('techHavenUser', JSON.stringify(data.user));
                
                // Update UI to show logged in state
                updateUIForLoggedInUser(data.user);
            }
            
            console.log('✅ Registration successful:', data.user || data);
        } else {
            console.error('❌ Registration failed:', data);
            showNotification(data.error || data.message || 'Đăng ký thất bại!', 'error');
        }
    })
    .catch(error => {
        console.error('❌ Registration error:', error);
        showNotification('Có lỗi xảy ra. Vui lòng thử lại!', 'error');
    });
}

// Show email verification modal
// Send email verification using Firebase client SDK
async function sendEmailVerificationToUser(email, password) {
    try {
        console.log('🔐 Attempting to sign in user to send verification email...');
        
        // Sign in with the newly created user credentials using Firebase v8
        const userCredential = await firebase.auth().signInWithEmailAndPassword(email, password);
        const user = userCredential.user;
        
        console.log('✅ User signed in, now sending verification email...');
        
        // Send verification email using Firebase v8 with default settings
        await user.sendEmailVerification();
        console.log('📧 Email verification sent successfully to:', email, '(using Firebase default settings)');
        
        // Keep user signed in so we can check verification status
        console.log('✅ User remains signed in for verification checking');
        
        return true;
        
    } catch (error) {
        console.error('❌ Error in sendEmailVerificationToUser:', error);
        throw error;
    }
}

function showEmailVerificationModal(verificationLink, email) {
    // Create modal overlay
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
    `;
    
    // Create modal content
    const modal = document.createElement('div');
    modal.className = 'verification-modal';
    modal.style.cssText = `
        background: white;
        padding: 30px;
        border-radius: 10px;
        max-width: 500px;
        margin: 20px;
        text-align: center;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    `;
    
    modal.innerHTML = `
        <div style="font-size: 60px; margin-bottom: 20px;">📧</div>
        <h3 style="color: #333; margin-bottom: 15px;">Xác Thực Email</h3>
        <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
            Chúng tôi đã gửi một email xác thực đến <strong>${email}</strong>. Vui lòng kiểm tra hộp thư và click vào link xác thực để kích hoạt tài khoản.
        </p>
        <div style="margin: 20px 0;">
            <button onclick="resendVerificationEmail('${email}')" style="
                background: #007bff; 
                color: white; 
                border: none; 
                padding: 10px 20px; 
                border-radius: 5px; 
                cursor: pointer;
                margin-right: 10px;
            ">
                📧 Gửi Lại Email
            </button>
            <button onclick="closeVerificationModal()" style="
                background: #6c757d; 
                color: white; 
                border: none; 
                padding: 10px 20px; 
                border-radius: 5px; 
                cursor: pointer;
            ">
                Đóng
            </button>
        </div>
        <p style="font-size: 12px; color: #999; margin-top: 15px;">
            Không thấy email? Kiểm tra thư mục spam hoặc click "Gửi Lại Email"
        </p>
    `;
    
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    
    // Make close function global
    window.closeVerificationModal = function() {
        document.body.removeChild(overlay);
        delete window.closeVerificationModal;
        delete window.resendVerificationEmail;
    };
    
    // Make resend function global
    window.resendVerificationEmail = async function(email) {
        try {
            console.log('📧 Resending verification email to:', email);
            
            const response = await fetch('/api/resend-verification', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email: email })
            });
            
            const data = await response.json();
            
            if (data.success) {
                showNotification(data.message || 'Email xác thực đã được gửi lại!', 'success');
            } else {
                showNotification(data.message || 'Có lỗi khi gửi lại email!', 'error');
            }
        } catch (error) {
            console.error('❌ Error resending email:', error);
            showNotification('Có lỗi xảy ra khi gửi lại email!', 'error');
        }
    };
    
    // Close on overlay click
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            window.closeVerificationModal();
        }
    });
}

// Email validation helper
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Phone validation helper (Vietnamese phone numbers)
function isValidPhone(phone) {
    // Remove all spaces and special characters
    const cleanPhone = phone.replace(/\s+/g, '').replace(/[-().]/g, '');
    
    // Vietnamese phone number patterns:
    // Mobile: 09xxxxxxxx, 08xxxxxxxx, 07xxxxxxxx, 05xxxxxxxx, 03xxxxxxxx
    // Or with +84: +849xxxxxxxx, +848xxxxxxxx, etc.
    const phoneRegex = /^(\+84|84|0)?(3[2-9]|5[689]|7[06-9]|8[1-689]|9[0-46-9])[0-9]{7}$/;
    
    return phoneRegex.test(cleanPhone);
}

// Update UI for logged in user
function updateUIForLoggedInUser(user) {
    console.log('🔄 Updating UI for logged in user:', user);
    
    // Store user info in localStorage for persistence FIRST
    localStorage.setItem('techHavenUser', JSON.stringify(user));
    
    // Update global currentUser variable for other scripts BEFORE UI updates
    window.currentUser = user;
    
    // Update SmartCartManager with login status
    if (window.smartCart) {
        window.smartCart.setAuthStatus(true, user);
    }
    
    // Update user icon container in header
    const userIconContainer = document.getElementById('userIconContainer');
    if (userIconContainer) {
        const isAdmin = user.is_admin ? ' 👑' : '';
        const avatar = user.picture || user.photo;
        
        if (avatar) {
            // Google user with avatar
            userIconContainer.innerHTML = `
                <div class="user-icon-authenticated" onclick="openUserProfile()">
                    <img src="${avatar}" alt="${user.name}" class="user-avatar-small">
                    <span class="user-name-display">${user.name}${isAdmin}</span>
                </div>
            `;
        } else {
            // Manual user without avatar
            userIconContainer.innerHTML = `
                <div class="user-icon-authenticated" onclick="openUserProfile()">
                    <i class="fas fa-user-circle" style="margin-right: 8px; font-size: 20px;"></i>
                    <span class="user-name-display">${user.name}${isAdmin}</span>
                </div>
            `;
        }
    }
    
    // Also call the updateUserIcons function from EJS if it exists
    if (typeof updateUserIcons === 'function') {
        console.log('🔄 Calling updateUserIcons() from EJS template');
        updateUserIcons();
    }
    
    // Update all other user icons that might exist (fallback for old structure)
    const allUserIcons = document.querySelectorAll('.fas.fa-user[onclick*="openLoginModal"]');
    allUserIcons.forEach(icon => {
        const isAdmin = user.is_admin ? ' 👑' : '';
        const avatar = user.picture || user.photo;
        
        if (avatar) {
            // Replace with avatar and name
            icon.parentElement.innerHTML = `
                <div class="user-icon-authenticated" onclick="openUserProfile()" style="display: flex; align-items: center; cursor: pointer;">
                    <img src="${avatar}" alt="${user.name}" style="width: 24px; height: 24px; border-radius: 50%; margin-right: 8px;">
                    <span>${user.name}${isAdmin}</span>
                </div>
            `;
        } else {
            // Replace with user circle icon and name
            icon.parentElement.innerHTML = `
                <div class="user-icon-authenticated" onclick="openUserProfile()" style="display: flex; align-items: center; cursor: pointer; color: #667eea;">
                    <i class="fas fa-user-circle" style="margin-right: 8px; font-size: 20px;"></i>
                    <span>${user.name}${isAdmin}</span>
                </div>
            `;
        }
    });
    
    // Update mobile nav user link
    const mobileUserLink = document.getElementById('mobileUserLink');
    if (mobileUserLink) {
        const isAdmin = user.is_admin ? ' 👑' : '';
        const avatar = user.picture || user.photo;
        
        if (avatar) {
            mobileUserLink.innerHTML = `
                <img src="${avatar}" alt="${user.name}" style="width: 20px; height: 20px; border-radius: 50%; margin-right: 8px;">
                ${user.name}${isAdmin}
            `;
        } else {
            mobileUserLink.innerHTML = `<i class="fas fa-user-circle"></i> ${user.name}${isAdmin}`;
        }
        
        // Update onclick to open profile instead of login
        mobileUserLink.onclick = function(e) {
            e.preventDefault();
            openUserProfile();
            return false;
        };
    }
    
    // Update global currentUser variable for other scripts
    window.currentUser = user;
    
    // Update user profile panel if it exists
    if (typeof updateUserProfilePanel === 'function') {
        updateUserProfilePanel();
    }
    
    // Sync cart after user login - merge local cart with database cart
    setTimeout(async () => {
        try {
            console.log('🔄 Starting cart synchronization after user login...');
            await syncCartOnLogin();
            console.log('✅ Cart synchronization completed');
        } catch (error) {
            console.error('❌ Cart synchronization failed:', error);
        }
    }, 500); // Small delay to ensure all auth processes complete
    
    console.log('✅ UI updated successfully for:', user.name, user.provider === 'manual' ? '(Manual)' : '(Google)');
}

// Show notification (reuse existing function or create new one)
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const getIcon = (type) => {
        switch(type) {
            case 'success': return 'check-circle';
            case 'error': return 'exclamation-circle';
            case 'warning': return 'exclamation-triangle';
            default: return 'info-circle';
        }
    };
    
    const getColor = (type) => {
        switch(type) {
            case 'success': return '#4CAF50';
            case 'error': return '#f44336';
            case 'warning': return '#ff9800';
            default: return '#2196F3';
        }
    };
    
    notification.innerHTML = `
        <i class="fas fa-${getIcon(type)}"></i>
        <span>${message}</span>
    `;
    
    // Calculate position based on existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    const topOffset = 20 + (existingNotifications.length * 80); // Stack notifications
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: ${topOffset}px;
        right: 20px;
        background: ${getColor(type)};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 99999;
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 500;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        max-width: 400px;
        word-wrap: break-word;
        pointer-events: auto;
        cursor: pointer;
    `;
    
    document.body.appendChild(notification);
    
    // Add click to dismiss
    notification.addEventListener('click', function() {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    });
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Edit user profile
function editUserProfile() {
    console.log('📝 Redirecting to edit profile page...');
    
    // Get current user data
    const currentUser = window.currentUser || JSON.parse(localStorage.getItem('techHavenUser'));
    
    if (!currentUser) {
        showNotification('Vui lòng đăng nhập để chỉnh sửa hồ sơ!', 'error');
        return;
    }
    
    // Redirect to dedicated edit profile page
    window.location.href = '/edit-profile';
}

// Show edit profile modal
function showEditProfileModal(user) {
    console.log('🔧 Creating edit profile modal for user:', user);
    
    // Create modal overlay
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.cssText = `
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        background: rgba(0,0,0,0.8) !important;
        z-index: 9500 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
    `;
    
    console.log('📄 Modal overlay created:', overlay);
    
    // Create modal content
    const modal = document.createElement('div');
    modal.className = 'edit-profile-modal';
    modal.style.cssText = `
        background: white !important;
        padding: 30px !important;
        border-radius: 10px !important;
        max-width: 500px !important;
        width: 90% !important;
        margin: 20px !important;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2) !important;
        max-height: none !important;
        min-height: 400px !important;
        overflow: visible !important;
        z-index: 9500 !important;
        position: relative !important;
        color: #333 !important;
        font-family: Arial, sans-serif !important;
        font-size: 14px !important;
        line-height: 1.5 !important;
        display: block !important;
        visibility: visible !important;
    `;
    
    modal.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
            <h3 style="color: #333; margin: 0;">
                <i class="fas fa-edit"></i> Chỉnh Sửa Hồ Sơ
            </h3>
            <button onclick="closeEditProfileModal()" style="
                background: none;
                border: none;
                font-size: 20px;
                cursor: pointer;
                color: #999;
            ">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <form id="editProfileForm">
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: bold; color: #333;">
                    Họ và tên:
                </label>
                <input type="text" id="editName" value="${user.name || ''}" style="
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                    box-sizing: border-box;
                " required>
            </div>
            
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: bold; color: #333;">
                    Email:
                </label>
                <input type="email" id="editEmail" value="${user.email || ''}" style="
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                    box-sizing: border-box;
                    background: #f5f5f5;
                " readonly>
                <small style="color: #666; font-size: 12px;">Email không thể thay đổi</small>
            </div>
            
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: bold; color: #333;">
                    Số điện thoại:
                </label>
                <input type="tel" id="editPhone" value="${user.phone || ''}" style="
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                    box-sizing: border-box;
                " placeholder="Nhập số điện thoại">
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 5px; font-weight: bold; color: #333;">
                    Avatar URL (tùy chọn):
                </label>
                <input type="url" id="editAvatar" value="${user.photo || ''}" style="
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 14px;
                    box-sizing: border-box;
                " placeholder="https://example.com/avatar.jpg">
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button type="button" onclick="closeEditProfileModal()" style="
                    background: #6c757d;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 5px;
                    cursor: pointer;
                ">
                    Hủy
                </button>
                <button type="submit" style="
                    background: #007bff;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 5px;
                    cursor: pointer;
                ">
                    <i class="fas fa-save"></i> Lưu Thay Đổi
                </button>
            </div>
        </form>
    `;
    
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    
    // Add form submit handler
    const form = modal.querySelector('#editProfileForm');
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const name = document.getElementById('editName').value.trim();
            const phone = document.getElementById('editPhone').value.trim();
            const avatar = document.getElementById('editAvatar').value.trim();
            
            if (!name) {
                alert('Vui lòng nhập họ và tên!');
                return;
            }
            
            try {
                const response = await fetch('/api/user/profile', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        name: name,
                        phone: phone,
                        avatar: avatar
                    })
                });
                
                const result = await response.json();
                
                if (response.ok) {
                    // Update current user data
                    if (window.currentUser) {
                        window.currentUser.name = name;
                        window.currentUser.phone = phone;
                        window.currentUser.avatar = avatar;
                        
                        // Update localStorage for manual users
                        if (window.currentUser.provider === 'manual') {
                            localStorage.setItem('techHavenUser', JSON.stringify(window.currentUser));
                        }
                        
                        // Update UI
                        updateUIForLoggedInUser(window.currentUser);
                    }
                    
                    closeEditProfileModal();
                    alert('Cập nhật hồ sơ thành công!');
                } else {
                    alert(result.message || 'Có lỗi xảy ra khi cập nhật hồ sơ');
                }
            } catch (error) {
                console.error('Error updating profile:', error);
                alert('Có lỗi xảy ra khi cập nhật hồ sơ');
            }
        });
    }
    
    console.log('✅ Modal appended to body. Modal should be visible now!');
    console.log('📊 Modal overlay in DOM:', document.body.contains(overlay));
    console.log('📊 Modal z-index:', overlay.style.zIndex);
    
    // Debug form elements
    const editForm = document.getElementById('editProfileForm');
    const editName = document.getElementById('editName');
    console.log('📋 Edit form found:', !!editForm);
    console.log('📋 Edit name input found:', !!editName);
    console.log('📋 Modal innerHTML length:', modal.innerHTML.length);
    
    // Debug styling issues
    console.log('📊 Body overflow:', window.getComputedStyle(document.body).overflow);
    console.log('📊 Modal display:', window.getComputedStyle(overlay).display);
    console.log('📊 Modal visibility:', window.getComputedStyle(overlay).visibility);
    console.log('📊 Modal position:', window.getComputedStyle(overlay).position);
    
    // Force modal to be visible and on top
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100vw';
    overlay.style.height = '100vh';
    overlay.style.zIndex = '9500';
    overlay.style.display = 'flex';
    overlay.style.visibility = 'visible';
    
    // Make sure body doesn't hide overflow
    document.body.style.overflow = 'hidden';
    
    console.log('🔧 Applied force styling to modal');
    
    // Handle form submission
    document.getElementById('editProfileForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const name = document.getElementById('editName').value;
        const phone = document.getElementById('editPhone').value;
        const avatar = document.getElementById('editAvatar').value;
        
        // Validate
        if (!name.trim()) {
            showNotification('Vui lòng nhập họ và tên!', 'error');
            return;
        }
        
        if (phone && !isValidPhone(phone)) {
            showNotification('Số điện thoại không hợp lệ!', 'error');
            return;
        }
        
        // Show loading
        const submitBtn = e.target.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang lưu...';
        submitBtn.disabled = true;
        
        try {
            // Send update request
            const response = await fetch('/api/user/profile', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    uid: user.uid,
                    name: name.trim(),
                    phone: phone.trim(),
                    photo: avatar.trim()
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Update local user data
                const updatedUser = {
                    ...user,
                    name: name.trim(),
                    phone: phone.trim(),
                    photo: avatar.trim()
                };
                
                // Update localStorage
                localStorage.setItem('techHavenUser', JSON.stringify(updatedUser));
                window.currentUser = updatedUser;
                
                // Update UI
                updateUIForLoggedInUser(updatedUser);
                
                showNotification('Cập nhật hồ sơ thành công!', 'success');
                closeEditProfileModal();
            } else {
                showNotification(data.message || 'Có lỗi xảy ra khi cập nhật hồ sơ!', 'error');
            }
        } catch (error) {
            console.error('Error updating profile:', error);
            showNotification('Có lỗi xảy ra khi cập nhật hồ sơ!', 'error');
        } finally {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    });
    
    // Close on overlay click
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            closeEditProfileModal();
        }
    });
    
    // Make close function global
    window.closeEditProfileModal = function() {
        if (overlay && overlay.parentNode) {
            overlay.parentNode.removeChild(overlay);
        }
    };
}

// Make functions globally available
window.editUserProfile = editUserProfile;

// Debug function to check modal state
function debugModal() {
    const modal = document.getElementById('loginModal');
    console.log('=== MODAL DEBUG ===');
    console.log('Modal element:', modal);
    console.log('Modal classes:', modal ? modal.className : 'Modal not found');
    console.log('Modal style display:', modal ? modal.style.display : 'N/A');
    console.log('Modal computed styles:', modal ? window.getComputedStyle(modal) : 'N/A');
    console.log('Body overflow:', document.body.style.overflow);
    console.log('Document ready state:', document.readyState);
    console.log('All elements with loginModal ID:', document.querySelectorAll('#loginModal'));
    console.log('All elements with login-modal-overlay class:', document.querySelectorAll('.login-modal-overlay'));
    console.log('==================');
}

// Function to ensure modal exists (create if not found)
function ensureModalExists() {
    let modal = document.getElementById('loginModal');
    
    if (!modal) {
        console.log('🏗️ Creating login modal since it was not found...');
        
        // Create the modal HTML
        const modalHTML = `
        <div class="login-modal-overlay" id="loginModal">
            <div class="login-modal">
                <div class="login-modal-header">
                    <h3 id="modalTitle">Đăng Nhập</h3>
                    <button class="close-login-modal" onclick="closeLoginModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="login-modal-content">
                    <!-- Login Form -->
                    <div class="login-form" id="loginForm">
                        <div class="form-group">
                            <label for="loginEmail">Email</label>
                            <input type="email" id="loginEmail" placeholder="Nhập email của bạn" required>
                        </div>
                        <div class="form-group">
                            <label for="loginPassword">Mật khẩu</label>
                            <input type="password" id="loginPassword" placeholder="Nhập mật khẩu" required>
                        </div>
                        <div class="form-options">
                            <label class="remember-me">
                                <input type="checkbox" id="rememberMe">
                                <span>Ghi nhớ đăng nhập</span>
                            </label>
                            <a href="#" class="forgot-password">Quên mật khẩu?</a>
                        </div>
                        <button class="login-btn" onclick="handleLogin()">
                            <i class="fas fa-sign-in-alt"></i> Đăng Nhập
                        </button>
                    </div>

                    <!-- Register Form -->
                    <div class="register-form" id="registerForm" style="display: none;">
                        <div class="form-group">
                            <label for="registerName">Họ và tên</label>
                            <input type="text" id="registerName" placeholder="Nhập họ và tên" required>
                        </div>
                        <div class="form-group">
                            <label for="registerEmail">Email</label>
                            <input type="email" id="registerEmail" placeholder="Nhập email của bạn" required>
                        </div>
                        <div class="form-group">
                            <label for="registerPhone">Số điện thoại</label>
                            <input type="tel" id="registerPhone" placeholder="Nhập số điện thoại (VD: 0901234567)" required>
                        </div>
                        <div class="form-group">
                            <label for="registerPassword">Mật khẩu</label>
                            <input type="password" id="registerPassword" placeholder="Nhập mật khẩu" required>
                        </div>
                        <div class="form-group">
                            <label for="confirmPassword">Xác nhận mật khẩu</label>
                            <input type="password" id="confirmPassword" placeholder="Nhập lại mật khẩu" required>
                        </div>
                        <div class="form-options">
                            <label class="agree-terms">
                                <input type="checkbox" id="agreeTerms" required>
                                <span>Tôi đồng ý với <a href="#">Điều khoản dịch vụ</a></span>
                            </label>
                        </div>
                        <button class="register-btn" onclick="handleRegister()">
                            <i class="fas fa-user-plus"></i> Đăng Ký
                        </button>
                    </div>

                    <!-- Social Login -->
                    <div class="social-login">
                        <div class="divider">
                            <span>hoặc</span>
                        </div>
                        <a href="/auth/google" class="google-signin-btn" style="text-decoration: none; display: inline-block; width: 100%; text-align: center;">
                            <i class="fab fa-google"></i>
                            Đăng nhập với Google
                        </a>
                    </div>

                    <!-- Toggle between Login/Register -->
                    <div class="modal-footer">
                        <p id="toggleText">
                            Chưa có tài khoản? 
                            <a href="#" onclick="toggleAuthMode()">Đăng ký ngay</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>`;
        
        // Add modal to body
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        modal = document.getElementById('loginModal');
        console.log('✅ Login modal created:', modal);
        
        showNotification('Modal đăng nhập đã được tạo!', 'success');
    }
    
    return modal;
}

// Setup login modal (đơn giản)
function setupLoginModal() {
    console.log('⚙️ Thiết lập login modal');
    // Modal sẽ được tự động tạo khi cần thiết
}

// Alternative Google Sign-In method  
function showGoogleSignInPopup() {
    console.log('🔄 Trying alternative Google Sign-In method...');
    
    if (window.googleApiLoaded && typeof google !== 'undefined' && google.accounts && google.accounts.id) {
        try {
            // Generate OAuth URL manually
            const redirectUri = window.location.origin;
            const clientId = '442337591630-ab2m15n55vdi1700gs5qvufrpcfol58t.apps.googleusercontent.com';
            const scope = 'profile email';
            const responseType = 'code';
            
            const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
                `client_id=${clientId}&` +
                `redirect_uri=${encodeURIComponent(redirectUri)}&` +
                `response_type=${responseType}&` +
                `scope=${encodeURIComponent(scope)}&` +
                `access_type=offline&` +
                `prompt=select_account`;
            
            console.log('Opening Google OAuth popup:', authUrl);
            
            // Open popup window
            const popup = window.open(
                authUrl,
                'google-signin',
                'width=500,height=600,scrollbars=yes,resizable=yes'
            );
            
            if (popup) {
                showNotification('Đang mở cửa sổ đăng nhập Google...', 'info');
                
                // Monitor popup for completion
                const checkClosed = setInterval(() => {
                    if (popup.closed) {
                        clearInterval(checkClosed);
                        console.log('Google Sign-In popup closed');
                        showNotification('Cửa sổ đăng nhập đã đóng', 'info');
                    }
                }, 1000);
            } else {
                showNotification('Không thể mở cửa sổ đăng nhập. Vui lòng bật popup!', 'error');
            }
            
        } catch (error) {
            console.error('Error with alternative Google Sign-In:', error);
            showNotification('Lỗi đăng nhập Google: ' + error.message, 'error');
        }
    } else {
        console.error('Google API still not available for alternative method');
        showNotification('Google API không khả dụng', 'error');
    }
    console.log('🚀 Trying alternative Google Sign-In method...');
    
    // Create a temporary div for Google button
    const tempDiv = document.createElement('div');
    tempDiv.id = 'g_id_onload';
    tempDiv.setAttribute('data-client_id', '442337591630-ab2m15n55vdi1700gs5qvufrpcfol58t.apps.googleusercontent.com');
    tempDiv.setAttribute('data-callback', 'handleGoogleSignIn');
    tempDiv.setAttribute('data-auto_prompt', 'false');
    
    document.body.appendChild(tempDiv);
    
    // Render Google button
    if (typeof google !== 'undefined' && google.accounts) {
        google.accounts.id.renderButton(tempDiv, {
            theme: 'outline',
            size: 'large'
        });
        
        // Trigger click on rendered button
        setTimeout(() => {
            const gButton = tempDiv.querySelector('iframe');
            if (gButton) {
                gButton.click();
            }
        }, 500);
    }
}

// Show Google One Tap
function showGoogleOneTap() {
    if (typeof google !== 'undefined' && google.accounts) {
        google.accounts.id.prompt();
    }
}

// Handle Google Sign-In response
function handleGoogleSignIn(response) {
    try {
        // Decode the JWT token to get user information
        const userInfo = parseJwt(response.credential);
        console.log('Google Sign-In successful:', userInfo);
        
        // Show loading notification
        showNotification('Đang đăng nhập với Google...', 'info');
        
        // Simulate processing time
        setTimeout(() => {
            // Close login modal
            closeLoginModal();
            
            // Update UI with user info
            updateUIForLoggedInUser({
                email: userInfo.email,
                name: userInfo.name,
                picture: userInfo.picture,
                googleId: userInfo.sub
            });
            
            // Show success notification
            showNotification(`Chào mừng ${userInfo.name}!`, 'success');
            
            // Here you would typically send the token to your backend
            // to verify and create/update user account
            console.log('User info:', {
                email: userInfo.email,
                name: userInfo.name,
                picture: userInfo.picture,
                googleId: userInfo.sub
            });
            
        }, 1000);
        
    } catch (error) {
        console.error('Error handling Google Sign-In:', error);
        showNotification('Đăng nhập Google thất bại!', 'error');
    }
}

// Parse JWT token (simple implementation)
function parseJwt(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (error) {
        console.error('Error parsing JWT:', error);
        return null;
    }
}

// =====================================
// SERVER-SIDE AUTHENTICATION SUPPORT
// =====================================

// Hàm đăng nhập với Google (server-side)
window.handleGoogleLogin = function() {
    console.log('� Đăng nhập với Google (server-side)');
    window.location.href = '/auth/google';
};

// Hàm đăng xuất cho cả Google và manual users
window.handleLogout = function() {
    console.log('🚪 Đăng xuất');
    
    // Clear user data from localStorage
    localStorage.removeItem('techHavenUser');
    localStorage.removeItem('techHavenRememberMe');
    localStorage.removeItem('techHavenAuthToken');
    
    // Clear cart data (will reload from localStorage for guest mode)
    localStorage.removeItem('techHavenCart');
    localStorage.removeItem('techHavenCartCount');
    
    // Update SmartCartManager with logout status
    if (window.smartCart) {
        window.smartCart.setAuthStatus(false, null);
    }
    
    // Reset global variables
    window.currentUser = null;
    cartItems = [];
    cartCount = 0;
    
    // Reset UI to logged out state
    const userIcons = document.querySelectorAll('.fas.fa-user, .fa-user-circle');
    userIcons.forEach(icon => {
        if (icon.parentElement) {
            icon.parentElement.innerHTML = '<i class="fas fa-user" onclick="openLoginModal()" style="cursor: pointer;"></i>';
            icon.parentElement.style.color = '';
            icon.parentElement.style.display = '';
        }
    });
    
    // Update mobile nav
    const mobileUserLink = document.querySelector('#mobileUserLink');
    if (mobileUserLink) {
        mobileUserLink.innerHTML = '<i class="fas fa-user"></i> Tài khoản';
        mobileUserLink.onclick = function() { openLoginModal(); return false; };
    }
    
    // Update cart UI to empty state
    updateCartUI();
    
    // Firebase sign out if available
    if (window.firebase && window.firebase.auth) {
        try {
            window.firebase.auth().signOut();
        } catch (error) {
            console.log('Firebase signOut not available or failed:', error);
        }
    }
    
    showNotification('Đăng xuất thành công!', 'success');
    console.log('✅ Logout completed');
};

// Khởi tạo đơn giản khi DOM sẵn sàng
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 DOM loaded - Thiết lập login modal...');
    
    // Check if user is already logged in from localStorage
    checkStoredUser();
    
    // Setup user icons để mở modal
    const userIcons = document.querySelectorAll('.fas.fa-user');
    console.log('Tìm thấy', userIcons.length, 'user icons');
    
    userIcons.forEach((icon, index) => {
        icon.style.cursor = 'pointer';
        icon.addEventListener('click', function(e) {
            e.preventDefault();
            console.log(`User icon ${index + 1} được nhấn`);
            
            // Check if user is already logged in
            const storedUser = localStorage.getItem('techHavenUser');
            if (storedUser) {
                // User is logged in, show user profile or menu
                console.log('User already logged in, showing profile...');
                // You can open user profile panel here instead
                openLoginModal(); // For now, still open modal
            } else {
                openLoginModal();
            }
        });
    });
    
    console.log('✅ User icons đã được thiết lập');
    
    // Thiết lập login modal sau khi DOM load
    setTimeout(() => {
        setupLoginModal();
    }, 1000);
});

// Function to check stored user in localStorage
function checkStoredUser() {
    try {
        const storedUser = localStorage.getItem('techHavenUser');
        if (storedUser) {
            const user = JSON.parse(storedUser);
            console.log('🔄 Found stored user:', user.name);
            console.log('🔄 User provider:', user.provider);
            
            // CRITICAL: Set window.currentUser FIRST so other functions can detect it
            window.currentUser = user;
            console.log('✅ Set window.currentUser:', window.currentUser);
            
            // Update UI for logged in user (script.js function)
            updateUIForLoggedInUser(user);
            
            // Also call the EJS template updateUserIcons function if it exists
            if (typeof updateUserIcons === 'function') {
                console.log('🔄 Calling EJS updateUserIcons function...');
                updateUserIcons();
            } else {
                console.log('⚠️ EJS updateUserIcons function not found');
            }
            
            // Optionally verify with server that user is still valid
            // This is especially important for manual login users
            if (user.provider === 'manual') {
                verifyStoredUser(user);
            }
        } else {
            console.log('❌ No stored user found');
            // Make sure window.currentUser is null
            window.currentUser = null;
            
            // Call updateUserIcons to show login state
            if (typeof updateUserIcons === 'function') {
                updateUserIcons();
            }
        }
    } catch (error) {
        console.error('❌ Error checking stored user:', error);
        // Clear invalid data
        localStorage.removeItem('techHavenUser');
        localStorage.removeItem('techHavenRememberMe');
        
        // Reset currentUser
        window.currentUser = null;
        
        // Update UI to logged out state
        if (typeof updateUserIcons === 'function') {
            updateUserIcons();
        }
    }
}

// Function to verify stored user with server
function verifyStoredUser(user) {
    // For manual login users, we could ping the server to verify account is still active
    // For now, we trust localStorage data
    console.log('✅ Stored user verified:', user.name);
}

// Add Google API checker
function checkGoogleAPI() {
    console.log('=== GOOGLE API DEBUG ===');
    console.log('window.googleApiLoaded:', window.googleApiLoaded);
    console.log('typeof google:', typeof google);
    console.log('google exists:', typeof google !== 'undefined');
    
    if (typeof google !== 'undefined') {
        console.log('google.accounts:', google.accounts);
        console.log('google.accounts.id:', google.accounts ? google.accounts.id : 'N/A');
    }
    
    console.log('Google script in DOM:', document.querySelector('script[src*="gsi/client"]'));
    console.log('=======================');
    
    // Try to reinitialize
    if (window.googleApiLoaded) {
        showNotification('Google API đã được tải, thử khởi tạo lại...', 'info');
        initializeGoogleSignIn();
    } else {
        showNotification('Google API chưa được tải!', 'error');
    }
}

window.checkGoogleAPI = checkGoogleAPI;

// =====================================
// AUTO-FILL USER INFORMATION
// =====================================

// Function to auto-fill user information in checkout form if user is logged in
function fillUserInformationIfLoggedIn() {
    // Check if user is logged in
    if (!window.currentUser) {
        console.log('👤 No user logged in - form fields remain editable');
        // Make sure form fields are editable for guest users
        const customerName = document.getElementById('customerName');
        const customerPhone = document.getElementById('customerPhone');
        const customerEmail = document.getElementById('customerEmail');
        
        if (customerName) {
            customerName.disabled = false;
            customerName.placeholder = 'Nhập họ và tên';
        }
        if (customerPhone) {
            customerPhone.disabled = false;
            customerPhone.placeholder = 'Nhập số điện thoại';
        }
        if (customerEmail) {
            customerEmail.disabled = false;
            customerEmail.placeholder = 'Nhập email';
        }
        return;
    }
    
    console.log('✅ User logged in - auto-filling form with user data');
    
    // Fill customer name
    const customerName = document.getElementById('customerName');
    if (customerName) {
        const userName = window.currentUser.name || window.currentUser.displayName;
        if (userName) {
            customerName.value = userName;
            customerName.disabled = true; // Disable editing for logged-in users
            customerName.style.backgroundColor = '#f8f9fa';
            customerName.style.color = '#6c757d';
            customerName.title = 'Thông tin từ tài khoản đã đăng nhập';
        } else {
            // If no name available, allow manual input but will be filled from Firestore later
            customerName.disabled = false;
            customerName.placeholder = 'Nhập họ và tên';
        }
    }
    
    // Fill customer email
    const customerEmail = document.getElementById('customerEmail');
    if (customerEmail && window.currentUser.email) {
        customerEmail.value = window.currentUser.email;
        customerEmail.disabled = true; // Disable editing for logged-in users
        customerEmail.style.backgroundColor = '#f8f9fa';
        customerEmail.style.color = '#6c757d';
        customerEmail.title = 'Thông tin từ tài khoản đã đăng nhập';
    }
    
    // For phone and name, we need to fetch from user profile since Firebase Auth doesn't always have complete info
    fetchUserDataAndFill();
}

// Function to fetch user data (name and phone) from Firestore profile
async function fetchUserDataAndFill() {
    try {
        const idToken = await window.getIdToken();
        if (!idToken) return;
        
        const response = await fetch('/api/user/profile', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${idToken}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            const customerPhone = document.getElementById('customerPhone');
            const customerName = document.getElementById('customerName');
            
            // Fill name if available from Firestore
            if (customerName && data.user && data.user.name) {
                if (!customerName.value || customerName.value !== data.user.name) {
                    customerName.value = data.user.name;
                    customerName.disabled = true;
                    customerName.style.backgroundColor = '#f8f9fa';
                    customerName.style.color = '#6c757d';
                    customerName.title = 'Thông tin từ tài khoản đã đăng nhập';
                }
                // Update window.currentUser.name if different
                if (window.currentUser && window.currentUser.name !== data.user.name) {
                    window.currentUser.name = data.user.name;
                }
            }
            
            // Fill phone
            if (customerPhone && data.user && data.user.phone) {
                customerPhone.value = data.user.phone;
                customerPhone.disabled = true;
                customerPhone.style.backgroundColor = '#f8f9fa';
                customerPhone.style.color = '#6c757d';
                customerPhone.title = 'Thông tin từ tài khoản đã đăng nhập';
            } else if (customerPhone) {
                // Phone not found in profile - allow manual input
                customerPhone.disabled = false;
                customerPhone.placeholder = 'Nhập số điện thoại';
            }
        }
    } catch (error) {
        console.error('❌ Error fetching user data:', error);
        // If error, allow manual input
        const customerPhone = document.getElementById('customerPhone');
        const customerName = document.getElementById('customerName');
        
        if (customerPhone && !customerPhone.value) {
            customerPhone.disabled = false;
            customerPhone.placeholder = 'Nhập số điện thoại';
        }
        if (customerName && !customerName.value) {
            customerName.disabled = false;
            customerName.placeholder = 'Nhập họ và tên';
        }
    }
}

// Debug function for cart troubleshooting
window.debugCart = function() {
    console.log('🔍 CART DEBUG INFO:');
    console.log('cartItems:', cartItems);
    console.log('cartCount:', cartCount);
    console.log('localStorage cart:', localStorage.getItem('techHavenCart'));
    console.log('localStorage count:', localStorage.getItem('techHavenCartCount'));
    console.log('window.cartItems:', window.cartItems);
    console.log('Cart total:', calculateCartTotal());
    
    const cartBadge = document.getElementById('cartBadge');
    const mobileCartCount = document.getElementById('mobileCartCount');
    const cartItemsContainer = document.getElementById('cartItems');
    
    console.log('cartBadge element:', cartBadge);
    console.log('cartBadge text:', cartBadge?.textContent);
    console.log('mobileCartCount element:', mobileCartCount);
    console.log('mobileCartCount text:', mobileCartCount?.textContent);
    console.log('cartItemsContainer:', cartItemsContainer);
    console.log('cartItemsContainer HTML:', cartItemsContainer?.innerHTML.substring(0, 200) + '...');
};

// Make function globally available
window.fillUserInformationIfLoggedIn = fillUserInformationIfLoggedIn;

// =====================================
// EMAIL VERIFICATION LOADING SCREEN
// =====================================

// Show email verification loading screen
function showEmailVerificationLoadingScreen(email, userData) {
    // Create overlay
    const overlay = document.createElement('div');
    overlay.id = 'emailVerificationOverlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        z-index: 99999;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: fadeIn 0.3s ease-in-out;
    `;
    
    // Create loading screen content
    const content = document.createElement('div');
    content.style.cssText = `
        background: white;
        padding: 40px;
        border-radius: 15px;
        max-width: 500px;
        width: 90%;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        animation: slideUp 0.4s ease-out;
    `;
    
    content.innerHTML = `
        <div style="margin-bottom: 30px;">
            <div class="email-loading-icon" style="
                width: 80px;
                height: 80px;
                border: 4px solid #e3f2fd;
                border-top: 4px solid #2196f3;
                border-radius: 50%;
                animation: spin 1s linear infinite;
                margin: 0 auto 20px auto;
            "></div>
            <h2 style="color: #333; margin: 0 0 15px 0; font-size: 24px;">
                🎉 Đăng Ký Thành Công!
            </h2>
        </div>
        
        <div style="margin-bottom: 30px;">
            <div style="background: linear-gradient(135deg, #e3f2fd, #f3e5f5); padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                <p style="margin: 0 0 15px 0; color: #555; font-size: 16px; line-height: 1.6;">
                    Tài khoản của bạn đã được tạo thành công!
                </p>
                <p style="margin: 0; color: #333; font-weight: 600;">
                    📧 Email xác thực đã được gửi đến:<br>
                    <span style="color: #2196f3; font-family: 'Courier New', monospace;">${email}</span>
                </p>
            </div>
            
            <div style="background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 8px; padding: 15px; margin-bottom: 20px;">
                <p style="margin: 0; color: #856404; font-size: 14px;">
                    <strong>⚠️ Quan trọng:</strong> Vui lòng kiểm tra email và click vào liên kết xác thực để kích hoạt tài khoản.
                </p>
            </div>
        </div>
        
        <div style="margin-bottom: 30px;">
            <div class="verification-status" id="verificationStatus">
                <p style="color: #666; margin: 0 0 15px 0;">
                    ⏳ Đang chờ xác thực email...
                </p>
                <div class="progress-bar" style="
                    width: 100%;
                    height: 6px;
                    background: #e0e0e0;
                    border-radius: 3px;
                    overflow: hidden;
                ">
                    <div class="progress-fill" style="
                        height: 100%;
                        background: linear-gradient(90deg, #2196f3, #21cbf3);
                        border-radius: 3px;
                        animation: progress 2s ease-in-out infinite;
                    "></div>
                </div>
            </div>
        </div>
        
        <div style="display: flex; flex-direction: column; gap: 10px;">
            <button onclick="checkEmailVerification('${email}', '${userData.uid}')" style="
                background: linear-gradient(135deg, #4CAF50, #45a049);
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.3s ease;
            " onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
                🔍 Kiểm Tra Xác Thực
            </button>
            
            <button onclick="resendVerificationEmail('${email}')" style="
                background: linear-gradient(135deg, #ff9800, #f57c00);
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.3s ease;
            " onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
                📧 Gửi Lại Email
            </button>
            
            <button onclick="skipEmailVerification()" style="
                background: #6c757d;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 8px;
                font-size: 14px;
                cursor: pointer;
                transition: all 0.3s ease;
            " onmouseover="this.style.background='#5a6268'" onmouseout="this.style.background='#6c757d'">
                Bỏ Qua (Xác Thực Sau)
            </button>
        </div>
    `;
    
    // Add CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideUp {
            from { transform: translateY(50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        @keyframes progress {
            0% { transform: translateX(-100%); }
            50% { transform: translateX(0%); }
            100% { transform: translateX(100%); }
        }
    `;
    document.head.appendChild(style);
    
    overlay.appendChild(content);
    document.body.appendChild(overlay);
    
    // Auto-check verification status every 5 seconds
    let autoCheckInterval = setInterval(() => {
        checkEmailVerificationSilent(email, userData.uid, autoCheckInterval);
    }, 5000);
    
    // Store interval ID for cleanup
    overlay.autoCheckInterval = autoCheckInterval;
}

// Check email verification status (with user feedback)
window.checkEmailVerification = async function(email, uid) {
    const btn = event.target;
    const originalText = btn.innerHTML;
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang kiểm tra...';
    
    try {
        // Check with Firebase Auth - first try to get current user
        let user = firebase.auth().currentUser;
        
        // If no current user, try to sign in with stored token or wait for auth state
        if (!user) {
            console.log('🔄 No current Firebase user, checking auth state...');
            
            // Wait for auth state to be ready
            await new Promise((resolve) => {
                const unsubscribe = firebase.auth().onAuthStateChanged((authUser) => {
                    user = authUser;
                    unsubscribe();
                    resolve();
                });
            });
        }
        
        if (user) {
            console.log('📧 Reloading Firebase user to check verification status...');
            await user.reload(); // Refresh user data
            
            console.log('✅ User verification status:', user.emailVerified);
            
            if (user.emailVerified) {
                // Email verified successfully
                showNotification('🎉 Email đã được xác thực thành công!', 'success');
                
                // Close verification screen
                closeEmailVerificationScreen();
                
                // Auto login the user
                const idToken = await user.getIdToken();
                localStorage.setItem('techHavenAuthToken', idToken);
                
                // Update UI
                window.currentUser = {
                    uid: uid,
                    email: email,
                    name: user.displayName || email.split('@')[0],
                    emailVerified: true,
                    provider: 'manual'
                };
                updateUIForLoggedInUser(window.currentUser);
                
                return;
            }
        }
        
        // Still not verified
        console.log('⚠️ Email still not verified');
        showNotification('Email chưa được xác thực. Vui lòng kiểm tra hộp thư.', 'warning');
        
    } catch (error) {
        console.error('Error checking email verification:', error);
        showNotification('Có lỗi khi kiểm tra xác thực email.', 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
};

// Check email verification silently (for auto-check)
async function checkEmailVerificationSilent(email, uid, intervalId) {
    try {
        let user = firebase.auth().currentUser;
        
        // If no current user, wait for auth state
        if (!user) {
            await new Promise((resolve) => {
                const unsubscribe = firebase.auth().onAuthStateChanged((authUser) => {
                    user = authUser;
                    unsubscribe();
                    resolve();
                });
            });
        }
        
        if (user) {
            console.log('🔄 Silent check: Reloading user...');
            await user.reload();
            
            console.log('📧 Silent check: User verified?', user.emailVerified);
            
            if (user.emailVerified) {
                // Clear interval
                clearInterval(intervalId);
                
                // Auto close and login
                showNotification('🎉 Email đã được xác thực! Đăng nhập tự động...', 'success');
                
                setTimeout(() => {
                    closeEmailVerificationScreen();
                    
                    // Auto login
                    user.getIdToken().then(idToken => {
                        localStorage.setItem('techHavenAuthToken', idToken);
                        
                        window.currentUser = {
                            uid: uid,
                            email: email,
                            name: user.displayName || email.split('@')[0],
                            emailVerified: true,
                            provider: 'manual'
                        };
                        updateUIForLoggedInUser(window.currentUser);
                    });
                }, 1500);
            }
        }
    } catch (error) {
        console.error('Silent verification check error:', error);
    }
}

// Resend verification email
window.resendVerificationEmail = async function(email) {
    const btn = event.target;
    const originalText = btn.innerHTML;
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang gửi...';
    
    try {
        const response = await fetch('/api/resend-verification', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('📧 Email xác thực đã được gửi lại!', 'success');
        } else {
            showNotification(data.message || 'Có lỗi khi gửi lại email.', 'error');
        }
    } catch (error) {
        console.error('Error resending verification:', error);
        showNotification('Có lỗi khi gửi lại email xác thực.', 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
};

// Skip email verification
window.skipEmailVerification = function() {
    if (confirm('⚠️ Bạn có chắc muốn bỏ qua xác thực email?\n\nTài khoản chưa xác thực sẽ có một số hạn chế về tính năng.')) {
        closeEmailVerificationScreen();
        showNotification('Bạn có thể xác thực email sau trong phần cài đặt tài khoản.', 'info');
    }
};

// Close email verification screen
function closeEmailVerificationScreen() {
    const overlay = document.getElementById('emailVerificationOverlay');
    if (overlay) {
        // Clear auto-check interval
        if (overlay.autoCheckInterval) {
            clearInterval(overlay.autoCheckInterval);
        }
        
        // Fade out animation
        overlay.style.animation = 'fadeOut 0.3s ease-in-out forwards';
        setTimeout(() => {
            overlay.remove();
        }, 300);
    }
}

// Add fadeOut animation
const fadeOutStyle = document.createElement('style');
fadeOutStyle.textContent = `
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
`;
if (!document.querySelector('style[data-fadeout]')) {
    fadeOutStyle.setAttribute('data-fadeout', 'true');
    document.head.appendChild(fadeOutStyle);
}
