// =====================================
// BILL DETAIL PAGE JAVASCRIPT
// Fetches and displays user's order history from Firestore
// Independent from script.js - manages its own Firebase connection
// =====================================

console.log('🧾 Bill Detail JS loaded');
console.log('🔍 Checking window.currentUser:', window.currentUser);
console.log('🔍 Checking localStorage userData:', localStorage.getItem('userData'));

let currentUser = null;
let allBills = [];
let currentFilter = 'all';

// Check for existing user from parent window (index.ejs)
function checkExistingUser() {
    console.log('🔍 Checking for existing user from parent window...');
    
    // Try to get user from window.currentUser (set by index.ejs)
    if (window.currentUser) {
        console.log('✅ Found existing user from parent window:', {
            uid: window.currentUser.uid,
            email: window.currentUser.email,
            displayName: window.currentUser.displayName || window.currentUser.name
        });
        return window.currentUser;
    }
    
    // Try to get user from localStorage (backup)
    const storedUserData = localStorage.getItem('userData');
    if (storedUserData) {
        try {
            const userData = JSON.parse(storedUserData);
            console.log('✅ Found user in localStorage:', userData);
            return userData;
        } catch (error) {
            console.error('❌ Error parsing stored user data:', error);
        }
    }
    
    return null;
}

// Initialize page when DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
    console.log('📋 Initializing Bill Detail page...');
    
    // Check if Firebase is initialized
    if (!firebase || !firebase.apps.length) {
        console.error('❌ Firebase not initialized!');
        showErrorMessage('Firebase configuration error. Please refresh the page.');
        return;
    }
    
    // First, try to get existing user from parent window
    const existingUser = checkExistingUser();
    if (existingUser && existingUser.uid) {
        console.log('✅ Using existing user from parent window');
        currentUser = existingUser;
        await loadUserBills();
        initializeFilterTabs();
        initializeModal();
        return;
    }
    
    // Wait for Firebase Auth to be ready
    firebase.auth().onAuthStateChanged(async (user) => {
        if (user) {
            currentUser = user;
            console.log('👤 User logged in via Firebase Auth:', user.email);
            console.log('🔑 User ID:', user.uid);
            await loadUserBills();
            initializeFilterTabs();
        } else {
            console.warn('⚠️ No user logged in, redirecting to home...');
            showErrorMessage('Vui lòng đăng nhập để xem lịch sử đơn hàng');
            setTimeout(() => {
                window.location.href = '/';
            }, 2000);
        }
    });
    
    // Initialize modal close handlers
    initializeModal();
});

// Load user's bills from Firestore
async function loadUserBills() {
    try {
        // Validate currentUser exists
        if (!currentUser || !currentUser.uid) {
            console.error('❌ No current user found');
            showErrorMessage('User not authenticated. Please login.');
            return;
        }
        
        showLoading(true);
        console.log('📥 Fetching bills for user:', currentUser.uid);
        console.log('📧 User email:', currentUser.email || currentUser.emailAddress || 'N/A');
        
        const db = firebase.firestore();
        const billsRef = db.collection('bills');
        
        // Query bills by userId
        console.log('🔍 Querying Firestore: bills collection where userId ==', currentUser.uid);
        const snapshot = await billsRef
            .where('userId', '==', currentUser.uid)
            .orderBy('createdAt', 'desc')
            .get();
        
        console.log('📊 Query result:', snapshot.size, 'documents found');
        
        allBills = [];
        snapshot.forEach((doc) => {
            const billData = doc.data();
            console.log('📄 Bill found:', doc.id, billData);
            allBills.push({
                id: doc.id,
                ...billData
            });
        });
        
        console.log(`✅ Loaded ${allBills.length} bills for user ${currentUser.uid}`);
        console.log('📦 All bills:', allBills);
        
        updateStats();
        renderBills(currentFilter);
        showLoading(false);
        
    } catch (error) {
        console.error('❌ Error loading bills:', error);
        console.error('Error details:', error.message);
        showLoading(false);
        
        // Show detailed error message based on error type
        if (error.code === 'failed-precondition' || error.message.includes('index')) {
            // Index is still being created
            const errorDiv = document.createElement('div');
            errorDiv.className = 'index-building-message';
            errorDiv.innerHTML = `
                <div style="text-align: center; padding: 60px 20px;">
                    <i class="fas fa-hourglass-half" style="font-size: 80px; color: #E5D4FF; margin-bottom: 30px; animation: spin 2s linear infinite;"></i>
                    <h2 style="color: #333; margin-bottom: 20px; font-size: 32px;">⏳ Đang khởi tạo cơ sở dữ liệu...</h2>
                    <p style="color: #666; font-size: 18px; margin-bottom: 30px; max-width: 600px; margin-left: auto; margin-right: auto;">
                        Database index đang được tạo để tối ưu hóa tốc độ truy vấn. 
                        Quá trình này thường mất <strong>1-2 phút</strong>.
                    </p>
                    <div style="background: linear-gradient(135deg, #FFD6E8 0%, #E5D4FF 100%); padding: 20px; border-radius: 15px; margin: 30px auto; max-width: 500px;">
                        <p style="margin: 0; color: #333; font-size: 16px;">
                            💡 <strong>Mẹo:</strong> Hãy thử lại sau <strong>1 phút</strong> bằng cách nhấn nút bên dưới
                        </p>
                    </div>
                    <button onclick="location.reload()" style="
                        background: linear-gradient(135deg, #E5D4FF 0%, #FFD6E8 100%);
                        color: #333;
                        border: none;
                        padding: 15px 40px;
                        border-radius: 30px;
                        font-size: 18px;
                        font-weight: 600;
                        cursor: pointer;
                        box-shadow: 0 4px 15px rgba(229, 212, 255, 0.4);
                        transition: all 0.3s ease;
                        margin-top: 20px;
                    " onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(229, 212, 255, 0.6)';" 
                       onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(229, 212, 255, 0.4)';">
                        🔄 Thử lại ngay
                    </button>
                    <p style="margin-top: 20px; color: #999; font-size: 14px;">
                        Trang sẽ tự động tải lại sau <span id="countdown">60</span> giây...
                    </p>
                </div>
                <style>
                    @keyframes spin {
                        0% { transform: rotate(0deg); }
                        100% { transform: rotate(360deg); }
                    }
                </style>
            `;
            
            // Replace bill cards container with error message
            const billsGrid = document.querySelector('.bills-grid');
            if (billsGrid) {
                billsGrid.innerHTML = '';
                billsGrid.appendChild(errorDiv);
            }
            
            // Auto reload after 60 seconds
            let countdown = 60;
            const countdownInterval = setInterval(() => {
                countdown--;
                const countdownEl = document.getElementById('countdown');
                if (countdownEl) {
                    countdownEl.textContent = countdown;
                }
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    location.reload();
                }
            }, 1000);
            
        } else if (error.code === 'permission-denied') {
            showErrorMessage('Bạn không có quyền xem đơn hàng. Vui lòng đăng nhập lại.');
        } else {
            showErrorMessage('Không thể tải lịch sử đơn hàng: ' + error.message);
        }
    }
}

// Update statistics cards
function updateStats() {
    const stats = {
        all: allBills.length,
        pending: allBills.filter(b => b.status === 'pending').length,
        completed: allBills.filter(b => b.status === 'completed').length,
        cancelled: allBills.filter(b => b.status === 'cancelled').length
    };
    
    document.querySelector('.stat-all .stat-number').textContent = stats.all;
    document.querySelector('.stat-pending .stat-number').textContent = stats.pending;
    document.querySelector('.stat-completed .stat-number').textContent = stats.completed;
    document.querySelector('.stat-cancelled .stat-number').textContent = stats.cancelled;
}

// Initialize filter tabs
function initializeFilterTabs() {
    const filterTabs = document.querySelectorAll('.filter-tab');
    
    filterTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            filterTabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            tab.classList.add('active');
            
            // Get filter value and render bills
            currentFilter = tab.dataset.filter;
            console.log('🔍 Filter changed to:', currentFilter);
            renderBills(currentFilter);
        });
    });
}

// Render bills based on filter
function renderBills(filter = 'all') {
    const billsList = document.querySelector('.bills-list');
    
    // Filter bills based on status
    let filteredBills = allBills;
    if (filter !== 'all') {
        filteredBills = allBills.filter(bill => bill.status === filter);
    }
    
    console.log(`📊 Rendering ${filteredBills.length} bills with filter: ${filter}`);
    
    // Check if empty
    if (filteredBills.length === 0) {
        billsList.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">📦</div>
                <h3>No orders found</h3>
                <p>You don't have any ${filter === 'all' ? '' : filter} orders yet.</p>
                ${filter === 'all' ? '<a href="/shop" class="shop-now-btn"><i class="fas fa-shopping-bag"></i> Start Shopping</a>' : ''}
            </div>
        `;
        return;
    }
    
    // Render bill cards
    billsList.innerHTML = filteredBills.map(bill => createBillCard(bill)).join('');
    
    // Add click handlers to view detail buttons
    document.querySelectorAll('.view-detail-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const billId = btn.dataset.billId;
            const bill = allBills.find(b => b.id === billId);
            if (bill) {
                showBillDetail(bill);
            }
        });
    });
    
    // Add click handler to entire card
    document.querySelectorAll('.bill-card').forEach(card => {
        card.addEventListener('click', () => {
            const billId = card.dataset.billId;
            const bill = allBills.find(b => b.id === billId);
            if (bill) {
                showBillDetail(bill);
            }
        });
    });
}

// Create HTML for a single bill card
function createBillCard(bill) {
    const statusClass = `status-${bill.status || 'pending'}`;
    const statusText = getStatusText(bill.status || 'pending');
    const statusIcon = getStatusIcon(bill.status || 'pending');
    const date = formatDate(bill.createdAt || bill.updatedAt);
    const totalAmount = formatCurrency(bill.totalAmount || 0);
    
    // Ensure products is an array
    const products = Array.isArray(bill.products) ? bill.products : [];
    
    // Show first 3 products
    const productsPreview = products.slice(0, 3).map(p => `
        <div class="product-item">
            <span class="product-name">${escapeHtml(p.name || 'Product')}</span>
            <span class="product-quantity">x${p.quantity || 1}</span>
            <span class="product-price">${formatCurrency(p.price || 0)}</span>
        </div>
    `).join('');
    
    const moreProducts = products.length > 3 ? 
        `<div class="product-item" style="color: #999; font-style: italic;">
            + ${products.length - 3} more products
        </div>` : '';
    
    return `
        <div class="bill-card ${statusClass}" data-bill-id="${bill.id}">
            <div class="bill-header">
                <div class="bill-id-section">
                    <div class="bill-id">Order #${bill.id.substring(0, 8).toUpperCase()}</div>
                    <div class="bill-date">
                        <i class="fas fa-calendar-alt"></i>
                        ${date}
                    </div>
                </div>
                <span class="bill-status ${statusClass}">
                    <i class="${statusIcon}"></i>
                    ${statusText}
                </span>
            </div>
            
            <div class="bill-products">
                ${productsPreview || '<div class="product-item" style="color: #999;">No products</div>'}
                ${moreProducts}
            </div>
            
            <div class="bill-footer">
                <div class="bill-total">
                    Total: <strong>${totalAmount}</strong>
                </div>
                <button class="view-detail-btn" data-bill-id="${bill.id}">
                    <i class="fas fa-eye"></i>
                    View Details
                </button>
            </div>
        </div>
    `;
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text).replace(/[&<>"']/g, m => map[m]);
}

// Show bill detail in modal
function showBillDetail(bill) {
    console.log('📄 Showing bill detail:', bill.id);
    
    const modal = document.getElementById('billDetailModal');
    const modalBody = modal.querySelector('.modal-body');
    
    const statusClass = `status-${bill.status || 'pending'}`;
    const statusText = getStatusText(bill.status || 'pending');
    const statusIcon = getStatusIcon(bill.status || 'pending');
    const date = formatDate(bill.createdAt || bill.updatedAt);
    
    // Ensure products is an array
    const products = Array.isArray(bill.products) ? bill.products : [];
    
    // Build products list
    const productsList = products.map(p => `
        <div class="product-detail-item">
            <span class="product-detail-name">${escapeHtml(p.name || 'Product')}</span>
            <span class="product-detail-qty">x${p.quantity || 1}</span>
            <span class="product-detail-price">${formatCurrency((p.price || 0) * (p.quantity || 1))}</span>
        </div>
    `).join('');
    
    // Calculate totals with safe number handling
    const subtotal = products.reduce((sum, p) => {
        const price = parseFloat(p.price) || 0;
        const quantity = parseInt(p.quantity) || 1;
        return sum + (price * quantity);
    }, 0);
    const discount = parseFloat(bill.discount) || 0;
    const shipping = parseFloat(bill.shippingFee) || 0;
    const total = parseFloat(bill.totalAmount) || (subtotal - discount + shipping);
    
    modalBody.innerHTML = `
        <!-- Order Status -->
        <div class="detail-section">
            <h4><i class="fas fa-info-circle"></i> Order Status</h4>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Order ID</div>
                    <div class="info-value">#${bill.id.substring(0, 8).toUpperCase()}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Date</div>
                    <div class="info-value">${date}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Status</div>
                    <div class="info-value">
                        <span class="bill-status ${statusClass}">
                            <i class="${statusIcon}"></i>
                            ${statusText}
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Customer Info -->
        <div class="detail-section">
            <h4><i class="fas fa-user"></i> Customer Information</h4>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Name</div>
                    <div class="info-value">${escapeHtml(bill.customerInfo?.name || bill.customerInfo?.fullName || bill.name || 'N/A')}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Phone</div>
                    <div class="info-value">${escapeHtml(bill.customerInfo?.phone || bill.phone || 'N/A')}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Email</div>
                    <div class="info-value">${escapeHtml(bill.customerInfo?.email || bill.email || currentUser?.email || 'N/A')}</div>
                </div>
            </div>
        </div>
        
        <!-- Shipping Address -->
        <div class="detail-section">
            <h4><i class="fas fa-map-marker-alt"></i> Shipping Address</h4>
            <div class="info-item">
                <div class="info-value">${escapeHtml(getFullAddress(bill))}</div>
            </div>
        </div>
        
        <!-- Products -->
        <div class="detail-section">
            <h4><i class="fas fa-box"></i> Products (${products.length})</h4>
            <div class="product-list">
                ${productsList || '<p>No products</p>'}
            </div>
        </div>
        
        <!-- Order Summary -->
        <div class="detail-section">
            <h4><i class="fas fa-receipt"></i> Order Summary</h4>
            <div class="summary-grid">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span>${formatCurrency(subtotal)}</span>
                </div>
                ${discount > 0 ? `
                    <div class="summary-row">
                        <span>Discount:</span>
                        <span>-${formatCurrency(discount)}</span>
                    </div>
                ` : ''}
                ${shipping > 0 ? `
                    <div class="summary-row">
                        <span>Shipping Fee:</span>
                        <span>${formatCurrency(shipping)}</span>
                    </div>
                ` : ''}
                <div class="summary-row">
                    <span>Total Amount:</span>
                    <span><strong>${formatCurrency(total)}</strong></span>
                </div>
            </div>
        </div>
        
        ${bill.note ? `
            <div class="detail-section">
                <h4><i class="fas fa-sticky-note"></i> Order Note</h4>
                <div class="info-item">
                    <div class="info-value">${escapeHtml(bill.note)}</div>
                </div>
            </div>
        ` : ''}
    `;
    
    modal.classList.add('active');
}

// Initialize modal handlers
function initializeModal() {
    const modal = document.getElementById('billDetailModal');
    const closeBtn = modal.querySelector('.close-modal');
    
    // Close on button click
    closeBtn.addEventListener('click', () => {
        modal.classList.remove('active');
    });
    
    // Close on overlay click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
    
    // Close on ESC key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            modal.classList.remove('active');
        }
    });
}

// Utility: Format date
function formatDate(timestamp) {
    if (!timestamp) return 'N/A';
    
    try {
        let date;
        if (timestamp && typeof timestamp.toDate === 'function') {
            // Firestore Timestamp
            date = timestamp.toDate();
        } else if (timestamp instanceof Date) {
            date = timestamp;
        } else if (timestamp && timestamp.seconds) {
            // Firestore Timestamp object with seconds
            date = new Date(timestamp.seconds * 1000);
        } else {
            date = new Date(timestamp);
        }
        
        // Check if date is valid
        if (isNaN(date.getTime())) {
            console.warn('Invalid date:', timestamp);
            return 'N/A';
        }
        
        const options = {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            timeZone: 'Asia/Ho_Chi_Minh'
        };
        
        return date.toLocaleDateString('vi-VN', options);
    } catch (error) {
        console.error('Error formatting date:', error, timestamp);
        return 'N/A';
    }
}

// Utility: Format currency
function formatCurrency(amount) {
    if (typeof amount !== 'number') {
        amount = parseFloat(amount) || 0;
    }
    
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount);
}

// Utility: Get status text
function getStatusText(status) {
    const statusMap = {
        'pending': 'Pending',
        'processing': 'Processing',
        'shipping': 'Shipping',
        'completed': 'Completed',
        'cancelled': 'Cancelled'
    };
    
    return statusMap[status] || status;
}

// Utility: Get status icon
function getStatusIcon(status) {
    const iconMap = {
        'pending': 'fas fa-clock',
        'processing': 'fas fa-spinner',
        'shipping': 'fas fa-truck',
        'completed': 'fas fa-check-circle',
        'cancelled': 'fas fa-times-circle'
    };
    
    return iconMap[status] || 'fas fa-info-circle';
}

// Utility: Get full address from bill data
function getFullAddress(bill) {
    // Try different address formats
    if (bill.address) {
        if (typeof bill.address === 'string') {
            return bill.address;
        }
        if (bill.address.fullAddress) {
            return bill.address.fullAddress;
        }
        // Construct from parts
        const parts = [
            bill.address.address,
            bill.address.district,
            bill.address.city
        ].filter(Boolean);
        if (parts.length > 0) {
            return parts.join(', ');
        }
    }
    
    // Try customerInfo address
    if (bill.customerInfo?.address) {
        if (typeof bill.customerInfo.address === 'string') {
            return bill.customerInfo.address;
        }
        const parts = [
            bill.customerInfo.address.address,
            bill.customerInfo.address.district,
            bill.customerInfo.address.city
        ].filter(Boolean);
        if (parts.length > 0) {
            return parts.join(', ');
        }
    }
    
    return 'No address provided';
}

// Show/hide loading state
function showLoading(show) {
    const billsList = document.querySelector('.bills-list');
    
    if (show) {
        billsList.innerHTML = `
            <div class="loading-state">
                <div class="loading-spinner"></div>
                <h3>Loading your orders...</h3>
                <p>Please wait while we fetch your order history</p>
            </div>
        `;
    }
}

// Show error message
function showErrorMessage(message) {
    const billsList = document.querySelector('.bills-list');
    billsList.innerHTML = `
        <div class="empty-state">
            <div class="empty-icon">⚠️</div>
            <h3>Oops! Something went wrong</h3>
            <p>${message}</p>
            <button onclick="location.reload()" class="shop-now-btn">
                <i class="fas fa-sync-alt"></i>
                Retry
            </button>
        </div>
    `;
}

// Back button handler
document.querySelector('.back-btn')?.addEventListener('click', () => {
    window.history.back();
});

console.log('✅ Bill Detail JS initialized');
