# Firebase Firestore Comments Collection Structure

## Collection: `comments`

### Document Structure

```javascript
{
  // Auto-generated document ID by Firestore
  id: "auto-generated-doc-id",
  
  // Required fields
  productId: "string",        // ID of the product being commented on
  userId: "string",           // Firebase Auth UID of the user who made the comment
  content: "string",          // The actual comment text content
  createdAt: "timestamp",     // Firestore server timestamp when comment was created
  updatedAt: "timestamp",     // Firestore server timestamp when comment was last updated
  
  // Comment hierarchy fields
  isChild: "boolean",         // false for main comments, true for replies
  parentId: "string|null",    // null for main comments, parent comment ID for replies
  
  // User display information (cached for performance)
  userDisplayName: "string",  // Display name of the user (from Firebase Auth)
  userAvatar: "string|null",  // Profile photo URL of the user (from Firebase Auth)
  
  // Optional fields
  edited: "boolean",          // true if comment has been edited
  editedAt: "timestamp|null", // timestamp of last edit
  reactions: {                // Optional: for future reaction system
    likes: "number",
    dislikes: "number",
    hearts: "number"
  },
  flagged: "boolean",         // true if comment has been flagged for moderation
  visible: "boolean"          // true by default, false if hidden by moderator
}
```

### Index Requirements

To ensure optimal performance, create the following composite indexes in Firestore:

1. **Product Comments Index:**
   - Collection: `comments`
   - Fields: `productId` (Ascending), `createdAt` (Descending)
   - Query scope: Collection

2. **User Comments Index:**
   - Collection: `comments`
   - Fields: `userId` (Ascending), `createdAt` (Descending)
   - Query scope: Collection

3. **Reply Comments Index:**
   - Collection: `comments`
   - Fields: `parentId` (Ascending), `createdAt` (Ascending)
   - Query scope: Collection

4. **Product Main Comments Index:**
   - Collection: `comments`
   - Fields: `productId` (Ascending), `isChild` (Ascending), `createdAt` (Descending)
   - Query scope: Collection

### Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Comments collection rules
    match /comments/{commentId} {
      // Allow read for all authenticated users
      allow read: if request.auth != null;
      
      // Allow create for authenticated users with valid data
      allow create: if request.auth != null
        && request.auth.uid == resource.data.userId
        && request.resource.data.keys().hasAll(['productId', 'userId', 'content', 'isChild', 'userDisplayName'])
        && request.resource.data.content is string
        && request.resource.data.content.size() > 0
        && request.resource.data.content.size() <= 1000
        && request.resource.data.productId is string
        && request.resource.data.userId == request.auth.uid
        && request.resource.data.isChild is bool;
      
      // Allow update only by the comment owner for content and edited fields
      allow update: if request.auth != null
        && request.auth.uid == resource.data.userId
        && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['content', 'edited', 'editedAt', 'updatedAt']);
      
      // Allow delete only by the comment owner
      allow delete: if request.auth != null
        && request.auth.uid == resource.data.userId;
    }
  }
}
```

### Example Comment Documents

#### Main Comment Example:
```javascript
{
  id: "main_comment_123",
  productId: "laptop_msi_001",
  userId: "user_firebase_uid_123",
  userDisplayName: "Nguyen Van A",
  userAvatar: "https://lh3.googleusercontent.com/...",
  content: "Sản phẩm rất tốt, chất lượng ổn trong tầm giá!",
  isChild: false,
  parentId: null,
  createdAt: Timestamp,
  updatedAt: Timestamp,
  edited: false,
  visible: true,
  flagged: false
}
```

#### Reply Comment Example:
```javascript
{
  id: "reply_comment_456", 
  productId: "laptop_msi_001",
  userId: "user_firebase_uid_456",
  userDisplayName: "Tran Thi B",
  userAvatar: null,
  content: "Bạn đã dùng được bao lâu rồi? Có gặp vấn đề gì không?",
  isChild: true,
  parentId: "main_comment_123",
  createdAt: Timestamp,
  updatedAt: Timestamp,
  edited: false,
  visible: true,
  flagged: false
}
```

### Query Examples

#### Get all comments for a product:
```javascript
db.collection('comments')
  .where('productId', '==', productId)
  .orderBy('createdAt', 'desc')
  .limit(20)
```

#### Get main comments only:
```javascript
db.collection('comments')
  .where('productId', '==', productId)
  .where('isChild', '==', false)
  .orderBy('createdAt', 'desc')
  .limit(10)
```

#### Get replies for a specific comment:
```javascript
db.collection('comments')
  .where('parentId', '==', mainCommentId)
  .orderBy('createdAt', 'asc')
```

#### Real-time listener for new comments:
```javascript
db.collection('comments')
  .where('productId', '==', productId)
  .orderBy('createdAt', 'desc')
  .onSnapshot(snapshot => {
    // Handle real-time updates
  })
```

### Performance Considerations

1. **Pagination:** Use `startAfter()` with `limit()` for efficient pagination
2. **Caching:** Cache user display information to reduce Auth lookups
3. **Real-time:** Use Firestore real-time listeners for live updates
4. **Indexing:** All queries above require composite indexes
5. **Batch Operations:** Use batch writes for comment deletion with replies

### Future Enhancements

1. **Reactions System:** Add like/dislike functionality
2. **Moderation:** Add admin moderation features
3. **Rich Text:** Support for formatted text and links
4. **File Attachments:** Support for image attachments
5. **Mention System:** Tag other users in comments
6. **Thread Depth:** Support for nested reply threads