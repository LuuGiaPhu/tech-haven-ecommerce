const functions = require('firebase-functions');
const { onRequest } = require('firebase-functions/v2/https');
const express = require('express');
const path = require('path');
const admin = require('firebase-admin');

// Initialize Firebase Admin
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(require('./serviceAccountKey.json')),
    projectId: 'tech-haven-5368b'
  });
  console.log('✅ Firebase Admin SDK initialized');
}

const db = admin.firestore();
const auth = admin.auth();

const app = express();

// Express configuration
app.set('trust proxy', 1);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS for API calls
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Debug middleware
app.use((req, res, next) => {
  if (!req.path.includes('.') && !req.path.includes('/js') && !req.path.includes('/css')) {
    console.log(`🌐 ${req.method} ${req.path}`);
    if (req.headers.authorization) {
      console.log('🔑 Has Authorization header');
    }
  }
  next();
});

// Middleware to verify Firebase ID token
async function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    req.user = null;
    return next();
  }
  
  const idToken = authHeader.split('Bearer ')[1];
  
  try {
    console.log('� Verifying ID token...');
    const decodedToken = await auth.verifyIdToken(idToken);
    console.log('✅ Token verified for user:', decodedToken.name);
    
    // Save user info to Firestore if not exists
    const userRef = db.collection('users').doc(decodedToken.uid);
    const userDoc = await userRef.get();
    
    if (!userDoc.exists) {
      const userData = {
        uid: decodedToken.uid,
        email: decodedToken.email,
        name: decodedToken.name,
        photo: decodedToken.picture,
        provider: 'google',
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        lastLoginAt: admin.firestore.FieldValue.serverTimestamp(),
        // Additional fields for e-commerce
        preferences: {
          currency: 'VND',
          language: 'vi',
          notifications: true
        },
        profile: {
          isActive: true,
          membershipLevel: 'bronze',
          totalOrders: 0,
          totalSpent: 0
        },
        addresses: [],
        wishlist: [],
        // Admin privileges - default to false for new users
        is_admin: false
      };
      await userRef.set(userData);
      console.log('💾 New user saved to Firestore with complete profile:', decodedToken.name, '- Admin:', false);
    } else {
      // Update last login and ensure all required fields exist
      const currentData = userDoc.data();
      const updateData = {
        lastLoginAt: admin.firestore.FieldValue.serverTimestamp(),
        // Update user info in case it changed
        name: decodedToken.name,
        email: decodedToken.email,
        photo: decodedToken.picture
      };
      
      // Add missing fields for existing users, but preserve is_admin if it exists
      if (!currentData.preferences) {
        updateData.preferences = {
          currency: 'VND',
          language: 'vi',
          notifications: true
        };
      }
      if (!currentData.profile) {
        updateData.profile = {
          isActive: true,
          membershipLevel: 'bronze',
          totalOrders: currentData.totalOrders || 0,
          totalSpent: currentData.totalSpent || 0
        };
      }
      if (!currentData.addresses) {
        updateData.addresses = [];
      }
      if (!currentData.wishlist) {
        updateData.wishlist = [];
      }
      // Only set is_admin to false if it doesn't exist - preserve existing value
      if (typeof currentData.is_admin === 'undefined') {
        updateData.is_admin = false;
      }
      
      await userRef.update(updateData);
      console.log('🔄 Updated user profile in Firestore:', decodedToken.name, '- Admin:', currentData.is_admin || false);
    }
    
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
      name: decodedToken.name,
      photo: decodedToken.picture,
      provider: decodedToken.firebase.sign_in_provider,
      is_admin: userDoc.exists ? (userDoc.data().is_admin || false) : false
    };
    
  } catch (error) {
    console.error('❌ Token verification failed:', error.message);
    req.user = null;
  }
  
  next();
}

// Middleware to check admin privileges
async function requireAdmin(req, res, next) {
  // Check if token is in query parameter (for direct navigation)
  if (req.query.token && !req.headers.authorization) {
    req.headers.authorization = `Bearer ${req.query.token}`;
    console.log('🔑 Using token from query parameter');
  }
  
  // First verify token
  await new Promise((resolve) => {
    verifyToken(req, res, resolve);
  });
  
  if (!req.user) {
    // Check if it's an API request or web request
    const acceptsJson = req.headers.accept && req.headers.accept.includes('application/json');
    
    if (acceptsJson) {
      return res.status(401).json({ 
        error: 'Authentication required for admin access',
        message: 'Please log in to access this page'
      });
    } else {
      // For web requests, redirect to home with error message
      return res.redirect('/?error=login_required&message=' + encodeURIComponent('Please log in to access admin pages'));
    }
  }
  
  if (!req.user.is_admin) {
    const acceptsJson = req.headers.accept && req.headers.accept.includes('application/json');
    
    if (acceptsJson) {
      return res.status(403).json({ 
        error: 'Admin privileges required',
        message: 'You do not have permission to access this page',
        user: {
          name: req.user.name,
          email: req.user.email,
          is_admin: req.user.is_admin
        }
      });
    } else {
      // For web requests, redirect to home with error message
      return res.redirect('/?error=admin_required&message=' + encodeURIComponent('You do not have admin privileges to access this page'));
    }
  }
  
  console.log('✅ Admin access granted to:', req.user.name);
  next();
}

// Routes
app.get('/', (req, res) => {
  console.log('🏠 Home page - rendering with Firebase Auth support');
  
  // Pass URL query parameters for error messages
  const errorParams = {
    error: req.query.error,
    message: req.query.message
  };
  
  // Sample products for the home page
  const products = [
    {
      id: 1,
      name: "RTX 4070",
      price: "$15.00",
      rating: 5,
      image: "/images/gpu1.jpg"
    },
    {
      id: 2,
      name: "RTX 4080", 
      price: "$24.00",
      rating: 4,
      image: "/images/gpu2.jpg"
    },
    {
      id: 3,
      name: "MOTHERBOARD5",
      price: "$158.00",
      rating: 5,
      image: "/images/keyboard.jpg"
    },
    {
      id: 4,
      name: "Alienware",
      price: "$73.00",
      rating: 4,
      image: "/images/laptop.jpg"
    }
  ];
  
  res.render('index', { 
    products,
    user: null, // Client-side will handle user state
    isAuthenticated: false, // Client-side will handle auth state
    ...errorParams // Pass error parameters to template
  });
});

// Category routes
app.get('/components', (req, res) => {
  res.render('category', { 
    category: 'Components',
    user: null 
  });
});

app.get('/accessories', (req, res) => {
  res.render('category', { 
    category: 'Accessories',
    user: null 
  });
});

app.get('/gaming', (req, res) => {
  res.render('category', { 
    category: 'Gaming',
    user: null 
  });
});

app.get('/desktops', (req, res) => {
  res.render('category', { 
    category: 'Desktops',
    user: null 
  });
});

app.get('/laptops', (req, res) => {
  res.render('category', { 
    category: 'Laptops',
    user: null 
  });
});

app.get('/shop', (req, res) => {
  res.render('shop', { user: null });
});

app.get('/product/:id', (req, res) => {
  const productId = req.params.id;
  
  // Sample product data
  const product = {
    id: productId,
    name: "ASUS ROG Strix G15 Gaming Laptop",
    price: 35990000,
    oldPrice: 39990000,
    category: "laptop",
    brand: "asus",
    rating: 5,
    reviewCount: 152,
    availability: "Còn hàng",
    sku: "ASU-ROG-G15-001",
    description: "Laptop gaming ASUS ROG Strix G15 với hiệu năng mạnh mẽ, thiết kế đẳng cấp và công nghệ tản nhiệt tiên tiến.",
    specifications: {
      cpu: "AMD Ryzen 7 6800H (8 nhân, 16 luồng, 3.2GHz up to 4.7GHz)",
      gpu: "NVIDIA GeForce RTX 3060 6GB GDDR6",
      ram: "16GB DDR5-4800MHz (2x8GB, còn trống 2 slot)",
      storage: "512GB PCIe 4.0 NVMe SSD (còn trống 1 slot M.2)",
      display: "15.6\" FHD (1920x1080) IPS, 144Hz, 100% sRGB"
    },
    features: [
      "Tản nhiệt Intelligent Cooling với 2 quạt Arc Flow",
      "ROG Keystone II để tùy chỉnh profile game",
      "Armoury Crate để điều khiển RGB và hiệu năng"
    ],
    images: ["/images/laptop.jpg"],
    relatedProducts: [
      { id: 2, name: "MSI Katana 17 B13V", price: 28990000, image: "/images/laptop.jpg" }
    ]
  };
  
  res.render('product_detail', { 
    product,
    user: null 
  });
});

// API route to get current user (with token verification)
app.get('/api/user', verifyToken, (req, res) => {
  console.log('� User API called - User:', req.user?.name || 'None');
  
  res.json({
    success: true,
    authenticated: !!req.user,
    user: req.user || null,
    timestamp: new Date().toISOString()
  });
});

// API route for manual user registration (with email verification)
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    
    // Validation
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Vui lòng điền đầy đủ thông tin' });
    }
    
    if (password.length < 6) {
      return res.status(400).json({ error: 'Mật khẩu phải có ít nhất 6 ký tự' });
    }
    
    // Check if user already exists in Firestore
    const existingUserQuery = await db.collection('users').where('email', '==', email).get();
    if (!existingUserQuery.empty) {
      return res.status(400).json({ error: 'Email đã được sử dụng' });
    }
    
    // Create user in Firebase Auth first for email verification
    let firebaseUser;
    try {
      firebaseUser = await auth.createUser({
        email: email,
        password: password,
        displayName: name,
        emailVerified: false
      });
      console.log('✅ Firebase Auth user created:', firebaseUser.uid);
    } catch (authError) {
      console.error('❌ Firebase Auth creation failed:', authError);
      if (authError.code === 'auth/email-already-exists') {
        return res.status(400).json({ error: 'Email đã được sử dụng trong hệ thống' });
      }
      return res.status(500).json({ error: 'Không thể tạo tài khoản xác thực' });
    }
    
    // Generate sequential UID for Firestore
    const usersSnapshot = await db.collection('users').get();
    const userCount = usersSnapshot.size;
    const customUid = `UID${userCount + 1}`;
    
    // Create user document in Firestore
    const userData = {
      uid: customUid,
      firebaseUid: firebaseUser.uid, // Link to Firebase Auth
      email: email,
      name: name,
      provider: 'manual',
      emailVerified: false, // Will be synced from Firebase Auth after verification
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      lastLoginAt: null,
      preferences: {
        currency: 'VND',
        language: 'vi',
        notifications: true
      },
      profile: {
        isActive: false, // Will be activated after email verification
        membershipLevel: 'bronze',
        totalOrders: 0,
        totalSpent: 0
      },
      addresses: [],
      wishlist: [],
      is_admin: false
    };
    
    await db.collection('users').doc(customUid).set(userData);
    console.log('💾 New manual user created in Firestore:', name, 'with UID:', customUid, 'Firebase UID:', firebaseUser.uid);
    
    // Return success and let frontend handle email verification using client SDK
    res.json({
      success: true,
      message: 'Tài khoản đã được tạo thành công! Vui lòng kiểm tra email để xác thực tài khoản.',
      requiresVerification: true,
      user: {
        uid: customUid,
        email: email,
        name: name,
        provider: 'manual',
        emailVerified: false,
        is_admin: false,
        firebaseUid: firebaseUser.uid // Pass Firebase UID for email verification
      },
      emailSent: false // Frontend will handle email sending
    });
    
  } catch (error) {
    console.error('❌ Registration error:', error);
    res.status(500).json({ error: 'Không thể tạo tài khoản. Vui lòng thử lại.' });
  }
});

// Resend email verification
app.post('/api/resend-verification', async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email là bắt buộc'
      });
    }
    
    // Find user by email in Firebase Auth
    const firebaseUser = await auth.getUserByEmail(email);
    
    if (firebaseUser.emailVerified) {
      return res.json({
        success: false,
        message: 'Email đã được xác thực rồi'
      });
    }
    
    // Find user in Firestore to get custom UID
    const usersSnapshot = await db.collection('users')
      .where('firebaseUid', '==', firebaseUser.uid)
      .limit(1)
      .get();
    
    if (usersSnapshot.empty) {
      return res.status(404).json({
        success: false,
        message: 'Không tìm thấy thông tin người dùng'
      });
    }
    
    const userData = usersSnapshot.docs[0].data();
    const customUid = userData.uid;
    
    // Send verification email with custom action URL that redirects to our route
    const actionCodeSettings = {
      url: 'https://app-tb7nq3o2qq-uc.a.run.app/verify-email?uid=' + customUid, // Custom verification URL
      handleCodeInApp: false, // Firebase will handle the verification but redirect to our URL
    };
    
    const emailVerificationLink = await auth.generateEmailVerificationLink(email, actionCodeSettings);
    console.log('📧 Resend email verification link generated and email should be sent by Firebase to:', email);
    
    res.json({
      success: true,
      message: 'Email xác thực đã được gửi lại thành công!'
    });
    
  } catch (error) {
    console.error('❌ Error resending verification email:', error);
    res.status(500).json({
      success: false,
      message: 'Có lỗi xảy ra khi gửi lại email xác thực: ' + error.message
    });
  }
});

// Email verification route (Firebase standard)
app.get('/verify-email', async (req, res) => {
  try {
    const { oobCode, uid } = req.query;
    
    if (!oobCode) {
      return res.status(400).send('Invalid verification link');
    }
    
    // Check the action code first to get user info
    const actionCodeInfo = await auth.checkActionCode(oobCode);
    const email = actionCodeInfo.data.email;
    console.log('📧 Verifying email for:', email);
    
    // Apply the action code to verify email
    await auth.applyActionCode(oobCode);
    console.log('✅ Email verified successfully in Firebase Auth');
    
    // Find and update user in Firestore
    try {
      let userDoc = null;
      
      // First try to find by uid parameter if provided
      if (uid) {
        const userRef = db.collection('users').doc(uid);
        userDoc = await userRef.get();
        console.log('🔍 Searching by UID:', uid, 'Found:', userDoc.exists);
      }
      
      // If not found by uid, search by email
      if (!userDoc || !userDoc.exists) {
        const userQuery = await db.collection('users').where('email', '==', email).limit(1).get();
        if (!userQuery.empty) {
          userDoc = userQuery.docs[0];
          console.log('🔍 Found user by email:', email);
        }
      }
      
      // Update user if found
      if (userDoc && userDoc.exists) {
        await userDoc.ref.update({
          emailVerified: true,
          'profile.isActive': true,
          verifiedAt: admin.firestore.FieldValue.serverTimestamp()
        });
        console.log('✅ User email verified and activated in Firestore:', email, 'UID:', userDoc.id);
      } else {
        console.log('⚠️ User not found in Firestore for email:', email);
        // Create a warning but don't fail the verification
      }
    } catch (firestoreError) {
      console.error('❌ Error updating Firestore after email verification:', firestoreError);
      // Don't fail the verification if Firestore update fails
    }
    
    // Render success page or redirect
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Email Xác Thực Thành Công</title>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5; }
          .container { background: white; padding: 40px; border-radius: 10px; max-width: 500px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .success-icon { font-size: 60px; color: #28a745; margin-bottom: 20px; }
          .title { color: #333; margin-bottom: 20px; }
          .message { color: #666; margin-bottom: 30px; line-height: 1.6; }
          .btn { background: #667eea; color: white; padding: 12px 30px; border: none; border-radius: 5px; text-decoration: none; display: inline-block; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="success-icon">✅</div>
          <h1 class="title">Email Xác Thực Thành Công!</h1>
          <p class="message">Chúc mừng! Email của bạn đã được xác thực thành công. Tài khoản của bạn đã được kích hoạt và bạn có thể đăng nhập để sử dụng dịch vụ.</p>
          <a href="/" class="btn">Về Trang Chủ</a>
        </div>
        <script>
          // Auto redirect after 5 seconds
          setTimeout(() => {
            window.location.href = '/';
          }, 5000);
        </script>
      </body>
      </html>
    `);
    
  } catch (error) {
    console.error('❌ Email verification error:', error);
    
    let errorMessage = 'Có lỗi xảy ra khi xác thực email';
    if (error.code === 'auth/invalid-action-code') {
      errorMessage = 'Link xác thực không hợp lệ hoặc đã hết hạn';
    } else if (error.code === 'auth/expired-action-code') {
      errorMessage = 'Link xác thực đã hết hạn';
    }
    
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Lỗi Xác Thực Email</title>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5; }
          .container { background: white; padding: 40px; border-radius: 10px; max-width: 500px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .error-icon { font-size: 60px; color: #dc3545; margin-bottom: 20px; }
          .title { color: #333; margin-bottom: 20px; }
          .message { color: #666; margin-bottom: 30px; line-height: 1.6; }
          .btn { background: #667eea; color: white; padding: 12px 30px; border: none; border-radius: 5px; text-decoration: none; display: inline-block; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="error-icon">❌</div>
          <h1 class="title">Lỗi Xác Thực Email</h1>
          <p class="message">${errorMessage}. Vui lòng liên hệ support hoặc đăng ký lại.</p>
          <a href="/" class="btn">Về Trang Chủ</a>
        </div>
      </body>
      </html>
    `);
  }
});

// API route for manual user login (without Google)
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Validation
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    
    // Find user by email
    const userQuery = await db.collection('users').where('email', '==', email).get();
    if (userQuery.empty) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    const userDoc = userQuery.docs[0];
    const userData = userDoc.data();
    
    // Check if user was created manually (has Firebase UID for new system or password for old system)
    if (userData.provider !== 'manual') {
      return res.status(401).json({ error: 'Vui lòng sử dụng đăng nhập Google cho tài khoản này' });
    }
    
    // Check email verification for new users (with firebaseUid) using Firebase Auth as source of truth
    if (userData.firebaseUid) {
      try {
        const firebaseUser = await auth.getUser(userData.firebaseUid);
        if (!firebaseUser.emailVerified) {
          return res.status(403).json({ 
            error: 'Email chưa được xác thực. Vui lòng kiểm tra email và click vào link xác thực.',
            requiresVerification: true 
          });
        }
        
        // Update Firestore to match Firebase Auth status if needed
        if (!userData.emailVerified) {
          await userDoc.ref.update({
            emailVerified: true,
            'profile.isActive': true,
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          });
          console.log('✅ Updated Firestore emailVerified status to match Firebase Auth');
        }
      } catch (authError) {
        console.error('❌ Error checking Firebase Auth user:', authError);
        return res.status(500).json({ error: 'Không thể xác thực trạng thái email' });
      }
    }
    
    // For old manual users (before email verification was implemented)
    if (userData.password) {
      // Verify password (simple base64 decode for demo - use bcrypt in production)
      const storedPassword = Buffer.from(userData.password, 'base64').toString();
      if (storedPassword !== password) {
        return res.status(401).json({ error: 'Email hoặc mật khẩu không đúng' });
      }
    } else if (userData.firebaseUid) {
      // For new users, authenticate with Firebase Auth
      try {
        const userRecord = await auth.getUserByEmail(email);
        if (!userRecord.emailVerified) {
          return res.status(401).json({ 
            error: 'Email chưa được xác thực. Vui lòng kiểm tra email và click vào link xác thực.',
            requiresVerification: true
          });
        }
        
        // Update Firestore if email verification status changed
        if (!userData.emailVerified && userRecord.emailVerified) {
          await userDoc.ref.update({
            emailVerified: true,
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          });
          console.log('✅ Updated Firestore email verification status for:', userData.email);
        }
        
        // Additional password verification would be done by Firebase client-side
      } catch (authError) {
        console.error('Error verifying Firebase user:', authError);
        return res.status(401).json({ error: 'Tài khoản không hợp lệ' });
      }
    } else {
      return res.status(401).json({ error: 'Tài khoản không hợp lệ' });
    }
    
    // Update last login
    await userDoc.ref.update({
      lastLoginAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    console.log('✅ Manual login successful for:', userData.name);
    
    res.json({
      success: true,
      message: 'Login successful',
      user: {
        uid: userData.uid,
        email: userData.email,
        name: userData.name,
        provider: userData.provider,
        is_admin: userData.is_admin || false
      }
    });
    
  } catch (error) {
    console.error('❌ Login error:', error);
    res.status(500).json({ error: 'Failed to login' });
  }
});

// API route to save additional user data
app.post('/api/user/update', verifyToken, async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  try {
    const { displayName, preferences } = req.body;
    const userRef = db.collection('users').doc(req.user.uid);
    
    await userRef.update({
      ...(displayName && { displayName }),
      ...(preferences && { preferences }),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    res.json({
      success: true,
      message: 'User updated successfully'
    });
    
  } catch (error) {
    console.error('❌ Error updating user:', error);
    res.status(500).json({ error: error.message });
  }
});

// API route to get full user profile from Firestore
app.get('/api/user/profile', verifyToken, async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  try {
    const userRef = db.collection('users').doc(req.user.uid);
    const userDoc = await userRef.get();
    
    if (userDoc.exists) {
      const userData = userDoc.data();
      res.json({
        success: true,
        profile: userData,
        lastUpdated: userData.updatedAt?.toDate?.() || userData.createdAt?.toDate?.()
      });
    } else {
      res.status(404).json({ error: 'User profile not found' });
    }
  } catch (error) {
    console.error('❌ Error fetching user profile:', error);
    res.status(500).json({ error: 'Failed to fetch user profile' });
  }
});

// API route to add item to wishlist
app.post('/api/user/wishlist', verifyToken, async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  try {
    const { productId, productName, productPrice, productImage } = req.body;
    const userRef = db.collection('users').doc(req.user.uid);
    
    await userRef.update({
      wishlist: admin.firestore.FieldValue.arrayUnion({
        productId,
        productName,
        productPrice,
        productImage,
        addedAt: new Date().toISOString()
      }),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    res.json({ success: true, message: 'Item added to wishlist' });
  } catch (error) {
    console.error('❌ Error adding to wishlist:', error);
    res.status(500).json({ error: 'Failed to add to wishlist' });
  }
});

// API route to get user statistics
app.get('/api/user/stats', verifyToken, async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  try {
    const userRef = db.collection('users').doc(req.user.uid);
    const userDoc = await userRef.get();
    
    if (userDoc.exists) {
      const userData = userDoc.data();
      res.json({
        success: true,
        stats: {
          memberSince: userData.createdAt?.toDate?.(),
          lastLogin: userData.lastLoginAt?.toDate?.(),
          totalOrders: userData.profile?.totalOrders || 0,
          totalSpent: userData.profile?.totalSpent || 0,
          membershipLevel: userData.profile?.membershipLevel || 'bronze',
          wishlistCount: userData.wishlist?.length || 0,
          addressCount: userData.addresses?.length || 0
        }
      });
    } else {
      res.status(404).json({ error: 'User profile not found' });
    }
  } catch (error) {
    console.error('❌ Error fetching user stats:', error);
    res.status(500).json({ error: 'Failed to fetch user statistics' });
  }
});

// Debug route to check token
app.post('/api/debug/token', async (req, res) => {
  const { idToken } = req.body;
  
  if (!idToken) {
    return res.json({ error: 'No token provided' });
  }
  
  try {
    const decodedToken = await auth.verifyIdToken(idToken);
    res.json({
      success: true,
      decoded: {
        uid: decodedToken.uid,
        email: decodedToken.email,
        name: decodedToken.name,
        picture: decodedToken.picture,
        provider: decodedToken.firebase.sign_in_provider,
        exp: new Date(decodedToken.exp * 1000),
        iat: new Date(decodedToken.iat * 1000)
      }
    });
  } catch (error) {
    res.json({
      error: error.message,
      code: error.code
    });
  }
});

// API route to check admin status
app.get('/api/user/admin-status', verifyToken, (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  res.json({
    success: true,
    user: {
      uid: req.user.uid,
      name: req.user.name,
      email: req.user.email,
      is_admin: req.user.is_admin
    },
    timestamp: new Date().toISOString()
  });
});

// API route to set admin status (only existing admins can promote others)
app.post('/api/user/set-admin', requireAdmin, async (req, res) => {
  try {
    const { userEmail, isAdmin } = req.body;
    
    if (!userEmail) {
      return res.status(400).json({ error: 'User email is required' });
    }
    
    // Find user by email
    const usersQuery = await db.collection('users').where('email', '==', userEmail).get();
    
    if (usersQuery.empty) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const userDoc = usersQuery.docs[0];
    await userDoc.ref.update({
      is_admin: !!isAdmin,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      adminUpdatedBy: req.user.email,
      adminUpdatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    console.log(`👑 Admin status updated for ${userEmail} to ${!!isAdmin} by ${req.user.email}`);
    
    res.json({
      success: true,
      message: `Admin status updated for ${userEmail}`,
      newStatus: !!isAdmin,
      updatedBy: req.user.email
    });
    
  } catch (error) {
    console.error('❌ Error updating admin status:', error);
    res.status(500).json({ error: 'Failed to update admin status' });
  }
});

// Debug route to test token verification
app.get('/debug/auth', async (req, res) => {
  const authHeader = req.headers.authorization;
  console.log('� Debug Auth Route');
  console.log('� Authorization header:', authHeader ? 'Present' : 'Missing');
  
  if (!authHeader) {
    return res.json({
      error: 'No Authorization header',
      message: 'Send request with "Authorization: Bearer <idToken>"',
      headers: req.headers
    });
  }
  
  try {
    const idToken = authHeader.split('Bearer ')[1];
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    console.log('✅ Token verified for user:', decodedToken.name);
    
    res.json({
      success: true,
      user: {
        uid: decodedToken.uid,
        name: decodedToken.name,
        email: decodedToken.email,
        picture: decodedToken.picture
      }
    });
  } catch (error) {
    console.error('❌ Token verification failed:', error.message);
    res.status(401).json({ error: 'Invalid token', details: error.message });
  }
});

// Admin routes (protected by admin privileges)
app.get('/admin', requireAdmin, (req, res) => {
  res.render('input', { user: req.user });
});

app.get('/admin/input', requireAdmin, (req, res) => {
  res.render('input', { user: req.user });
});

app.get('/admin/edit', requireAdmin, (req, res) => {
  res.render('edit', { 
    productId: null,
    user: req.user 
  });
});

app.get('/admin/edit/:productId', requireAdmin, (req, res) => {
  const productId = req.params.productId;
  res.render('edit', { 
    productId: productId,
    user: req.user 
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    service: 'Firebase Auth Demo'
  });
});

exports.app = onRequest(app);
