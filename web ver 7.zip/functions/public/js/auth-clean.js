/**
 * CLEAN AUTH FRONTEND - Simplified JavaScript
 * Chỉ gọi API, không xử lý logic phức tạp
 */

// Global variables
let currentUser = null;
let isAuthenticated = false;

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Clean Auth Frontend initialized');
    loadUserData();
});

/**
 * Load user data từ API
 */
async function loadUserData() {
    try {
        console.log('📡 Loading user data from API...');
        const response = await fetch('/api/user');
        const data = await response.json();
        
        if (data.success) {
            currentUser = data.user;
            isAuthenticated = data.authenticated;
            
            console.log('✅ User data loaded:', {
                authenticated: isAuthenticated,
                user: currentUser ? currentUser.name : 'None'
            });
            
            updateUI();
        } else {
            console.error('❌ Failed to load user data:', data.error);
            handleUnauthenticated();
        }
    } catch (error) {
        console.error('❌ Error loading user data:', error);
        handleUnauthenticated();
    }
}

/**
 * Update UI based on authentication status
 */
function updateUI() {
    updateUserIcon();
    updateUserProfile();
    updateNavigationButtons();
}

/**
 * Update user icon in navigation
 */
async function updateUserIcon() {
    try {
        const response = await fetch('/api/user-icon');
        const data = await response.json();
        
        if (data.success) {
            const container = document.getElementById('userIconContainer');
            if (container) {
                container.innerHTML = data.html;
                console.log('✅ User icon updated');
            }
        }
    } catch (error) {
        console.error('❌ Error updating user icon:', error);
    }
}

/**
 * Update user profile panel
 */
function updateUserProfile() {
    if (!isAuthenticated || !currentUser) return;
    
    // Update avatar
    const avatarImg = document.querySelector('.user-avatar img');
    if (avatarImg && currentUser.photo) {
        avatarImg.src = currentUser.photo;
        avatarImg.alt = currentUser.name;
    }
    
    // Update name
    const nameElement = document.querySelector('.user-info h3');
    if (nameElement) {
        nameElement.textContent = currentUser.name;
    }
    
    // Update email
    const emailElement = document.querySelector('.user-info p');
    if (emailElement) {
        emailElement.textContent = currentUser.email;
    }
    
    console.log('✅ User profile updated');
}

/**
 * Update navigation buttons
 */
function updateNavigationButtons() {
    // Ẩn/hiện các nút dựa trên authentication status
    const loginButtons = document.querySelectorAll('.login-button');
    const userButtons = document.querySelectorAll('.user-button');
    
    loginButtons.forEach(btn => {
        btn.style.display = isAuthenticated ? 'none' : 'block';
    });
    
    userButtons.forEach(btn => {
        btn.style.display = isAuthenticated ? 'block' : 'none';
    });
}

/**
 * Handle unauthenticated state
 */
function handleUnauthenticated() {
    currentUser = null;
    isAuthenticated = false;
    console.log('❌ User not authenticated');
    updateUI();
}

/**
 * Open user profile panel
 */
function openUserProfile() {
    console.log('👤 Opening user profile panel');
    const panel = document.getElementById('userProfilePanel');
    if (panel) {
        panel.classList.add('active');
        console.log('✅ User profile panel opened');
    } else {
        console.log('❌ User profile panel not found');
    }
}

/**
 * Close user profile panel
 */
function closeUserProfile() {
    console.log('❌ Closing user profile panel');
    const panel = document.getElementById('userProfilePanel');
    if (panel) {
        panel.classList.remove('active');
        console.log('✅ User profile panel closed');
    }
}

/**
 * Logout user
 */
async function logoutUser() {
    try {
        console.log('👋 Logging out user...');
        const response = await fetch('/api/logout', { method: 'POST' });
        const data = await response.json();
        
        if (data.success) {
            console.log('✅ Logout successful');
            window.location.reload(); // Reload page để clear state
        } else {
            console.error('❌ Logout failed:', data.error);
            alert('Đăng xuất thất bại. Vui lòng thử lại.');
        }
    } catch (error) {
        console.error('❌ Logout error:', error);
        alert('Lỗi khi đăng xuất. Vui lòng thử lại.');
    }
}

/**
 * Redirect to Google login
 */
function loginWithGoogle() {
    console.log('🔐 Redirecting to Google login');
    window.location.href = '/auth/google';
}

/**
 * Show user menu dropdown
 */
function showUserMenu() {
    if (!isAuthenticated || !currentUser) return;
    
    const menu = document.createElement('div');
    menu.id = 'userDropdown';
    menu.className = 'user-dropdown';
    menu.innerHTML = `
        <div class="dropdown-content">
            <div class="user-info-dropdown">
                <img src="${currentUser.photo || '/images/default-avatar.png'}" alt="${currentUser.name}">
                <div>
                    <div class="user-name">${currentUser.name}</div>
                    <div class="user-email">${currentUser.email}</div>
                </div>
            </div>
            <hr>
            <a href="#" onclick="openUserProfile()">
                <i class="fas fa-user"></i> Hồ sơ cá nhân
            </a>
            <a href="#" onclick="viewOrderHistory()">
                <i class="fas fa-shopping-bag"></i> Lịch sử đơn hàng
            </a>
            ${currentUser.role === 'admin' ? '<a href="/admin"><i class="fas fa-cog"></i> Admin Panel</a>' : ''}
            <hr>
            <a href="#" onclick="logoutUser()">
                <i class="fas fa-sign-out-alt"></i> Đăng xuất
            </a>
        </div>
    `;
    
    // Remove existing dropdown
    const existing = document.getElementById('userDropdown');
    if (existing) existing.remove();
    
    // Add new dropdown
    document.body.appendChild(menu);
    
    // Close on click outside
    setTimeout(() => {
        document.addEventListener('click', function closeDropdown(e) {
            if (!e.target.closest('#userDropdown')) {
                const dropdown = document.getElementById('userDropdown');
                if (dropdown) dropdown.remove();
                document.removeEventListener('click', closeDropdown);
            }
        });
    }, 100);
    
    console.log('✅ User menu displayed');
}

/**
 * Placeholder functions
 */
function editUserProfile() {
    console.log('✏️ Edit user profile clicked');
    alert('Chức năng chỉnh sửa hồ sơ đang được phát triển!');
}

function viewOrderHistory() {
    console.log('📋 View order history clicked');
    alert('Chức năng xem lịch sử đơn hàng đang được phát triển!');
}

// Make functions globally available
window.openUserProfile = openUserProfile;
window.closeUserProfile = closeUserProfile;
window.logoutUser = logoutUser;
window.loginWithGoogle = loginWithGoogle;
window.showUserMenu = showUserMenu;
window.editUserProfile = editUserProfile;
window.viewOrderHistory = viewOrderHistory;