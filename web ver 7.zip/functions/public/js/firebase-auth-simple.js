// Simple Firebase Auth without ES6 modules for better compatibility
console.log('🔐 Loading simplified Firebase Auth...');

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDpzgsxZ1Jfs5hWAfS-gDbYfgkVte_jXoA",
  authDomain: "tech-haven-5368b.firebaseapp.com",
  projectId: "tech-haven-5368b",
  storageBucket: "tech-haven-5368b.firebasestorage.app",
  messagingSenderId: "442337591630",
  appId: "1:442337591630:web:7005525c7664f513a55e1f",
  measurementId: "G-N54V96PG4M"
};

// Simple Firebase Auth implementation
let firebaseAuth = null;
let currentUser = null;

// Initialize Firebase Auth when Firebase is loaded
function initializeFirebaseAuth() {
    try {
        if (typeof firebase === 'undefined') {
            console.error('❌ Firebase SDK not loaded');
            return;
        }
        
        // Initialize Firebase
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }
        
        firebaseAuth = firebase.auth();
        console.log('✅ Firebase Auth initialized');
        
        // Listen for auth state changes
        firebaseAuth.onAuthStateChanged((user) => {
            console.log('🔍 Auth state changed:', user ? user.displayName : 'No user');
            currentUser = user;
            updateUI(user);
            
            if (user) {
                // Get ID token for API calls
                user.getIdToken().then((idToken) => {
                    localStorage.setItem('firebase-id-token', idToken);
                    console.log('✅ ID token stored');
                }).catch((error) => {
                    console.error('❌ Error getting ID token:', error);
                });
            } else {
                localStorage.removeItem('firebase-id-token');
            }
        });
        
        // Set up button event listeners
        setupEventListeners();
        
    } catch (error) {
        console.error('❌ Firebase Auth initialization error:', error);
    }
}

// Google Sign In
async function signInWithGoogle() {
    try {
        console.log('🔍 Starting Google sign in...');
        
        if (!firebaseAuth) {
            throw new Error('Firebase Auth not initialized');
        }
        
        const provider = new firebase.auth.GoogleAuthProvider();
        const result = await firebaseAuth.signInWithPopup(provider);
        
        console.log('✅ Google sign in successful:', result.user.displayName);
        return { success: true, user: result.user };
    } catch (error) {
        console.error('❌ Google sign in error:', error);
        return { success: false, error };
    }
}

// Sign Out
async function signOut() {
    try {
        console.log('🔍 Signing out...');
        await firebaseAuth.signOut();
        console.log('✅ Sign out successful');
        return { success: true };
    } catch (error) {
        console.error('❌ Sign out error:', error);
        return { success: false, error };
    }
}

// Update UI based on auth state
function updateUI(user) {
    console.log('🔄 Updating UI for user:', user ? user.displayName : 'No user');
    
    // Update login/logout buttons
    const loginBtn = document.getElementById('google-login-btn');
    const registerBtn = document.getElementById('google-register-btn');
    const logoutBtn = document.getElementById('logout-btn');
    
    if (user) {
        // User is logged in
        if (loginBtn) loginBtn.style.display = 'none';
        if (registerBtn) registerBtn.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'inline-block';
        
        // You can add more UI updates here
        console.log('✅ UI updated for logged in user');
    } else {
        // User is logged out
        if (loginBtn) loginBtn.style.display = 'inline-block';
        if (registerBtn) registerBtn.style.display = 'inline-block';
        if (logoutBtn) logoutBtn.style.display = 'none';
        
        console.log('✅ UI updated for logged out user');
    }
}

// Set up event listeners
function setupEventListeners() {
    console.log('🔄 Setting up event listeners...');
    
    // Google login button (in login modal)
    const loginBtn = document.getElementById('google-login-btn');
    if (loginBtn) {
        loginBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            console.log('🔍 Login button clicked');
            const result = await signInWithGoogle();
            if (result.success) {
                console.log('✅ Login successful, reloading page...');
                window.location.reload();
            } else {
                alert('Đăng nhập thất bại: ' + result.error.message);
            }
        });
        console.log('✅ Login button listener added');
    }
    
    // Google register button (in register modal)
    const registerBtn = document.getElementById('google-register-btn');
    if (registerBtn) {
        registerBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            console.log('🔍 Register button clicked');
            const result = await signInWithGoogle();
            if (result.success) {
                console.log('✅ Registration/Login successful, reloading page...');
                window.location.reload();
            } else {
                alert('Đăng ký thất bại: ' + result.error.message);
            }
        });
        console.log('✅ Register button listener added');
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            console.log('🔍 Logout button clicked');
            const result = await signOut();
            if (result.success) {
                console.log('✅ Logout successful, reloading page...');
                window.location.reload();
            }
        });
        console.log('✅ Logout button listener added');
    }
    
    console.log('✅ Event listeners setup complete');
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('🔄 DOM ready, initializing Firebase Auth...');
    
    // Wait a bit for Firebase SDK to load
    setTimeout(() => {
        initializeFirebaseAuth();
    }, 1000);
});

// Also try to initialize if Firebase is already loaded
if (typeof firebase !== 'undefined') {
    initializeFirebaseAuth();
}

console.log('🔐 Firebase Auth Simple script loaded');