// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
    // Cute Loading Screen Controller
    const loadingScreen = document.getElementById('loadingScreen');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const progressPercentage = document.getElementById('progressPercentage');
    
    // Thêm class loading cho body và html ngay lập tức
    document.body.classList.add('loading');
    document.documentElement.classList.add('loading');
    
    // Ẩn tất cả nội dung khác ngay lập tức
    const allElements = document.querySelectorAll('body > *:not(.loading-screen)');
    allElements.forEach(element => {
        element.style.display = 'none';
        element.style.visibility = 'hidden';
    });
    
    // Đảm bảo loading screen hiển thị trên cùng
    if (loadingScreen) {
        loadingScreen.style.zIndex = '999999';
        loadingScreen.style.position = 'fixed';
        loadingScreen.style.top = '0';
        loadingScreen.style.left = '0';
        loadingScreen.style.width = '100%';
        loadingScreen.style.height = '100%';
        loadingScreen.style.display = 'flex';
    }
    
    // Cute loading messages với emoji
    const cuteMessages = [
        '🤖 Robot đang khởi động...',
        '🔧 Đang lắp ráp linh kiện...',
        '🎮 Chuẩn bị game gear...',
        '✨ Tạo phép màu công nghệ...',
        '🚀 Sắp sẵn sàng rồi...',
        '🎉 Chào mừng đến Tech Haven!'
    ];
    
    let progress = 0;
    let currentMessageIndex = 0;
    
    function updateCuteProgress() {
        // Tăng progress một cách tự nhiên
        progress += Math.random() *75 + 5; 
        
        if (progress >= 100) {
            progress = 100;
            progressFill.style.width = '100%';
            progressPercentage.textContent = '100%';
            progressText.textContent = cuteMessages[5];
            
            // Animation vui nhộn khi hoàn thành
            setTimeout(() => {
                loadingScreen.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    // Hiện lại tất cả nội dung web
                    document.body.classList.remove('loading');
                    document.documentElement.classList.remove('loading');
                    
                    // Khôi phục visibility của body
                    document.body.style.visibility = 'visible';
                    
                    // Hiện lại tất cả element với display phù hợp
                    allElements.forEach(element => {
                        element.style.display = '';
                        element.style.visibility = '';
                        element.style.opacity = '';
                        
                        // Khôi phục display phù hợp cho các element khác nhau
                        if (element.tagName === 'HEADER' || element.tagName === 'SECTION' || element.tagName === 'FOOTER') {
                            element.style.display = 'block';
                        }
                    });
                    
                    // Ẩn loading screen
                    loadingScreen.classList.add('hidden');
                    document.body.style.overflow = 'auto';
                    document.documentElement.style.overflow = 'auto';
                    
                    // Dọn dẹp DOM
                    setTimeout(() => {
                        if (loadingScreen && loadingScreen.parentNode) {
                            loadingScreen.parentNode.removeChild(loadingScreen);
                        }
                    }, 800);
                }, 300);
            }, 500);
            return;
        }
        
        // Update progress bar và percentage
        progressFill.style.width = progress + '%';
        progressPercentage.textContent = Math.round(progress) + '%';
        
        // Update cute message
        const messageIndex = Math.floor((progress / 100) * (cuteMessages.length - 1));
        if (messageIndex !== currentMessageIndex && messageIndex < cuteMessages.length - 1) {
            currentMessageIndex = messageIndex;
            progressText.textContent = cuteMessages[messageIndex];
            
            // Cute bounce effect khi đổi message
            progressText.style.transform = 'scale(1.1)';
            setTimeout(() => {
                progressText.style.transform = 'scale(1)';
            }, 200);
        }
        
        // Tiếp tục với timing ngẫu nhiên
        setTimeout(updateCuteProgress, Math.random() * 500 + 400);
    }
    
    // Bắt đầu loading với delay để tạo cảm giác tự nhiên
    setTimeout(() => {
        updateCuteProgress();
    }, 800);
    
    // Safety fallback - force hide sau 8 giây
    setTimeout(() => {
        if (loadingScreen && !loadingScreen.classList.contains('hidden')) {
            // Hiện lại tất cả nội dung web
            document.body.classList.remove('loading');
            document.documentElement.classList.remove('loading');
            document.body.style.visibility = 'visible';
            
            allElements.forEach(element => {
                element.style.display = '';
                element.style.visibility = '';
                element.style.opacity = '';
                
                if (element.tagName === 'HEADER' || element.tagName === 'SECTION' || element.tagName === 'FOOTER') {
                    element.style.display = 'block';
                }
            });
            
            loadingScreen.classList.add('hidden');
            document.body.style.overflow = 'auto';
            document.documentElement.style.overflow = 'auto';
            
            setTimeout(() => {
                if (loadingScreen && loadingScreen.parentNode) {
                    loadingScreen.parentNode.removeChild(loadingScreen);
                }
            }, 800);
        }
    }, 8000);

    // Mobile Menu Toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (mobileMenuToggle && navMenu) {
        mobileMenuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            
            // Change hamburger icon
            const icon = this.querySelector('i');
            if (navMenu.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });

        // Close menu when clicking on menu items
        const menuItems = navMenu.querySelectorAll('a');
        menuItems.forEach(item => {
            item.addEventListener('click', () => {
                navMenu.classList.remove('active');
                const icon = mobileMenuToggle.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            });
        });

        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!mobileMenuToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('active');
                const icon = mobileMenuToggle.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    }

    // Banner Carousel - Completely Rewritten
    class BannerCarousel {
        constructor() {
            this.slides = document.querySelectorAll('.banner-slide');
            this.dots = document.querySelectorAll('.banner-dot');
            this.prevBtn = document.querySelector('.banner-prev');
            this.nextBtn = document.querySelector('.banner-next');
            this.currentSlide = 0;
            this.totalSlides = this.slides.length;
            this.isAnimating = false;
            this.autoPlayInterval = null;
            
            this.init();
        }

        init() {
            if (this.slides.length === 0) return;
            
            // Set up event listeners
            this.prevBtn?.addEventListener('click', () => this.prevSlide());
            this.nextBtn?.addEventListener('click', () => this.nextSlide());
            
            this.dots.forEach((dot, index) => {
                dot.addEventListener('click', () => this.goToSlide(index));
            });

            // Keyboard navigation
            document.addEventListener('keydown', (e) => {
                if (e.key === 'ArrowLeft') this.prevSlide();
                if (e.key === 'ArrowRight') this.nextSlide();
            });

            // Touch/Swipe support
            this.setupTouchEvents();

            // Auto-play
            this.startAutoPlay();

            // Pause on hover
            const bannerContainer = document.querySelector('.banner-container');
            bannerContainer?.addEventListener('mouseenter', () => this.stopAutoPlay());
            bannerContainer?.addEventListener('mouseleave', () => this.startAutoPlay());

            // Initialize first slide
            this.updateSlide();
        }

        goToSlide(index) {
            if (this.isAnimating || index === this.currentSlide) return;
            
            this.currentSlide = index;
            this.updateSlide();
            this.resetAutoPlay();
        }

        nextSlide() {
            if (this.isAnimating) return;
            
            this.currentSlide = (this.currentSlide + 1) % this.totalSlides;
            this.updateSlide();
            this.resetAutoPlay();
        }

        prevSlide() {
            if (this.isAnimating) return;
            
            this.currentSlide = (this.currentSlide - 1 + this.totalSlides) % this.totalSlides;
            this.updateSlide();
            this.resetAutoPlay();
        }

        updateSlide() {
            this.isAnimating = true;

            // Update slides
            this.slides.forEach((slide, index) => {
                slide.classList.toggle('active', index === this.currentSlide);
            });

            // Update dots
            this.dots.forEach((dot, index) => {
                dot.classList.toggle('active', index === this.currentSlide);
            });

            // Reset animation flag after transition
            setTimeout(() => {
                this.isAnimating = false;
            }, 600);
        }

        startAutoPlay() {
            this.autoPlayInterval = setInterval(() => {
                this.nextSlide();
            }, 5000);
        }

        stopAutoPlay() {
            if (this.autoPlayInterval) {
                clearInterval(this.autoPlayInterval);
                this.autoPlayInterval = null;
            }
        }

        resetAutoPlay() {
            this.stopAutoPlay();
            this.startAutoPlay();
        }

        setupTouchEvents() {
            const container = document.querySelector('.banner-container');
            if (!container) return;

            let startX = 0;
            let endX = 0;

            container.addEventListener('touchstart', (e) => {
                startX = e.touches[0].clientX;
            });

            container.addEventListener('touchend', (e) => {
                endX = e.changedTouches[0].clientX;
                const diff = startX - endX;
                const threshold = 50;

                if (Math.abs(diff) > threshold) {
                    if (diff > 0) {
                        this.nextSlide();
                    } else {
                        this.prevSlide();
                    }
                }
            });
        }
    }

    // Initialize banner carousel
    const bannerCarousel = new BannerCarousel();

    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Add smooth transition effect
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });

    // Product card hover effects
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });

    // Add to cart functionality
    const addToCartBtns = document.querySelectorAll('.add-to-cart');
    addToCartBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Animation effect
            this.style.transform = 'scale(0.9)';
            this.textContent = 'ADDED!';
            this.style.background = 'linear-gradient(135deg, #10b981, #059669)';
            
            setTimeout(() => {
                this.style.transform = 'scale(1)';
                this.textContent = 'ADD TO CART';
                this.style.background = 'linear-gradient(135deg, #f472b6, #ec4899)';
            }, 1500);
        });
    });

    // Build options functionality
    const buildOptions = document.querySelectorAll('.build-option');
    buildOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            buildOptions.forEach(opt => opt.classList.remove('active'));
            
            // Add active class to clicked option
            this.classList.add('active');
            
            // Add click animation
            this.style.transform = 'scale(0.9)';
            setTimeout(() => {
                this.style.transform = this.classList.contains('active') ? 'scale(1.1)' : 'scale(1)';
            }, 150);
        });
    });

    // Shop Now button functionality
    const shopBtn = document.querySelector('.shop-btn');
    if (shopBtn) {
        shopBtn.addEventListener('click', function() {
            // Scroll to featured products section
            const featuredSection = document.querySelector('.featured-products');
            if (featuredSection) {
                featuredSection.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    }

    // Header scroll effect
    const header = document.querySelector('.header');
    let lastScrollY = window.scrollY;

    window.addEventListener('scroll', () => {
        const currentScrollY = window.scrollY;
        
        if (currentScrollY > 100) {
            header.style.background = 'rgba(255, 255, 255, 0.98)';
            header.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.15)';
        } else {
            header.style.background = 'rgba(255, 255, 255, 0.95)';
            header.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.1)';
        }
        
        lastScrollY = currentScrollY;
    });

    // Parallax effect for hero section (disabled to prevent overlap)
    // window.addEventListener('scroll', () => {
    //     const scrolled = window.pageYOffset;
    //     const parallax = document.querySelector('.hero');
    //     if (parallax) {
    //         const speed = scrolled * 0.5;
    //         parallax.style.transform = `translateY(${speed}px)`;
    //     }
    // });

    // Animation on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const animateElements = document.querySelectorAll('.product-card, .build-option');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });

    // Search functionality (placeholder)
    const searchIcon = document.querySelector('.fa-search');
    if (searchIcon) {
        searchIcon.addEventListener('click', function() {
            alert('Search functionality coming soon!');
        });
    }

    // Cart functionality (placeholder)
    const cartIcon = document.querySelector('.fa-shopping-cart');
    if (cartIcon) {
        cartIcon.addEventListener('click', function() {
            alert('Cart functionality coming soon!');
        });
    }

    // User account functionality (placeholder)
    const userIcon = document.querySelector('.fa-user');
    if (userIcon) {
        userIcon.addEventListener('click', function() {
            alert('User account functionality coming soon!');
        });
    }

    // Add loading animation
    window.addEventListener('load', function() {
        document.body.classList.add('loaded');
        
        // Remove any conflicting transforms
        const hero = document.querySelector('.hero');
        if (hero) {
            hero.style.transform = 'none';
        }
        
        // Animate elements on page load
        const heroContent = document.querySelector('.hero-content');
        if (heroContent) {
            heroContent.style.opacity = '0';
            heroContent.style.transform = 'translateY(50px)';
            setTimeout(() => {
                heroContent.style.transition = 'opacity 1s ease, transform 1s ease';
                heroContent.style.opacity = '1';
                heroContent.style.transform = 'translateY(0)';
            }, 300);
        }
    });

    // =====================================
    // SHOPPING CART FUNCTIONALITY
    // =====================================

    let cartItems = [];
    let cartCount = 0;

    // Add to cart function
    function addToCart(productName, productPrice) {
        const existingItem = cartItems.find(item => item.name === productName);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cartItems.push({
                name: productName,
                price: productPrice,
                quantity: 1,
                image: getProductIcon(productName)
            });
        }
        
        cartCount++;
        updateCartUI();
        showCartNotification(productName);
    }

    // Remove from cart
    function removeFromCart(productName) {
        const itemIndex = cartItems.findIndex(item => item.name === productName);
        if (itemIndex > -1) {
            const item = cartItems[itemIndex];
            cartCount -= item.quantity;
            cartItems.splice(itemIndex, 1);
            updateCartUI();
        }
    }

    // Update quantity
    function updateCartQuantity(productName, newQuantity) {
        const item = cartItems.find(item => item.name === productName);
        if (item) {
            const oldQuantity = item.quantity;
            item.quantity = Math.max(1, newQuantity);
            cartCount += (item.quantity - oldQuantity);
            updateCartUI();
        }
    }

    // Get product icon
    function getProductIcon(productName) {
        const name = productName.toLowerCase();
        if (name.includes('cpu') || name.includes('core')) return 'fas fa-microchip';
        if (name.includes('gpu') || name.includes('rtx') || name.includes('gtx')) return 'fas fa-memory';
        if (name.includes('laptop')) return 'fas fa-laptop';
        if (name.includes('monitor') || name.includes('màn hình')) return 'fas fa-desktop';
        if (name.includes('keyboard') || name.includes('bàn phím')) return 'fas fa-keyboard';
        if (name.includes('mouse') || name.includes('chuột')) return 'fas fa-mouse';
        if (name.includes('headset') || name.includes('tai nghe')) return 'fas fa-headset';
        if (name.includes('ssd') || name.includes('nvme') || name.includes('hdd')) return 'fas fa-hdd';
        if (name.includes('ram') || name.includes('memory')) return 'fas fa-memory';
        return 'fas fa-cube';
    }

    // Update cart UI
    function updateCartUI() {
        // Update cart badge
        const cartBadge = document.getElementById('cartBadge');
        const cartCountSpan = document.getElementById('cartCount');
        
        if (cartBadge) {
            cartBadge.textContent = cartCount;
            cartBadge.style.display = cartCount > 0 ? 'flex' : 'none';
        }
        
        if (cartCountSpan) {
            cartCountSpan.textContent = cartCount;
        }

        // Update cart items display
        const cartItemsContainer = document.getElementById('cartItems');
        if (cartItemsContainer) {
            if (cartItems.length === 0) {
                cartItemsContainer.innerHTML = `
                    <div class="empty-cart">
                        <i class="fas fa-shopping-cart" style="font-size: 3rem; color: #ccc;"></i>
                        <p>Giỏ hàng của bạn đang trống</p>
                    </div>
                `;
            } else {
                cartItemsContainer.innerHTML = cartItems.map(item => `
                    <div class="cart-item">
                        <div class="cart-item-image">
                            <i class="${item.image}"></i>
                        </div>
                        <div class="cart-item-details">
                            <div class="cart-item-name">${item.name}</div>
                            <div class="cart-item-price">${item.price}</div>
                            <div class="cart-item-controls">
                                <button class="quantity-btn" onclick="updateCartQuantity('${item.name}', ${item.quantity - 1})">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <span class="cart-item-quantity">${item.quantity}</span>
                                <button class="quantity-btn" onclick="updateCartQuantity('${item.name}', ${item.quantity + 1})">
                                    <i class="fas fa-plus"></i>
                                </button>
                                <button class="remove-item" onclick="removeFromCart('${item.name}')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                `).join('');
            }
        }

        // Update cart total
        const total = calculateCartTotal();
        const cartTotalElement = document.getElementById('cartTotal');
        if (cartTotalElement) {
            cartTotalElement.textContent = formatPrice(total) + ' VNĐ';
        }

        // Update checkout button
        const checkoutBtn = document.getElementById('checkoutBtn');
        if (checkoutBtn) {
            checkoutBtn.disabled = cartItems.length === 0;
        }
    }

    // Calculate cart total
    function calculateCartTotal() {
        return cartItems.reduce((total, item) => {
            const price = parseInt(item.price.replace(/[^\d]/g, ''));
            return total + (price * item.quantity);
        }, 0);
    }

    // Format price
    function formatPrice(price) {
        return new Intl.NumberFormat('vi-VN').format(price);
    }

    // Toggle cart sidebar
    function toggleCart() {
        const cartSidebar = document.getElementById('cartSidebar');
        const cartOverlay = document.getElementById('cartOverlay');
        
        if (cartSidebar && cartOverlay) {
            cartSidebar.classList.toggle('active');
            cartOverlay.classList.toggle('active');
        }
    }

    // Show cart notification
    function showCartNotification(productName) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'cart-notification';
        notification.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>Đã thêm "${productName}" vào giỏ hàng!</span>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            z-index: 10000;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            max-width: 300px;
            font-weight: 500;
        `;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Auto remove
        setTimeout(() => {
            notification.style.transform = 'translateX(400px)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Proceed to checkout
    function proceedToCheckout() {
        if (cartItems.length === 0) return;
        
        const checkoutModal = document.getElementById('checkoutModal');
        if (checkoutModal) {
            checkoutModal.classList.add('active');
            updateOrderSummary();
        }
    }

    // Close checkout modal
    function closeCheckoutModal() {
        const checkoutModal = document.getElementById('checkoutModal');
        if (checkoutModal) {
            checkoutModal.classList.remove('active');
        }
    }

    // Update order summary
    function updateOrderSummary() {
        const orderSummaryItems = document.getElementById('orderSummaryItems');
        const subtotalAmount = document.getElementById('subtotalAmount');
        const finalTotal = document.getElementById('finalTotal');
        
        if (orderSummaryItems) {
            orderSummaryItems.innerHTML = cartItems.map(item => `
                <div class="order-item">
                    <span class="order-item-name">${item.name} x${item.quantity}</span>
                    <span class="order-item-price">${formatPrice(parseInt(item.price.replace(/[^\d]/g, '')) * item.quantity)} VNĐ</span>
                </div>
            `).join('');
        }
        
        const subtotal = calculateCartTotal();
        const shipping = 50000;
        const total = subtotal + shipping;
        
        if (subtotalAmount) subtotalAmount.textContent = formatPrice(subtotal) + ' VNĐ';
        if (finalTotal) finalTotal.textContent = formatPrice(total) + ' VNĐ';
    }

    // Complete order
    function completeOrder() {
        const customerName = document.getElementById('customerName').value;
        const customerPhone = document.getElementById('customerPhone').value;
        const customerEmail = document.getElementById('customerEmail').value;
        const shippingAddress = document.getElementById('shippingAddress').value;
        const shippingCity = document.getElementById('shippingCity').value;
        const shippingDistrict = document.getElementById('shippingDistrict').value;
        const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
        
        // Validate form
        if (!customerName || !customerPhone || !customerEmail || !shippingAddress || !shippingCity || !shippingDistrict) {
            alert('Vui lòng điền đầy đủ thông tin!');
            return;
        }
        
        // Simulate order processing
        const loadingOverlay = document.createElement('div');
        loadingOverlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10001;
            color: white;
            font-size: 1.2rem;
        `;
        loadingOverlay.innerHTML = `
            <div style="text-align: center;">
                <div style="width: 50px; height: 50px; border: 3px solid #fff; border-top: 3px solid transparent; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 1rem;"></div>
                <div>Đang xử lý đơn hàng...</div>
            </div>
        `;
        
        // Add spin animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
        
        document.body.appendChild(loadingOverlay);
        
        // Simulate processing time
        setTimeout(() => {
            document.body.removeChild(loadingOverlay);
            document.head.removeChild(style);
            
            // Show success message
            alert(`🎉 Đơn hàng đã được đặt thành công!\n\nMã đơn hàng: TH${Date.now()}\nTổng tiền: ${formatPrice(calculateCartTotal() + 50000)} VNĐ\n\nChúng tôi sẽ liên hệ với bạn trong vòng 24h để xác nhận đơn hàng.`);
            
            // Reset cart and close modal
            cartItems = [];
            cartCount = 0;
            updateCartUI();
            closeCheckoutModal();
            toggleCart();
            
            // Reset form
            document.getElementById('customerName').value = '';
            document.getElementById('customerPhone').value = '';
            document.getElementById('customerEmail').value = '';
            document.getElementById('shippingAddress').value = '';
            document.getElementById('shippingCity').value = '';
            document.getElementById('shippingDistrict').value = '';
        }, 2000);
    }

    // Build PC function
    function proceedToBuild() {
        alert('🔧 Tính năng xây dựng PC sẽ sớm có mặt!\n\nBạn có thể liên hệ hotline 1800-1234 để được tư vấn trực tiếp từ chuyên gia của chúng tôi.');
    }

    // Product section navigation
    function setupProductNavigation() {
        const navArrows = document.querySelectorAll('.nav-arrow');
        
        navArrows.forEach(arrow => {
            arrow.addEventListener('click', function() {
                const section = this.dataset.section;
                const container = document.getElementById(`${section}-container`);
                const scrollAmount = 300;
                
                if (container) {
                    if (this.classList.contains('prev')) {
                        container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
                    } else {
                        container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
                    }
                }
            });
        });
    }

    // Initialize all functions
    setupProductNavigation();

    // Make functions global
    window.addToCart = addToCart;
    window.removeFromCart = removeFromCart;
    window.updateCartQuantity = updateCartQuantity;
    window.toggleCart = toggleCart;
    window.proceedToCheckout = proceedToCheckout;
    window.closeCheckoutModal = closeCheckoutModal;
    window.completeOrder = completeOrder;
    window.proceedToBuild = proceedToBuild;

    // Close cart when clicking overlay
    document.addEventListener('click', function(e) {
        if (e.target.id === 'cartOverlay') {
            toggleCart();
        }
    });

    // Close modal when clicking overlay
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-overlay')) {
            closeCheckoutModal();
        }
    });
});
