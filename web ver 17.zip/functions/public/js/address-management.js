// =====================================
//       ADDRESS MANAGEMENT
// =====================================

// Global variables for address management
let userAddresses = [];
let selectedAddress = null;
let isEditingAddress = false;
let editingAddressIndex = -1;

// Load user addresses on page load
async function loadUserAddresses() {
    if (!window.currentUser) {
        console.log('👤 No authenticated user - cannot load addresses');
        return;
    }
    
    try {
        const token = await window.getIdToken();
        const response = await fetch('/api/user/addresses', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            userAddresses = data.addresses || [];
            console.log('✅ Loaded user addresses:', userAddresses.length);
            renderAddressList();
            
            // Auto-select default address if exists
            const defaultAddress = userAddresses.find(addr => addr.isDefault);
            if (defaultAddress) {
                selectAddress(userAddresses.indexOf(defaultAddress));
            }
        } else {
            console.error('❌ Error loading addresses:', response.status);
        }
    } catch (error) {
        console.error('❌ Error loading addresses:', error);
    }
}

// Render address list in checkout modal
function renderAddressList() {
    const addressList = document.getElementById('addressList');
    const noAddresses = document.getElementById('noAddresses');
    
    if (!addressList) return;
    
    if (userAddresses.length === 0) {
        addressList.innerHTML = '';
        if (noAddresses) noAddresses.style.display = 'block';
        return;
    }
    
    if (noAddresses) noAddresses.style.display = 'none';
    
    addressList.innerHTML = userAddresses.map((address, index) => `
        <div class="address-item ${address.isDefault ? 'default' : ''} ${selectedAddress === index ? 'selected' : ''}" 
             onclick="selectAddress(${index})">
            <div class="address-details">
                <div class="address-text">
                    <strong>${address.address}</strong><br>
                    ${address.district}, ${getCityName(address.city)}
                </div>
                <div class="address-actions">
                    ${!address.isDefault ? `
                        <button class="address-action-btn set-default" onclick="event.stopPropagation(); setDefaultAddress(${index})" title="Đặt làm mặc định">
                            <i class="fas fa-star"></i>
                        </button>
                    ` : ''}
                    <button class="address-action-btn" onclick="event.stopPropagation(); editAddress(${index})" title="Chỉnh sửa">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="address-action-btn delete" onclick="event.stopPropagation(); deleteAddress(${index})" title="Xóa">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Select address for checkout
function selectAddress(index) {
    selectedAddress = index;
    renderAddressList();
    
    // Show selected address display
    const selectedAddressDisplay = document.getElementById('selectedAddressDisplay');
    const selectedAddressText = document.getElementById('selectedAddressText');
    const savedAddresses = document.getElementById('savedAddresses');
    
    if (selectedAddressDisplay && selectedAddressText && savedAddresses) {
        const address = userAddresses[index];
        selectedAddressText.innerHTML = `
            <strong>${address.address}</strong><br>
            ${address.district}, ${getCityName(address.city)}
        `;
        
        selectedAddressDisplay.style.display = 'block';
        savedAddresses.style.display = 'none';
    }
}

// Change selected address (show address list again)
function changeSelectedAddress() {
    const selectedAddressDisplay = document.getElementById('selectedAddressDisplay');
    const savedAddresses = document.getElementById('savedAddresses');
    
    if (selectedAddressDisplay && savedAddresses) {
        selectedAddressDisplay.style.display = 'none';
        savedAddresses.style.display = 'block';
    }
}

// Toggle new address form
function toggleNewAddressForm() {
    const newAddressForm = document.getElementById('newAddressForm');
    const addressFormTitle = document.getElementById('addressFormTitle');
    
    if (newAddressForm) {
        const isVisible = newAddressForm.style.display === 'block';
        newAddressForm.style.display = isVisible ? 'none' : 'block';
        
        if (!isVisible) {
            // Reset form for new address
            isEditingAddress = false;
            editingAddressIndex = -1;
            if (addressFormTitle) addressFormTitle.textContent = 'Thêm địa chỉ mới';
            clearAddressForm();
        }
    }
}

// Cancel address form
function cancelAddressForm() {
    const newAddressForm = document.getElementById('newAddressForm');
    if (newAddressForm) {
        newAddressForm.style.display = 'none';
        clearAddressForm();
        isEditingAddress = false;
        editingAddressIndex = -1;
    }
}

// Clear address form
function clearAddressForm() {
    const fields = ['newShippingAddress', 'newShippingCity', 'newShippingDistrict'];
    fields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) field.value = '';
    });
    
    const setAsDefault = document.getElementById('setAsDefault');
    if (setAsDefault) setAsDefault.checked = false;
}

// Save new or edited address
async function saveNewAddress() {
    if (!window.currentUser) {
        alert('Vui lòng đăng nhập để lưu địa chỉ');
        return;
    }
    
    // Get form values
    const address = document.getElementById('newShippingAddress')?.value.trim();
    const city = document.getElementById('newShippingCity')?.value;
    const district = document.getElementById('newShippingDistrict')?.value.trim();
    const setAsDefault = document.getElementById('setAsDefault')?.checked || false;
    
    // Validation
    if (!address || !city || !district) {
        alert('Vui lòng điền đầy đủ thông tin địa chỉ');
        return;
    }
    
    try {
        const token = await window.getIdToken();
        const addressData = {
            address,
            city,
            district,
            isDefault: setAsDefault
        };
        
        let response;
        if (isEditingAddress && editingAddressIndex >= 0) {
            // Update existing address
            response = await fetch(`/api/user/addresses/${editingAddressIndex}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(addressData)
            });
        } else {
            // Add new address
            response = await fetch('/api/user/addresses', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(addressData)
            });
        }
        
        if (response.ok) {
            const result = await response.json();
            console.log('✅ Address saved successfully');
            
            // Reload addresses and update UI
            await loadUserAddresses();
            cancelAddressForm();
            
            // Show success message
            if (window.showNotification) {
                window.showNotification(
                    isEditingAddress ? 'Địa chỉ đã được cập nhật!' : 'Địa chỉ mới đã được lưu!', 
                    'success'
                );
            }
        } else {
            const error = await response.json();
            console.error('❌ Error saving address:', error);
            alert(error.error || 'Không thể lưu địa chỉ. Vui lòng thử lại.');
        }
    } catch (error) {
        console.error('❌ Error saving address:', error);
        alert('Có lỗi xảy ra khi lưu địa chỉ. Vui lòng thử lại.');
    }
}

// Edit existing address
function editAddress(index) {
    if (index < 0 || index >= userAddresses.length) return;
    
    const address = userAddresses[index];
    isEditingAddress = true;
    editingAddressIndex = index;
    
    // Fill form with existing data
    const addressField = document.getElementById('newShippingAddress');
    const cityField = document.getElementById('newShippingCity');
    const districtField = document.getElementById('newShippingDistrict');
    const defaultField = document.getElementById('setAsDefault');
    const formTitle = document.getElementById('addressFormTitle');
    
    if (addressField) addressField.value = address.address;
    if (cityField) cityField.value = address.city;
    if (districtField) districtField.value = address.district;
    if (defaultField) defaultField.checked = address.isDefault;
    if (formTitle) formTitle.textContent = 'Chỉnh sửa địa chỉ';
    
    // Show form
    toggleNewAddressForm();
}

// Set address as default
async function setDefaultAddress(index) {
    if (!window.currentUser || index < 0 || index >= userAddresses.length) return;
    
    try {
        const token = await window.getIdToken();
        const response = await fetch(`/api/user/addresses/${index}/set-default`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            console.log('✅ Default address updated');
            
            // Update UI immediately - remove default class from all addresses
            const addressItems = document.querySelectorAll('.address-item');
            addressItems.forEach((item, itemIndex) => {
                if (itemIndex === index) {
                    // Add default class to new default address
                    item.classList.add('default');
                    // Update the address data
                    userAddresses[itemIndex].isDefault = true;
                } else {
                    // Remove default class from other addresses
                    item.classList.remove('default');
                    // Update the address data
                    if (userAddresses[itemIndex]) {
                        userAddresses[itemIndex].isDefault = false;
                    }
                }
            });
            
            // Also reload addresses to ensure data consistency (but UI already updated)
            setTimeout(() => {
                loadUserAddresses();
            }, 1000);
            
            if (window.showNotification) {
                window.showNotification('Địa chỉ mặc định đã được cập nhật!', 'success');
            }
        } else {
            const error = await response.json();
            console.error('❌ Error setting default address:', error);
            alert(error.error || 'Không thể đặt địa chỉ mặc định.');
        }
    } catch (error) {
        console.error('❌ Error setting default address:', error);
        alert('Có lỗi xảy ra. Vui lòng thử lại.');
    }
}

// Delete address
async function deleteAddress(index) {
    if (!window.currentUser || index < 0 || index >= userAddresses.length) return;
    
    const address = userAddresses[index];
    if (!confirm(`Bạn có chắc chắn muốn xóa địa chỉ này?\n\n${address.address}\n${address.district}, ${getCityName(address.city)}`)) {
        return;
    }
    
    try {
        const token = await window.getIdToken();
        const response = await fetch(`/api/user/addresses/${index}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            console.log('✅ Address deleted successfully');
            await loadUserAddresses();
            
            // Reset selected address if it was deleted
            if (selectedAddress === index) {
                selectedAddress = null;
                const selectedAddressDisplay = document.getElementById('selectedAddressDisplay');
                const savedAddresses = document.getElementById('savedAddresses');
                
                if (selectedAddressDisplay && savedAddresses) {
                    selectedAddressDisplay.style.display = 'none';
                    savedAddresses.style.display = 'block';
                }
            } else if (selectedAddress > index) {
                selectedAddress--;
            }
            
            if (window.showNotification) {
                window.showNotification('Địa chỉ đã được xóa!', 'success');
            }
        } else {
            const error = await response.json();
            console.error('❌ Error deleting address:', error);
            alert(error.error || 'Không thể xóa địa chỉ.');
        }
    } catch (error) {
        console.error('❌ Error deleting address:', error);
        alert('Có lỗi xảy ra khi xóa địa chỉ. Vui lòng thử lại.');
    }
}

// Get city display name from city code
function getCityName(cityCode) {
    const cityMap = {
        'hanoi': 'Hà Nội',
        'hcm': 'TP. Hồ Chí Minh',
        'danang': 'Đà Nẵng',
        'haiphong': 'Hải Phòng',
        'cantho': 'Cần Thơ',
        'angiang': 'An Giang',
        'bacgiang': 'Bắc Giang',
        'backan': 'Bắc Kạn',
        'baclieu': 'Bạc Liêu',
        'bacninh': 'Bắc Ninh',
        'baria': 'Bà Rịa - Vũng Tàu',
        'bentre': 'Bến Tre',
        'binhdinh': 'Bình Định',
        'binhduong': 'Bình Dương',
        'binhphuoc': 'Bình Phước',
        'binhthuan': 'Bình Thuận',
        'camau': 'Cà Mau',
        'caobang': 'Cao Bằng',
        'daklak': 'Đắk Lắk',
        'daknong': 'Đắk Nông',
        'dienbien': 'Điện Biên',
        'dongnai': 'Đồng Nai',
        'dongthap': 'Đồng Tháp',
        'gialai': 'Gia Lai',
        'hagiang': 'Hà Giang',
        'hanam': 'Hà Nam',
        'hatinh': 'Hà Tĩnh',
        'haiduong': 'Hải Dương',
        'haugiang': 'Hậu Giang',
        'hoabinh': 'Hòa Bình',
        'hungyen': 'Hưng Yên',
        'khanhhoa': 'Khánh Hòa',
        'kiengiang': 'Kiên Giang',
        'kontum': 'Kon Tum',
        'laichau': 'Lai Châu',
        'lamdong': 'Lâm Đồng',
        'langson': 'Lạng Sơn',
        'laocai': 'Lào Cai',
        'longan': 'Long An',
        'namdinh': 'Nam Định',
        'nghean': 'Nghệ An',
        'ninhbinh': 'Ninh Bình',
        'ninhthuan': 'Ninh Thuận',
        'phutho': 'Phú Thọ',
        'phuyen': 'Phú Yên',
        'quangbinh': 'Quảng Bình',
        'quangnam': 'Quảng Nam',
        'quangngai': 'Quảng Ngãi',
        'quangninh': 'Quảng Ninh',
        'quangtri': 'Quảng Trị',
        'soctrang': 'Sóc Trăng',
        'sonla': 'Sơn La',
        'tayninh': 'Tây Ninh',
        'thaibinh': 'Thái Bình',
        'thainguyen': 'Thái Nguyên',
        'thanhhoa': 'Thanh Hóa',
        'thuathienhue': 'Thừa Thiên Huế',
        'tiengiang': 'Tiền Giang',
        'travinh': 'Trà Vinh',
        'tuyenquang': 'Tuyên Quang',
        'vinhlong': 'Vĩnh Long',
        'vinhphuc': 'Vĩnh Phúc',
        'yenbai': 'Yên Bái'
    };
    return cityMap[cityCode] || cityCode;
}

// Initialize address management when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Load addresses when checkout modal is opened
    const checkoutModal = document.getElementById('checkoutModal');
    if (checkoutModal) {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    if (checkoutModal.classList.contains('active')) {
                        // Modal opened - load addresses
                        loadUserAddresses();
                    }
                }
            });
        });
        
        observer.observe(checkoutModal, { attributes: true });
    }
});

// Make address management functions globally available
window.toggleNewAddressForm = toggleNewAddressForm;
window.cancelAddressForm = cancelAddressForm;
window.saveNewAddress = saveNewAddress;
window.selectAddress = selectAddress;
window.changeSelectedAddress = changeSelectedAddress;
window.editAddress = editAddress;
window.setDefaultAddress = setDefaultAddress;
window.deleteAddress = deleteAddress;
window.loadUserAddresses = loadUserAddresses;