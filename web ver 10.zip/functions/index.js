const functions = require('firebase-functions');
const { onRequest } = require('firebase-functions/v2/https');
const express = require('express');
const path = require('path');
const admin = require('firebase-admin');

// Initialize Firebase Admin
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(require('./serviceAccountKey.json')),
    projectId: 'tech-haven-5368b'
  });
  console.log('✅ Firebase Admin SDK initialized');
}

const db = admin.firestore();
const auth = admin.auth();

const app = express();

// Express configuration
app.set('trust proxy', 1);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS for API calls
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Debug middleware
app.use((req, res, next) => {
  if (!req.path.includes('.') && !req.path.includes('/js') && !req.path.includes('/css')) {
    console.log(`🌐 ${req.method} ${req.path}`);
    if (req.headers.authorization) {
      console.log('🔑 Has Authorization header');
    }
  }
  next();
});

// Middleware to verify Firebase ID token
async function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    req.user = null;
    return next();
  }
  
  const idToken = authHeader.split('Bearer ')[1];
  
  try {
    console.log('� Verifying ID token...');
    const decodedToken = await auth.verifyIdToken(idToken);
    console.log('✅ Token verified for user:', decodedToken.name);
    
    // Save user info to Firestore if not exists
    const userRef = db.collection('users').doc(decodedToken.uid);
    const userDoc = await userRef.get();
    
    if (!userDoc.exists) {
      const userData = {
        uid: decodedToken.uid,
        email: decodedToken.email,
        name: decodedToken.name,
        photo: decodedToken.picture,
        provider: 'google',
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        lastLoginAt: admin.firestore.FieldValue.serverTimestamp(),
        // Additional fields for e-commerce
        preferences: {
          currency: 'VND',
          language: 'vi',
          notifications: true
        },
        profile: {
          isActive: true,
          membershipLevel: 'bronze',
          totalOrders: 0,
          totalSpent: 0
        },
        addresses: [],
        wishlist: [],
        // Admin privileges - default to false for new users
        is_admin: false
      };
      await userRef.set(userData);
      console.log('💾 New user saved to Firestore with complete profile:', decodedToken.name, '- Admin:', false);
    } else {
      // Update last login and ensure all required fields exist
      const currentData = userDoc.data();
      const updateData = {
        lastLoginAt: admin.firestore.FieldValue.serverTimestamp(),
        // Update user info in case it changed
        name: decodedToken.name,
        email: decodedToken.email,
        photo: decodedToken.picture
      };
      
      // Add missing fields for existing users, but preserve is_admin if it exists
      if (!currentData.preferences) {
        updateData.preferences = {
          currency: 'VND',
          language: 'vi',
          notifications: true
        };
      }
      if (!currentData.profile) {
        updateData.profile = {
          isActive: true,
          membershipLevel: 'bronze',
          totalOrders: currentData.totalOrders || 0,
          totalSpent: currentData.totalSpent || 0
        };
      }
      if (!currentData.addresses) {
        updateData.addresses = [];
      }
      if (!currentData.wishlist) {
        updateData.wishlist = [];
      }
      // Only set is_admin to false if it doesn't exist - preserve existing value
      if (typeof currentData.is_admin === 'undefined') {
        updateData.is_admin = false;
      }
      
      await userRef.update(updateData);
      console.log('🔄 Updated user profile in Firestore:', decodedToken.name, '- Admin:', currentData.is_admin || false);
    }
    
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
      name: decodedToken.name,
      photo: decodedToken.picture,
      provider: decodedToken.firebase.sign_in_provider,
      is_admin: userDoc.exists ? (userDoc.data().is_admin || false) : false
    };
    
  } catch (error) {
    console.error('❌ Token verification failed:', error.message);
    req.user = null;
  }
  
  next();
}

// Middleware to check admin privileges
async function requireAdmin(req, res, next) {
  // Check if token is in query parameter (for direct navigation)
  if (req.query.token && !req.headers.authorization) {
    req.headers.authorization = `Bearer ${req.query.token}`;
    console.log('🔑 Using token from query parameter');
  }
  
  // First verify token
  await new Promise((resolve) => {
    verifyToken(req, res, resolve);
  });
  
  if (!req.user) {
    // Check if it's an API request or web request
    const acceptsJson = req.headers.accept && req.headers.accept.includes('application/json');
    
    if (acceptsJson) {
      return res.status(401).json({ 
        error: 'Authentication required for admin access',
        message: 'Please log in to access this page'
      });
    } else {
      // For web requests, redirect to home with error message
      return res.redirect('/?error=login_required&message=' + encodeURIComponent('Please log in to access admin pages'));
    }
  }
  
  if (!req.user.is_admin) {
    const acceptsJson = req.headers.accept && req.headers.accept.includes('application/json');
    
    if (acceptsJson) {
      return res.status(403).json({ 
        error: 'Admin privileges required',
        message: 'You do not have permission to access this page',
        user: {
          name: req.user.name,
          email: req.user.email,
          is_admin: req.user.is_admin
        }
      });
    } else {
      // For web requests, redirect to home with error message
      return res.redirect('/?error=admin_required&message=' + encodeURIComponent('You do not have admin privileges to access this page'));
    }
  }
  
  console.log('✅ Admin access granted to:', req.user.name);
  next();
}

// Routes
app.get('/', (req, res) => {
  console.log('🏠 Home page - rendering with Firebase Auth support');
  
  // Pass URL query parameters for error messages
  const errorParams = {
    error: req.query.error,
    message: req.query.message
  };
  
  // Sample products for the home page
  const products = [
    {
      id: 1,
      name: "RTX 4070",
      price: "$15.00",
      rating: 5,
      image: "/images/gpu1.jpg"
    },
    {
      id: 2,
      name: "RTX 4080", 
      price: "$24.00",
      rating: 4,
      image: "/images/gpu2.jpg"
    },
    {
      id: 3,
      name: "MOTHERBOARD5",
      price: "$158.00",
      rating: 5,
      image: "/images/keyboard.jpg"
    },
    {
      id: 4,
      name: "Alienware",
      price: "$73.00",
      rating: 4,
      image: "/images/laptop.jpg"
    }
  ];
  
  res.render('index', { 
    products,
    user: null, // Client-side will handle user state
    isAuthenticated: false, // Client-side will handle auth state
    ...errorParams // Pass error parameters to template
  });
});

// Category routes
app.get('/components', (req, res) => {
  res.render('category', { 
    category: 'Components',
    user: null 
  });
});

app.get('/accessories', (req, res) => {
  res.render('category', { 
    category: 'Accessories',
    user: null 
  });
});

app.get('/gaming', (req, res) => {
  res.render('category', { 
    category: 'Gaming',
    user: null 
  });
});

app.get('/desktops', (req, res) => {
  res.render('category', { 
    category: 'Desktops',
    user: null 
  });
});

app.get('/laptops', (req, res) => {
  res.render('category', { 
    category: 'Laptops',
    user: null 
  });
});

app.get('/shop', (req, res) => {
  res.render('shop', { user: null });
});

// Edit Profile route
app.get('/edit-profile', (req, res) => {
  res.render('edit-profile', { user: null });
});

app.get('/product/:id', (req, res) => {
  const productId = req.params.id;
  
  // Sample product data
  const product = {
    id: productId,
    name: "ASUS ROG Strix G15 Gaming Laptop",
    price: 35990000,
    oldPrice: 39990000,
    category: "laptop",
    brand: "asus",
    rating: 5,
    reviewCount: 152,
    availability: "Còn hàng",
    sku: "ASU-ROG-G15-001",
    description: "Laptop gaming ASUS ROG Strix G15 với hiệu năng mạnh mẽ, thiết kế đẳng cấp và công nghệ tản nhiệt tiên tiến.",
    specifications: {
      cpu: "AMD Ryzen 7 6800H (8 nhân, 16 luồng, 3.2GHz up to 4.7GHz)",
      gpu: "NVIDIA GeForce RTX 3060 6GB GDDR6",
      ram: "16GB DDR5-4800MHz (2x8GB, còn trống 2 slot)",
      storage: "512GB PCIe 4.0 NVMe SSD (còn trống 1 slot M.2)",
      display: "15.6\" FHD (1920x1080) IPS, 144Hz, 100% sRGB"
    },
    features: [
      "Tản nhiệt Intelligent Cooling với 2 quạt Arc Flow",
      "ROG Keystone II để tùy chỉnh profile game",
      "Armoury Crate để điều khiển RGB và hiệu năng"
    ],
    images: ["/images/laptop.jpg"],
    relatedProducts: [
      { id: 2, name: "MSI Katana 17 B13V", price: 28990000, image: "/images/laptop.jpg" }
    ]
  };
  
  res.render('product_detail', { 
    product,
    user: null 
  });
});

// API route to get current user (with token verification)
app.get('/api/user', verifyToken, (req, res) => {
  console.log('� User API called - User:', req.user?.name || 'None');
  
  res.json({
    success: true,
    authenticated: !!req.user,
    user: req.user || null,
    timestamp: new Date().toISOString()
  });
});

// API route for manual user registration (with email verification)
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    
    // Validation
    if (!name || !email || !phone || !password) {
      return res.status(400).json({ error: 'Vui lòng điền đầy đủ thông tin' });
    }
    
    if (password.length < 6) {
      return res.status(400).json({ error: 'Mật khẩu phải có ít nhất 6 ký tự' });
    }
    
    // Validate phone number (Vietnamese format)
    const cleanPhone = phone.replace(/\s+/g, '').replace(/[-().]/g, '');
    const phoneRegex = /^(\+84|84|0)?(3[2-9]|5[689]|7[06-9]|8[1-689]|9[0-46-9])[0-9]{7}$/;
    if (!phoneRegex.test(cleanPhone)) {
      return res.status(400).json({ error: 'Số điện thoại không hợp lệ' });
    }
    
    // Check if user already exists in Firestore (by email or phone)
    const existingUserQuery = await db.collection('users').where('email', '==', email).get();
    if (!existingUserQuery.empty) {
      return res.status(400).json({ error: 'Email đã được sử dụng' });
    }
    
    const existingPhoneQuery = await db.collection('users').where('phone', '==', cleanPhone).get();
    if (!existingPhoneQuery.empty) {
      return res.status(400).json({ error: 'Số điện thoại đã được sử dụng' });
    }
    
    // Create user in Firebase Auth first for email verification
    let firebaseUser;
    try {
      firebaseUser = await auth.createUser({
        email: email,
        password: password,
        displayName: name,
        emailVerified: false
      });
      console.log('✅ Firebase Auth user created:', firebaseUser.uid);
    } catch (authError) {
      console.error('❌ Firebase Auth creation failed:', authError);
      if (authError.code === 'auth/email-already-exists') {
        return res.status(400).json({ error: 'Email đã được sử dụng trong hệ thống' });
      }
      return res.status(500).json({ error: 'Không thể tạo tài khoản xác thực' });
    }
    
    // Generate sequential UID for Firestore
    const usersSnapshot = await db.collection('users').get();
    const userCount = usersSnapshot.size;
    const customUid = `UID${userCount + 1}`;
    
    // Create user document in Firestore (password handled by Firebase Auth only)
    const userData = {
      uid: customUid,
      firebaseUid: firebaseUser.uid, // Link to Firebase Auth
      email: email,
      name: name,
      phone: cleanPhone, // Store cleaned phone number
      provider: 'manual',
      emailVerified: false, // Will be synced from Firebase Auth after verification
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      lastLoginAt: null,
      preferences: {
        currency: 'VND',
        language: 'vi',
        notifications: true
      },
      profile: {
        isActive: false, // Will be activated after email verification
        membershipLevel: 'bronze',
        totalOrders: 0,
        totalSpent: 0
      },
      addresses: [],
      wishlist: [],
      is_admin: false
    };
    
    await db.collection('users').doc(customUid).set(userData);
    console.log('💾 New manual user created in Firestore:', name, 'with UID:', customUid, 'Firebase UID:', firebaseUser.uid);
    
    // Return success and let frontend handle email verification using client SDK
    res.json({
      success: true,
      message: 'Tài khoản đã được tạo thành công! Vui lòng kiểm tra email để xác thực tài khoản.',
      requiresVerification: true,
      user: {
        uid: customUid,
        email: email,
        name: name,
        phone: cleanPhone,
        provider: 'manual',
        emailVerified: false,
        is_admin: false,
        firebaseUid: firebaseUser.uid // Pass Firebase UID for email verification
      },
      emailSent: false // Frontend will handle email sending
    });
    
  } catch (error) {
    console.error('❌ Registration error:', error);
    res.status(500).json({ error: 'Không thể tạo tài khoản. Vui lòng thử lại.' });
  }
});

// Resend email verification
app.post('/api/resend-verification', async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email là bắt buộc'
      });
    }
    
    // Find user by email in Firebase Auth
    const firebaseUser = await auth.getUserByEmail(email);
    
    if (firebaseUser.emailVerified) {
      return res.json({
        success: false,
        message: 'Email đã được xác thực rồi'
      });
    }
    
    // Find user in Firestore to get custom UID
    const usersSnapshot = await db.collection('users')
      .where('firebaseUid', '==', firebaseUser.uid)
      .limit(1)
      .get();
    
    if (usersSnapshot.empty) {
      return res.status(404).json({
        success: false,
        message: 'Không tìm thấy thông tin người dùng'
      });
    }
    
    const userData = usersSnapshot.docs[0].data();
    const customUid = userData.uid;
    
    // Send verification email with custom action URL that redirects to our route
    const actionCodeSettings = {
      url: 'https://app-tb7nq3o2qq-uc.a.run.app/verify-email?uid=' + customUid, // Custom verification URL
      handleCodeInApp: false, // Firebase will handle the verification but redirect to our URL
    };
    
    const emailVerificationLink = await auth.generateEmailVerificationLink(email, actionCodeSettings);
    console.log('📧 Resend email verification link generated and email should be sent by Firebase to:', email);
    
    res.json({
      success: true,
      message: 'Email xác thực đã được gửi lại thành công!'
    });
    
  } catch (error) {
    console.error('❌ Error resending verification email:', error);
    res.status(500).json({
      success: false,
      message: 'Có lỗi xảy ra khi gửi lại email xác thực: ' + error.message
    });
  }
});

// Password reset route (Firebase standard)
app.get('/reset-password', async (req, res) => {
  try {
    const { oobCode, mode } = req.query;
    
    if (mode !== 'resetPassword') {
      return res.status(400).send('Invalid reset mode');
    }
    
    if (!oobCode) {
      return res.status(400).send('Invalid reset link');
    }
    
    // Verify the password reset code and get email
    try {
      const email = await auth.checkActionCode(oobCode);
      console.log('🔒 Password reset requested for:', email.data.email);
      
      // Render password reset form
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Đặt Lại Mật Khẩu - Tech Haven</title>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              font-family: Arial, sans-serif; 
              text-align: center; 
              padding: 50px; 
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              min-height: 100vh;
              margin: 0;
              display: flex;
              align-items: center;
              justify-content: center;
            }
            .container { 
              background: white; 
              padding: 40px; 
              border-radius: 15px; 
              max-width: 500px; 
              width: 100%;
              box-shadow: 0 8px 25px rgba(0,0,0,0.15); 
            }
            .lock-icon { font-size: 60px; color: #667eea; margin-bottom: 20px; }
            .title { color: #333; margin-bottom: 10px; font-size: 24px; }
            .subtitle { color: #666; margin-bottom: 30px; line-height: 1.6; }
            .form-group { margin-bottom: 20px; text-align: left; }
            .form-group label { display: block; margin-bottom: 8px; color: #333; font-weight: 500; }
            .form-group input { 
              width: 100%; 
              padding: 12px; 
              border: 2px solid #e1e5e9; 
              border-radius: 8px; 
              font-size: 16px;
              box-sizing: border-box;
              transition: border-color 0.3s;
            }
            .form-group input:focus { 
              outline: none; 
              border-color: #667eea; 
            }
            .btn { 
              background: #667eea; 
              color: white; 
              padding: 12px 30px; 
              border: none; 
              border-radius: 8px; 
              cursor: pointer; 
              font-size: 16px;
              width: 100%;
              margin-bottom: 15px;
              transition: background 0.3s;
            }
            .btn:hover { background: #5a6fd8; }
            .btn-secondary { 
              background: #6c757d; 
              text-decoration: none; 
              display: inline-block; 
              text-align: center;
            }
            .btn-secondary:hover { background: #5a6268; }
            .error { color: #dc3545; margin-top: 15px; font-weight: 500; }
            .success { color: #28a745; margin-top: 15px; font-weight: 500; }
            .requirements { 
              text-align: left; 
              background: #f8f9fa; 
              padding: 15px; 
              border-radius: 8px; 
              margin-bottom: 20px;
              font-size: 14px;
            }
            .requirements ul { margin: 0; padding-left: 20px; }
            .requirements li { margin-bottom: 5px; color: #666; }
          </style>
          <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"></script>
          <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-auth.js"></script>
        </head>
        <body>
          <div class="container">
            <div class="lock-icon">🔒</div>
            <h1 class="title">Đặt Lại Mật Khẩu</h1>
            <p class="subtitle">Nhập mật khẩu mới cho tài khoản: <strong>${email.data.email}</strong></p>
            
            <div class="requirements">
              <strong>Yêu cầu mật khẩu:</strong>
              <ul>
                <li>Ít nhất 6 ký tự</li>
                <li>Nên bao gồm chữ hoa, chữ thường và số</li>
                <li>Không sử dụng mật khẩu quá đơn giản</li>
              </ul>
            </div>
            
            <form id="resetForm">
              <div class="form-group">
                <label for="newPassword">Mật khẩu mới:</label>
                <input type="password" id="newPassword" placeholder="Nhập mật khẩu mới" required minlength="6">
              </div>
              <div class="form-group">
                <label for="confirmPassword">Xác nhận mật khẩu:</label>
                <input type="password" id="confirmPassword" placeholder="Nhập lại mật khẩu mới" required minlength="6">
              </div>
              <button type="submit" class="btn">Đặt Lại Mật Khẩu</button>
              <a href="/" class="btn btn-secondary">Quay Về Trang Chủ</a>
            </form>
            
            <div id="message"></div>
          </div>
          
          <script>
            // Initialize Firebase
            const firebaseConfig = {
              apiKey: "AIzaSyDpzgsxZ1Jfs5hWAfS-gDbYfgkVte_jXoA",
              authDomain: "tech-haven-5368b.firebaseapp.com",
              projectId: "tech-haven-5368b",
              storageBucket: "tech-haven-5368b.appspot.com",
              messagingSenderId: "442337591630",
              appId: "1:442337591630:web:5d4977cc5c3cb44b7c3b8c"
            };
            firebase.initializeApp(firebaseConfig);
            const auth = firebase.auth();
            
            const actionCode = "${oobCode}";
            const userEmail = "${email.data.email}";
            
            document.getElementById('resetForm').addEventListener('submit', async function(e) {
              e.preventDefault();
              
              const newPassword = document.getElementById('newPassword').value;
              const confirmPassword = document.getElementById('confirmPassword').value;
              const messageDiv = document.getElementById('message');
              
              // Validation
              if (newPassword.length < 6) {
                messageDiv.innerHTML = '<div class="error">Mật khẩu phải có ít nhất 6 ký tự</div>';
                return;
              }
              
              if (newPassword !== confirmPassword) {
                messageDiv.innerHTML = '<div class="error">Mật khẩu xác nhận không khớp</div>';
                return;
              }
              
              try {
                // Show loading
                messageDiv.innerHTML = '<div style="color: #007bff;">Đang đặt lại mật khẩu...</div>';
                
                // Confirm password reset with Firebase
                await auth.confirmPasswordReset(actionCode, newPassword);
                
                messageDiv.innerHTML = '<div class="success">Mật khẩu đã được đặt lại thành công! Đang chuyển về trang đăng nhập...</div>';
                
                // Redirect to home page after 3 seconds
                setTimeout(() => {
                  window.location.href = '/?message=' + encodeURIComponent('Mật khẩu đã được đặt lại thành công! Vui lòng đăng nhập với mật khẩu mới.');
                }, 3000);
                
              } catch (error) {
                console.error('Password reset error:', error);
                let errorMessage = 'Có lỗi xảy ra khi đặt lại mật khẩu';
                
                if (error.code === 'auth/expired-action-code') {
                  errorMessage = 'Liên kết đặt lại mật khẩu đã hết hạn. Vui lòng yêu cầu reset lại.';
                } else if (error.code === 'auth/invalid-action-code') {
                  errorMessage = 'Liên kết đặt lại mật khẩu không hợp lệ.';
                } else if (error.code === 'auth/weak-password') {
                  errorMessage = 'Mật khẩu quá yếu. Vui lòng chọn mật khẩu mạnh hơn.';
                }
                
                messageDiv.innerHTML = '<div class="error">' + errorMessage + '</div>';
              }
            });
          </script>
        </body>
        </html>
      `);
      
    } catch (actionCodeError) {
      console.error('❌ Invalid password reset code:', actionCodeError);
      
      let errorMessage = 'Liên kết đặt lại mật khẩu không hợp lệ hoặc đã hết hạn';
      if (actionCodeError.code === 'auth/expired-action-code') {
        errorMessage = 'Liên kết đặt lại mật khẩu đã hết hạn';
      } else if (actionCodeError.code === 'auth/invalid-action-code') {
        errorMessage = 'Liên kết đặt lại mật khẩu không hợp lệ';
      }
      
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Lỗi Đặt Lại Mật Khẩu</title>
          <meta charset="UTF-8">
          <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5; }
            .container { background: white; padding: 40px; border-radius: 10px; max-width: 500px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .error-icon { font-size: 60px; color: #dc3545; margin-bottom: 20px; }
            .title { color: #333; margin-bottom: 20px; }
            .message { color: #666; margin-bottom: 30px; line-height: 1.6; }
            .btn { background: #667eea; color: white; padding: 12px 30px; border: none; border-radius: 5px; text-decoration: none; display: inline-block; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="error-icon">❌</div>
            <h1 class="title">Lỗi Đặt Lại Mật Khẩu</h1>
            <p class="message">${errorMessage}. Vui lòng yêu cầu đặt lại mật khẩu mới từ trang đăng nhập.</p>
            <a href="/" class="btn">Về Trang Chủ</a>
          </div>
        </body>
        </html>
      `);
    }
    
  } catch (error) {
    console.error('❌ Password reset route error:', error);
    res.status(500).send('Internal server error');
  }
});

// Email verification route (Firebase standard)
app.get('/verify-email', async (req, res) => {
  try {
    const { oobCode, uid } = req.query;
    
    if (!oobCode) {
      return res.status(400).send('Invalid verification link');
    }
    
    // Check the action code first to get user info
    const actionCodeInfo = await auth.checkActionCode(oobCode);
    const email = actionCodeInfo.data.email;
    console.log('📧 Verifying email for:', email);
    
    // Apply the action code to verify email
    await auth.applyActionCode(oobCode);
    console.log('✅ Email verified successfully in Firebase Auth');
    
    // Find and update user in Firestore
    try {
      let userDoc = null;
      
      // First try to find by uid parameter if provided
      if (uid) {
        const userRef = db.collection('users').doc(uid);
        userDoc = await userRef.get();
        console.log('🔍 Searching by UID:', uid, 'Found:', userDoc.exists);
      }
      
      // If not found by uid, search by email
      if (!userDoc || !userDoc.exists) {
        const userQuery = await db.collection('users').where('email', '==', email).limit(1).get();
        if (!userQuery.empty) {
          userDoc = userQuery.docs[0];
          console.log('🔍 Found user by email:', email);
        }
      }
      
      // Update user if found
      if (userDoc && userDoc.exists) {
        await userDoc.ref.update({
          emailVerified: true,
          'profile.isActive': true,
          verifiedAt: admin.firestore.FieldValue.serverTimestamp()
        });
        console.log('✅ User email verified and activated in Firestore:', email, 'UID:', userDoc.id);
      } else {
        console.log('⚠️ User not found in Firestore for email:', email);
        // Create a warning but don't fail the verification
      }
    } catch (firestoreError) {
      console.error('❌ Error updating Firestore after email verification:', firestoreError);
      // Don't fail the verification if Firestore update fails
    }
    
    // Render success page or redirect
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Email Xác Thực Thành Công</title>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5; }
          .container { background: white; padding: 40px; border-radius: 10px; max-width: 500px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .success-icon { font-size: 60px; color: #28a745; margin-bottom: 20px; }
          .title { color: #333; margin-bottom: 20px; }
          .message { color: #666; margin-bottom: 30px; line-height: 1.6; }
          .btn { background: #667eea; color: white; padding: 12px 30px; border: none; border-radius: 5px; text-decoration: none; display: inline-block; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="success-icon">✅</div>
          <h1 class="title">Email Xác Thực Thành Công!</h1>
          <p class="message">Chúc mừng! Email của bạn đã được xác thực thành công. Tài khoản của bạn đã được kích hoạt và bạn có thể đăng nhập để sử dụng dịch vụ.</p>
          <a href="/" class="btn">Về Trang Chủ</a>
        </div>
        <script>
          // Auto redirect after 5 seconds
          setTimeout(() => {
            window.location.href = '/';
          }, 5000);
        </script>
      </body>
      </html>
    `);
    
  } catch (error) {
    console.error('❌ Email verification error:', error);
    
    let errorMessage = 'Có lỗi xảy ra khi xác thực email';
    if (error.code === 'auth/invalid-action-code') {
      errorMessage = 'Link xác thực không hợp lệ hoặc đã hết hạn';
    } else if (error.code === 'auth/expired-action-code') {
      errorMessage = 'Link xác thực đã hết hạn';
    }
    
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Lỗi Xác Thực Email</title>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5; }
          .container { background: white; padding: 40px; border-radius: 10px; max-width: 500px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .error-icon { font-size: 60px; color: #dc3545; margin-bottom: 20px; }
          .title { color: #333; margin-bottom: 20px; }
          .message { color: #666; margin-bottom: 30px; line-height: 1.6; }
          .btn { background: #667eea; color: white; padding: 12px 30px; border: none; border-radius: 5px; text-decoration: none; display: inline-block; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="error-icon">❌</div>
          <h1 class="title">Lỗi Xác Thực Email</h1>
          <p class="message">${errorMessage}. Vui lòng liên hệ support hoặc đăng ký lại.</p>
          <a href="/" class="btn">Về Trang Chủ</a>
        </div>
      </body>
      </html>
    `);
  }
});

// Route to handle password reset (from Firebase Auth email)
app.get('/reset-password', async (req, res) => {
  try {
    const { oobCode, email } = req.query;
    
    if (!oobCode) {
      return res.status(400).send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Lỗi Reset Password</title>
          <style>
            body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
            .container { max-width: 500px; margin: 50px auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
            .error-icon { font-size: 48px; margin-bottom: 20px; }
            .title { color: #333; margin-bottom: 20px; }
            .message { color: #666; margin-bottom: 30px; line-height: 1.5; }
            .btn { display: inline-block; background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; transition: background 0.3s; }
            .btn:hover { background: #0056b3; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="error-icon">❌</div>
            <h1 class="title">Lỗi Reset Password</h1>
            <p class="message">Link reset password không hợp lệ hoặc đã hết hạn.</p>
            <a href="/" class="btn">Về Trang Chủ</a>
          </div>
        </body>
        </html>
      `);
    }

    // Display reset password form
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Đặt Lại Mật Khẩu</title>
        <style>
          body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
          .container { max-width: 500px; margin: 50px auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .title { color: #333; margin-bottom: 30px; text-align: center; }
          .form-group { margin-bottom: 20px; }
          .form-group label { display: block; margin-bottom: 8px; color: #333; font-weight: bold; }
          .form-group input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px; box-sizing: border-box; }
          .btn { width: 100%; background: #007bff; color: white; padding: 12px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; transition: background 0.3s; }
          .btn:hover { background: #0056b3; }
          .btn:disabled { background: #ccc; cursor: not-allowed; }
          .error { color: #dc3545; margin-top: 10px; font-size: 14px; }
          .success { color: #28a745; margin-top: 10px; font-size: 14px; }
          .back-link { text-align: center; margin-top: 20px; }
          .back-link a { color: #007bff; text-decoration: none; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1 class="title">Đặt Lại Mật Khẩu</h1>
          <form id="resetForm">
            <div class="form-group">
              <label for="newPassword">Mật khẩu mới:</label>
              <input type="password" id="newPassword" name="newPassword" required minlength="6" placeholder="Nhập mật khẩu mới (tối thiểu 6 ký tự)">
            </div>
            <div class="form-group">
              <label for="confirmPassword">Xác nhận mật khẩu:</label>
              <input type="password" id="confirmPassword" name="confirmPassword" required minlength="6" placeholder="Nhập lại mật khẩu mới">
            </div>
            <button type="submit" class="btn" id="submitBtn">Đặt Lại Mật Khẩu</button>
            <div id="message"></div>
          </form>
          <div class="back-link">
            <a href="/">← Về Trang Chủ</a>
          </div>
        </div>

        <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js"></script>
        <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-auth-compat.js"></script>
        <script>
          // Firebase config
          const firebaseConfig = {
            apiKey: "AIzaSyBYOy1NQmlXv8N4GjBXdCdIIe2PfTG0e1M",
            authDomain: "shopping-website-7cebf.firebaseapp.com",
            projectId: "shopping-website-7cebf",
            storageBucket: "shopping-website-7cebf.appspot.com",
            messagingSenderId: "442337591630",
            appId: "1:442337591630:web:36344e8a88fb8c4e4b1c19"
          };
          
          firebase.initializeApp(firebaseConfig);
          const auth = firebase.auth();
          
          const urlParams = new URLSearchParams(window.location.search);
          const oobCode = urlParams.get('oobCode');
          const email = urlParams.get('email') || '';
          
          document.getElementById('resetForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const messageDiv = document.getElementById('message');
            const submitBtn = document.getElementById('submitBtn');
            
            // Clear previous messages
            messageDiv.innerHTML = '';
            
            // Validate passwords
            if (newPassword !== confirmPassword) {
              messageDiv.innerHTML = '<div class="error">Mật khẩu xác nhận không khớp!</div>';
              return;
            }
            
            if (newPassword.length < 6) {
              messageDiv.innerHTML = '<div class="error">Mật khẩu phải có ít nhất 6 ký tự!</div>';
              return;
            }
            
            try {
              submitBtn.disabled = true;
              submitBtn.textContent = 'Đang xử lý...';
              
              // Verify the reset code and get email
              const email = await auth.verifyPasswordResetCode(oobCode);
              
              // Confirm password reset
              await auth.confirmPasswordReset(oobCode, newPassword);
              
              messageDiv.innerHTML = '<div class="success">Mật khẩu đã được đặt lại thành công! Đang chuyển hướng...</div>';
              setTimeout(() => {
                window.location.href = '/';
              }, 2000);
              
            } catch (error) {
              console.error('Password reset error:', error);
              let errorMessage = 'Có lỗi xảy ra khi đặt lại mật khẩu.';
              
              if (error.code === 'auth/expired-action-code') {
                errorMessage = 'Link đặt lại mật khẩu đã hết hạn.';
              } else if (error.code === 'auth/invalid-action-code') {
                errorMessage = 'Link đặt lại mật khẩu không hợp lệ.';
              } else if (error.code === 'auth/weak-password') {
                errorMessage = 'Mật khẩu quá yếu. Vui lòng chọn mật khẩu mạnh hơn.';
              }
              
              messageDiv.innerHTML = '<div class="error">' + errorMessage + '</div>';
              submitBtn.disabled = false;
              submitBtn.textContent = 'Đặt Lại Mật Khẩu';
            }
          });
        </script>
      </body>
      </html>
    `);
    
  } catch (error) {
    console.error('Reset password route error:', error);
    res.status(500).send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Lỗi Server</title>
        <style>
          body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
          .container { max-width: 500px; margin: 50px auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
          .error-icon { font-size: 48px; margin-bottom: 20px; }
          .title { color: #333; margin-bottom: 20px; }
          .message { color: #666; margin-bottom: 30px; line-height: 1.5; }
          .btn { display: inline-block; background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; transition: background 0.3s; }
          .btn:hover { background: #0056b3; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="error-icon">❌</div>
          <h1 class="title">Lỗi Server</h1>
          <p class="message">Có lỗi xảy ra khi xử lý yêu cầu. Vui lòng thử lại sau.</p>
          <a href="/" class="btn">Về Trang Chủ</a>
        </div>
      </body>
      </html>
    `);
  }
});

// API route for manual user login (without Google)
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Validation
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    
    // Find user by email
    const userQuery = await db.collection('users').where('email', '==', email).get();
    if (userQuery.empty) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    const userDoc = userQuery.docs[0];
    const userData = userDoc.data();
    
    // Check if user was created manually
    if (userData.provider !== 'manual') {
      return res.status(401).json({ error: 'Vui lòng sử dụng đăng nhập Google cho tài khoản này' });
    }
    
    // For manual users, verify password using Firebase Auth client SDK
    if (userData.firebaseUid) {
      try {
        // Use Firebase client SDK to verify password
        const { initializeApp } = require('firebase/app');
        const { getAuth, signInWithEmailAndPassword } = require('firebase/auth');
        
        // Initialize Firebase client app for password verification
        const firebaseConfig = {
          apiKey: "AIzaSyDpzgsxZ1Jfs5hWAfS-gDbYfgkVte_jXoA",
          authDomain: "tech-haven-5368b.firebaseapp.com",
          projectId: "tech-haven-5368b"
        };
        
        let clientApp;
        try {
          clientApp = initializeApp(firebaseConfig, 'client-auth');
        } catch (e) {
          // App already exists, get it
          const { getApps, getApp } = require('firebase/app');
          const apps = getApps();
          clientApp = apps.find(app => app.name === 'client-auth') || initializeApp(firebaseConfig, 'client-auth');
        }
        
        const clientAuth = getAuth(clientApp);
        
        // Verify password by attempting to sign in
        await signInWithEmailAndPassword(clientAuth, email, password);
        console.log('✅ Password verified with Firebase Auth');
        
        // Check email verification from Firebase Auth (source of truth)
        const firebaseUser = await auth.getUser(userData.firebaseUid);
        if (!firebaseUser.emailVerified) {
          return res.status(403).json({ 
            error: 'Email chưa được xác thực. Vui lòng kiểm tra email và click vào link xác thực.',
            requiresVerification: true 
          });
        }
        
        // Update Firestore to sync with Firebase Auth status if needed
        if (!userData.emailVerified) {
          await userDoc.ref.update({
            emailVerified: true,
            'profile.isActive': true,
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          });
          console.log('✅ Updated Firestore emailVerified status to match Firebase Auth');
        }
        
      } catch (authError) {
        console.error('❌ Firebase Auth verification failed:', authError);
        if (authError.code === 'auth/wrong-password' || authError.code === 'auth/user-not-found' || authError.code === 'auth/invalid-credential') {
          return res.status(401).json({ error: 'Email hoặc mật khẩu không đúng' });
        }
        return res.status(500).json({ error: 'Không thể xác thực đăng nhập' });
      }
    } else {
      return res.status(401).json({ error: 'Tài khoản không hợp lệ - missing Firebase UID' });
    }
    
    // Update last login
    await userDoc.ref.update({
      lastLoginAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    console.log('✅ Manual login successful for:', userData.name);
    
    res.json({
      success: true,
      message: 'Login successful',
      user: {
        uid: userData.uid,
        email: userData.email,
        name: userData.name,
        provider: userData.provider,
        is_admin: userData.is_admin || false
      }
    });
    
  } catch (error) {
    console.error('❌ Login error:', error);
    res.status(500).json({ error: 'Failed to login' });
  }
});

// API route to save additional user data
app.post('/api/user/update', verifyToken, async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  try {
    const { displayName, preferences } = req.body;
    const userRef = db.collection('users').doc(req.user.uid);
    
    await userRef.update({
      ...(displayName && { displayName }),
      ...(preferences && { preferences }),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    res.json({
      success: true,
      message: 'User updated successfully'
    });
    
  } catch (error) {
    console.error('❌ Error updating user:', error);
    res.status(500).json({ error: error.message });
  }
});

// API route to update user profile
app.post('/api/user/profile', async (req, res) => {
  try {
    const { uid, name, phone, photoUrl } = req.body;
    
    if (!uid) {
      return res.status(400).json({ error: 'User ID is required' });
    }
    
    console.log('📝 Updating profile for user:', uid);
    
    // Update data in Firestore
    const userRef = db.collection('users').doc(uid);
    const userDoc = await userRef.get();
    
    if (!userDoc.exists) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const updateData = {
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    if (name) updateData.name = name;
    if (phone) updateData.phone = phone;
    if (photoUrl !== undefined) updateData.photo = photoUrl; // Allow empty string to remove photo
    
    await userRef.update(updateData);
    
    // Also update Firebase Auth if it's a Firebase Auth user
    const userData = userDoc.data();
    if (userData.firebaseUid) {
      try {
        const authUpdateData = {};
        if (name) authUpdateData.displayName = name;
        if (photoUrl !== undefined) authUpdateData.photoURL = photoUrl;
        
        if (Object.keys(authUpdateData).length > 0) {
          await auth.updateUser(userData.firebaseUid, authUpdateData);
          console.log('✅ Firebase Auth user updated');
        }
      } catch (authError) {
        console.warn('⚠️ Could not update Firebase Auth user:', authError.message);
        // Continue anyway since Firestore update succeeded
      }
    }
    
    // Get updated user data
    const updatedDoc = await userRef.get();
    const updatedUserData = updatedDoc.data();
    
    res.json({
      success: true,
      message: 'Profile updated successfully',
      user: {
        uid: updatedUserData.uid,
        email: updatedUserData.email,
        name: updatedUserData.name,
        phone: updatedUserData.phone,
        photo: updatedUserData.photo,
        provider: updatedUserData.provider,
        is_admin: updatedUserData.is_admin || false
      }
    });
    
  } catch (error) {
    console.error('❌ Error updating profile:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// API route to get full user profile from Firestore
app.get('/api/user/profile', async (req, res) => {
  try {
    console.log('📱 Getting user profile...');
    
    // Check if we have authorization header first
    const authHeader = req.headers.authorization;
    let user = null;
    let searchUid = null;
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      // Try token verification first
      const idToken = authHeader.split('Bearer ')[1];
      try {
        const decodedToken = await auth.verifyIdToken(idToken);
        console.log('✅ Token verified for user:', decodedToken.email);
        searchUid = decodedToken.uid;
        
        // Find user in Firestore by firebaseUid first
        const usersSnapshot = await db.collection('users')
          .where('firebaseUid', '==', decodedToken.uid)
          .limit(1)
          .get();
        
        if (!usersSnapshot.empty) {
          user = usersSnapshot.docs[0].data();
          console.log('👤 User found by Firebase UID:', user.name);
        } else {
          // Try by custom UID
          const userDoc = await db.collection('users').doc(decodedToken.uid).get();
          if (userDoc.exists) {
            user = userDoc.data();
            console.log('� User found by custom UID:', user.name);
          }
        }
      } catch (tokenError) {
        console.error('❌ Token verification failed:', tokenError.message);
      }
    }
    
    // If no user found via token, try UID from query parameter
    if (!user && req.query.uid) {
      console.log('🔍 Searching user by UID from query:', req.query.uid);
      const userDoc = await db.collection('users').doc(req.query.uid).get();
      if (userDoc.exists) {
        user = userDoc.data();
        console.log('👤 User found by query UID:', user.name, 'Phone:', user.phone);
      }
    }
    
    if (!user) {
      console.log('❌ User not found');
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    console.log('📱 Returning user profile:', user.name, 'Phone:', user.phone || 'No phone');
    res.json({
      success: true,
      user: {
        uid: user.uid,
        email: user.email,
        name: user.name,
        phone: user.phone || '',
        photo: user.photo || '',
        provider: user.provider,
        is_admin: user.is_admin || false,
        emailVerified: user.emailVerified || false
      },
      profile: user, // Keep for compatibility
      lastUpdated: user.updatedAt?.toDate?.() || user.createdAt?.toDate?.()
    });
    
  } catch (error) {
    console.error('❌ Error getting user profile:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// API route to add item to wishlist
app.post('/api/user/wishlist', verifyToken, async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  try {
    const { productId, productName, productPrice, productImage } = req.body;
    const userRef = db.collection('users').doc(req.user.uid);
    
    await userRef.update({
      wishlist: admin.firestore.FieldValue.arrayUnion({
        productId,
        productName,
        productPrice,
        productImage,
        addedAt: new Date().toISOString()
      }),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    res.json({ success: true, message: 'Item added to wishlist' });
  } catch (error) {
    console.error('❌ Error adding to wishlist:', error);
    res.status(500).json({ error: 'Failed to add to wishlist' });
  }
});

// API route to get user statistics
app.get('/api/user/stats', verifyToken, async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  try {
    const userRef = db.collection('users').doc(req.user.uid);
    const userDoc = await userRef.get();
    
    if (userDoc.exists) {
      const userData = userDoc.data();
      res.json({
        success: true,
        stats: {
          memberSince: userData.createdAt?.toDate?.(),
          lastLogin: userData.lastLoginAt?.toDate?.(),
          totalOrders: userData.profile?.totalOrders || 0,
          totalSpent: userData.profile?.totalSpent || 0,
          membershipLevel: userData.profile?.membershipLevel || 'bronze',
          wishlistCount: userData.wishlist?.length || 0,
          addressCount: userData.addresses?.length || 0
        }
      });
    } else {
      res.status(404).json({ error: 'User profile not found' });
    }
  } catch (error) {
    console.error('❌ Error fetching user stats:', error);
    res.status(500).json({ error: 'Failed to fetch user statistics' });
  }
});

// Debug route to check token
app.post('/api/debug/token', async (req, res) => {
  const { idToken } = req.body;
  
  if (!idToken) {
    return res.json({ error: 'No token provided' });
  }
  
  try {
    const decodedToken = await auth.verifyIdToken(idToken);
    res.json({
      success: true,
      decoded: {
        uid: decodedToken.uid,
        email: decodedToken.email,
        name: decodedToken.name,
        picture: decodedToken.picture,
        provider: decodedToken.firebase.sign_in_provider,
        exp: new Date(decodedToken.exp * 1000),
        iat: new Date(decodedToken.iat * 1000)
      }
    });
  } catch (error) {
    res.json({
      error: error.message,
      code: error.code
    });
  }
});

// API route to check admin status
app.get('/api/user/admin-status', verifyToken, (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  res.json({
    success: true,
    user: {
      uid: req.user.uid,
      name: req.user.name,
      email: req.user.email,
      is_admin: req.user.is_admin
    },
    timestamp: new Date().toISOString()
  });
});

// API route to set admin status (only existing admins can promote others)
app.post('/api/user/set-admin', requireAdmin, async (req, res) => {
  try {
    const { userEmail, isAdmin } = req.body;
    
    if (!userEmail) {
      return res.status(400).json({ error: 'User email is required' });
    }
    
    // Find user by email
    const usersQuery = await db.collection('users').where('email', '==', userEmail).get();
    
    if (usersQuery.empty) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const userDoc = usersQuery.docs[0];
    await userDoc.ref.update({
      is_admin: !!isAdmin,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      adminUpdatedBy: req.user.email,
      adminUpdatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    console.log(`👑 Admin status updated for ${userEmail} to ${!!isAdmin} by ${req.user.email}`);
    
    res.json({
      success: true,
      message: `Admin status updated for ${userEmail}`,
      newStatus: !!isAdmin,
      updatedBy: req.user.email
    });
    
  } catch (error) {
    console.error('❌ Error updating admin status:', error);
    res.status(500).json({ error: 'Failed to update admin status' });
  }
});

// Debug route to test token verification
app.get('/debug/auth', async (req, res) => {
  const authHeader = req.headers.authorization;
  console.log('� Debug Auth Route');
  console.log('� Authorization header:', authHeader ? 'Present' : 'Missing');
  
  if (!authHeader) {
    return res.json({
      error: 'No Authorization header',
      message: 'Send request with "Authorization: Bearer <idToken>"',
      headers: req.headers
    });
  }
  
  try {
    const idToken = authHeader.split('Bearer ')[1];
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    console.log('✅ Token verified for user:', decodedToken.name);
    
    res.json({
      success: true,
      user: {
        uid: decodedToken.uid,
        name: decodedToken.name,
        email: decodedToken.email,
        picture: decodedToken.picture
      }
    });
  } catch (error) {
    console.error('❌ Token verification failed:', error.message);
    res.status(401).json({ error: 'Invalid token', details: error.message });
  }
});

// Admin routes (protected by admin privileges)
app.get('/admin', requireAdmin, (req, res) => {
  res.render('input', { user: req.user });
});

app.get('/admin/input', requireAdmin, (req, res) => {
  res.render('input', { user: req.user });
});

app.get('/admin/edit', requireAdmin, (req, res) => {
  res.render('edit', { 
    productId: null,
    user: req.user 
  });
});

app.get('/admin/edit/:productId', requireAdmin, (req, res) => {
  const productId = req.params.productId;
  res.render('edit', { 
    productId: productId,
    user: req.user 
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    service: 'Firebase Auth Demo'
  });
});

exports.app = onRequest(app);
