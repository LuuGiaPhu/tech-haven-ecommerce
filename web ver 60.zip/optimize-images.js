/**
 * Image Optimization Script
 * Automatically adds width/height attributes and optimizes images
 */

const fs = require('fs');
const path = require('path');

// Common image dimensions based on usage
const IMAGE_DIMENSIONS = {
    // Product images
    'product': { width: 800, height: 600 },
    'product-thumb': { width: 200, height: 150 },
    'product-small': { width: 400, height: 300 },
    
    // Avatar images
    'avatar': { width: 40, height: 40 },
    'avatar-large': { width: 80, height: 80 },
    
    // Hero/Banner images
    'hero': { width: 1920, height: 600 },
    'banner': { width: 1200, height: 400 },
    
    // Category images
    'category': { width: 600, height: 400 },
    
    // Logo/Icon
    'logo': { width: 200, height: 60 },
    'icon': { width: 32, height: 32 },
    
    // Default
    'default': { width: 800, height: 600 }
};

// Patterns to identify image types
const IMAGE_PATTERNS = {
    avatar: /avatar|user-icon|profile-pic/i,
    productThumb: /thumb|thumbnail|small/i,
    hero: /hero|banner|slider/i,
    category: /category|cat-/i,
    logo: /logo|brand/i,
    icon: /icon|ico-/i
};

/**
 * Determine image dimensions based on context
 */
function getImageDimensions(imgTag, context) {
    const lower = imgTag.toLowerCase();
    
    if (IMAGE_PATTERNS.avatar.test(lower)) {
        return IMAGE_DIMENSIONS.avatar;
    }
    if (IMAGE_PATTERNS.productThumb.test(lower)) {
        return IMAGE_DIMENSIONS['product-thumb'];
    }
    if (IMAGE_PATTERNS.hero.test(lower)) {
        return IMAGE_DIMENSIONS.hero;
    }
    if (IMAGE_PATTERNS.category.test(lower)) {
        return IMAGE_DIMENSIONS.category;
    }
    if (IMAGE_PATTERNS.logo.test(lower)) {
        return IMAGE_DIMENSIONS.logo;
    }
    if (IMAGE_PATTERNS.icon.test(lower)) {
        return IMAGE_DIMENSIONS.icon;
    }
    
    // Check context (product page vs shop page)
    if (context.includes('product_detail')) {
        return IMAGE_DIMENSIONS.product;
    }
    
    return IMAGE_DIMENSIONS.default;
}

/**
 * Add width/height to img tag if missing
 */
function optimizeImgTag(imgTag, context) {
    // Skip if already has both width and height
    if (/width\s*=/.test(imgTag) && /height\s*=/.test(imgTag)) {
        return imgTag;
    }
    
    const dimensions = getImageDimensions(imgTag, context);
    
    // Find the position to insert attributes (before closing >)
    const closePos = imgTag.lastIndexOf('>');
    if (closePos === -1) return imgTag;
    
    let optimized = imgTag.substring(0, closePos);
    
    // Add width if missing
    if (!/width\s*=/.test(imgTag)) {
        optimized += ` width="${dimensions.width}"`;
    }
    
    // Add height if missing
    if (!/height\s*=/.test(imgTag)) {
        optimized += ` height="${dimensions.height}"`;
    }
    
    // Add loading="lazy" if missing and not above-the-fold
    if (!/loading\s*=/.test(imgTag) && !isAboveTheFold(imgTag)) {
        optimized += ' loading="lazy"';
    }
    
    // Add decoding="async" for better performance
    if (!/decoding\s*=/.test(imgTag)) {
        optimized += ' decoding="async"';
    }
    
    optimized += imgTag.substring(closePos);
    
    return optimized;
}

/**
 * Check if image is above the fold (hero, logo, first product)
 */
function isAboveTheFold(imgTag) {
    const lower = imgTag.toLowerCase();
    return /hero|logo|banner|first/.test(lower);
}

/**
 * Process a single EJS file
 */
function processFile(filePath) {
    console.log(`Processing: ${filePath}`);
    
    const content = fs.readFileSync(filePath, 'utf8');
    const context = path.basename(filePath);
    
    // Find all <img> tags
    const imgRegex = /<img[^>]*>/g;
    let modified = content;
    let count = 0;
    
    const matches = content.match(imgRegex);
    if (matches) {
        matches.forEach(imgTag => {
            const optimized = optimizeImgTag(imgTag, context);
            if (optimized !== imgTag) {
                modified = modified.replace(imgTag, optimized);
                count++;
            }
        });
    }
    
    if (count > 0) {
        // Backup original file
        const backupPath = filePath + '.backup';
        fs.copyFileSync(filePath, backupPath);
        console.log(`  ✓ Created backup: ${backupPath}`);
        
        // Write optimized content
        fs.writeFileSync(filePath, modified, 'utf8');
        console.log(`  ✓ Optimized ${count} images`);
    } else {
        console.log(`  - No changes needed`);
    }
    
    return count;
}

/**
 * Main execution
 */
function main() {
    console.log('🚀 Starting Image Optimization...\n');
    
    const viewsDir = path.join(__dirname, 'functions', 'views');
    const files = [
        'index.ejs',
        'shop.ejs',
        'product_detail.ejs',
        'category.ejs'
    ];
    
    let totalOptimized = 0;
    
    files.forEach(file => {
        const filePath = path.join(viewsDir, file);
        if (fs.existsSync(filePath)) {
            const count = processFile(filePath);
            totalOptimized += count;
        } else {
            console.log(`⚠ File not found: ${filePath}`);
        }
    });
    
    console.log(`\n✅ Optimization complete!`);
    console.log(`   Total images optimized: ${totalOptimized}`);
    console.log(`\n📝 Next steps:`);
    console.log(`   1. Test your website: firebase serve`);
    console.log(`   2. Check PageSpeed: https://pagespeed.web.dev/`);
    console.log(`   3. If OK, deploy: firebase deploy`);
    console.log(`   4. If issues, restore from .backup files`);
}

// Run if called directly
if (require.main === module) {
    main();
}

module.exports = { optimizeImgTag, getImageDimensions };
