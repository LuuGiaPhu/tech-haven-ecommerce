// =====================================
//    REVENUE STATISTICS PAGE
// =====================================

let revenueChart, ordersChart, topProductsChart, categoryChart;
let currentPeriod = 'week';
let billsData = [];

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎨 Revenue page loaded');
    initializePage();
});

async function initializePage() {
    // Set default date range
    setDefaultDateRange();
    
    // Setup event listeners
    setupEventListeners();
    
    // Load bills data
    await loadBillsData();
    
    // Initialize charts
    initializeCharts();
    
    // Update statistics
    updateStatistics();
}

// Set default date range based on period
function setDefaultDateRange() {
    const endDate = new Date();
    const startDate = new Date();
    
    switch(currentPeriod) {
        case 'week':
            startDate.setDate(endDate.getDate() - 7);
            break;
        case 'month':
            startDate.setMonth(endDate.getMonth() - 1);
            break;
        case 'quarter':
            startDate.setMonth(endDate.getMonth() - 3);
            break;
        case 'year':
            startDate.setFullYear(endDate.getFullYear() - 1);
            break;
    }
    
    document.getElementById('startDate').valueAsDate = startDate;
    document.getElementById('endDate').valueAsDate = endDate;
}

// Setup event listeners
function setupEventListeners() {
    // Period buttons
    document.querySelectorAll('.period-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.period-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentPeriod = this.dataset.period;
            setDefaultDateRange();
            updateStatistics();
        });
    });
}

// Load bills data from Firebase
async function loadBillsData() {
    showLoading();
    
    try {
        console.log('📦 Loading bills data...');
        
        // Get Firebase Auth token
        let idToken = null;
        try {
            const currentUser = window.firebaseAuth?.currentUser;
            if (currentUser) {
                idToken = await currentUser.getIdToken();
                console.log('🔑 Got auth token for user:', currentUser.email);
            } else {
                console.warn('⚠️ No user logged in, waiting for auth state...');
                
                // Wait for auth state to be ready
                await new Promise((resolve) => {
                    const unsubscribe = window.firebaseAuth.onAuthStateChanged((user) => {
                        unsubscribe();
                        resolve(user);
                    });
                });
                
                const user = window.firebaseAuth.currentUser;
                if (user) {
                    idToken = await user.getIdToken();
                    console.log('🔑 Got auth token after waiting:', user.email);
                } else {
                    console.error('❌ No authenticated user found');
                    throw new Error('Authentication required. Please log in.');
                }
            }
        } catch (authError) {
            console.error('❌ Auth error:', authError);
            throw new Error('Failed to authenticate. Please log in again.');
        }
        
        const headers = {
            'Accept': 'application/json'
        };
        
        if (idToken) {
            headers['Authorization'] = `Bearer ${idToken}`;
        }
        
        const response = await fetch('/api/bills', {
            credentials: 'include',
            headers: headers
        });
        
        console.log('📥 Response status:', response.status, response.statusText);
        console.log('📥 Response headers:', Object.fromEntries(response.headers.entries()));
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ Response error:', errorText);
            
            if (response.status === 401) {
                throw new Error('Authentication failed. Please log in again.');
            } else if (response.status === 403) {
                throw new Error('Admin access required. You do not have permission.');
            }
            
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log('📦 Raw API response:', data);
        console.log('📊 API response details:', {
            success: data.success,
            totalBills: data.total,
            uniqueUsers: data.uniqueUsers,
            billsArrayLength: data.bills?.length
        });
        
        billsData = data.bills || [];
        
        console.log(`✅ Loaded ${billsData.length} bills`);
        if (billsData.length > 0) {
            console.log('📋 First bill sample:', billsData[0]);
            console.log('📋 Last bill sample:', billsData[billsData.length - 1]);
        }
        
        // Debug: Show unique userIds
        const uniqueUserIds = [...new Set(billsData.map(bill => bill.userId))];
        console.log(`👥 Unique users in bills: ${uniqueUserIds.length}`, uniqueUserIds);
        
        // Debug: Show bill distribution by user
        const userBillCounts = {};
        billsData.forEach(bill => {
            const userId = bill.userId || 'NO_USER_ID';
            userBillCounts[userId] = (userBillCounts[userId] || 0) + 1;
        });
        console.log('📊 Bills by user:', userBillCounts);
        
        // Debug: Show bill distribution by email
        const emailBillCounts = {};
        billsData.forEach(bill => {
            const email = bill.email || bill.customerEmail || 'NO_EMAIL';
            emailBillCounts[email] = (emailBillCounts[email] || 0) + 1;
        });
        console.log('📧 Bills by email:', emailBillCounts);
        
    } catch (error) {
        console.error('❌ Error loading bills:', error);
        
        // More user-friendly error messages
        let errorMessage = 'Không thể tải dữ liệu. ';
        if (error.message.includes('Authentication')) {
            errorMessage += 'Vui lòng đăng nhập lại.';
        } else if (error.message.includes('permission')) {
            errorMessage += 'Bạn không có quyền truy cập trang này.';
        } else {
            errorMessage += 'Vui lòng thử lại sau.';
        }
        
        showError(errorMessage);
        billsData = [];
    } finally {
        hideLoading();
    }
}

// Filter bills by date range
function getFilteredBills() {
    const startDateInput = document.getElementById('startDate').value;
    const endDateInput = document.getElementById('endDate').value;
    
    console.log('🔍 Filtering bills:', { startDateInput, endDateInput, totalBills: billsData.length });
    
    // If no date range selected, return all bills
    if (!startDateInput || !endDateInput) {
        console.log('⚠️ No date range selected, returning all bills');
        return billsData;
    }
    
    const startDate = new Date(startDateInput);
    const endDate = new Date(endDateInput);
    endDate.setHours(23, 59, 59, 999); // Include the whole end date
    
    const filtered = billsData.filter(bill => {
        // Convert createdAt to Date object (handle both ISO string and Timestamp object)
        let billDate;
        if (typeof bill.createdAt === 'string') {
            billDate = new Date(bill.createdAt);
        } else if (bill.createdAt?.toDate) {
            billDate = bill.createdAt.toDate();
        } else if (bill.createdAt?._seconds) {
            billDate = new Date(bill.createdAt._seconds * 1000);
        } else {
            console.warn('⚠️ Invalid createdAt format:', bill.createdAt);
            return false;
        }
        
        return billDate >= startDate && billDate <= endDate;
    });
    
    console.log(`✅ Filtered ${filtered.length} bills from ${billsData.length} total`);
    return filtered;
}

// Apply date filter
function applyDateFilter() {
    console.log('🔍 Applying date filter...');
    updateStatistics();
}

// Update all statistics
function updateStatistics() {
    const filteredBills = getFilteredBills();
    
    // Update summary cards
    updateSummaryCards(filteredBills);
    
    // Update charts
    updateRevenueChart(filteredBills);
    updateOrdersChart(filteredBills);
    updateTopProductsChart(filteredBills);
    updateCategoryChart(filteredBills);
    
    // Update table
    updateTable(filteredBills);
}

// Update summary cards
function updateSummaryCards(bills) {
    // Total revenue
    const totalRevenue = bills.reduce((sum, bill) => sum + (bill.totalAmount || 0), 0);
    // Display shortened value, but keep full value in title (tooltip)
    const totalRevenueEl = document.getElementById('totalRevenue');
    if (totalRevenueEl) {
        totalRevenueEl.textContent = formatPriceShort(totalRevenue) + ' ₫';
        // Provide native title and a data attribute for a custom CSS tooltip
        const fullTotal = formatPrice(totalRevenue);
        totalRevenueEl.setAttribute('title', fullTotal);
        totalRevenueEl.setAttribute('data-full', fullTotal);
        totalRevenueEl.setAttribute('tabindex', '0');
    }
    
    // Total orders
    document.getElementById('totalOrders').textContent = bills.length;
    
    // Average order value
    const avgOrderValue = bills.length > 0 ? totalRevenue / bills.length : 0;
    const avgOrderEl = document.getElementById('avgOrderValue');
    if (avgOrderEl) {
        avgOrderEl.textContent = formatPriceShort(avgOrderValue) + ' ₫';
        const fullAvg = formatPrice(avgOrderValue);
        avgOrderEl.setAttribute('title', fullAvg);
        avgOrderEl.setAttribute('data-full', fullAvg);
        avgOrderEl.setAttribute('tabindex', '0');
    }
    
    // Top product
    const productCounts = {};
    bills.forEach(bill => {
        if (bill.items && Array.isArray(bill.items)) {
            bill.items.forEach(item => {
                const productName = item.productName || item.name || 'Unknown';
                productCounts[productName] = (productCounts[productName] || 0) + (item.quantity || 1);
            });
        }
    });
    
    const topProduct = Object.entries(productCounts).sort((a, b) => b[1] - a[1])[0];
    document.getElementById('topProduct').textContent = topProduct ? topProduct[0] : '---';
}

// Initialize charts
function initializeCharts() {
    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    revenueChart = new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Doanh Thu',
                data: [],
                borderColor: '#FF9CEE',
                backgroundColor: 'rgba(255, 156, 238, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#FF9CEE',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    titleColor: '#333',
                    bodyColor: '#666',
                    borderColor: '#FFB5E8',
                    borderWidth: 2,
                    padding: 12,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return 'Doanh thu: ' + formatPrice(context.parsed.y);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return formatPriceShort(value);
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
    
    // Orders Chart
    const ordersCtx = document.getElementById('ordersChart').getContext('2d');
    ordersChart = new Chart(ordersCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Đơn Hàng',
                data: [],
                backgroundColor: 'rgba(197, 179, 255, 0.8)',
                borderColor: '#C5B3FF',
                borderWidth: 2,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    titleColor: '#333',
                    bodyColor: '#666',
                    borderColor: '#DCD3FF',
                    borderWidth: 2,
                    padding: 12,
                    displayColors: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
    
    // Top Products Chart
    const topProductsCtx = document.getElementById('topProductsChart').getContext('2d');
    topProductsChart = new Chart(topProductsCtx, {
        type: 'doughnut',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#FFB5E8',
                    '#DCD3FF',
                    '#AEC6FF',
                    '#FFE5F4',
                    '#F0EBFF'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        padding: 15,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    titleColor: '#333',
                    bodyColor: '#666',
                    borderColor: '#FFB5E8',
                    borderWidth: 2,
                    padding: 12
                }
            }
        }
    });
    
    // Category Chart
    const categoryCtx = document.getElementById('categoryChart').getContext('2d');
    categoryChart = new Chart(categoryCtx, {
        type: 'pie',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#FFB5E8',
                    '#DCD3FF',
                    '#AEC6FF',
                    '#FFE5F4',
                    '#F0EBFF',
                    '#E3ECFF'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        padding: 15,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    titleColor: '#333',
                    bodyColor: '#666',
                    borderColor: '#DCD3FF',
                    borderWidth: 2,
                    padding: 12
                }
            }
        }
    });
}

// Update Revenue Chart
function updateRevenueChart(bills) {
    const groupedData = groupBillsByPeriod(bills);
    
    revenueChart.data.labels = groupedData.labels;
    revenueChart.data.datasets[0].data = groupedData.revenues;
    revenueChart.update();
}

// Update Orders Chart
function updateOrdersChart(bills) {
    const groupedData = groupBillsByPeriod(bills);
    
    ordersChart.data.labels = groupedData.labels;
    ordersChart.data.datasets[0].data = groupedData.counts;
    ordersChart.update();
}

// Update Top Products Chart
function updateTopProductsChart(bills) {
    const productCounts = {};
    const productRevenues = {};
    
    bills.forEach(bill => {
        if (bill.items && Array.isArray(bill.items)) {
            bill.items.forEach(item => {
                const productName = item.productName || item.name || 'Unknown';
                const quantity = item.quantity || 1;
                const price = item.price || 0;
                
                productCounts[productName] = (productCounts[productName] || 0) + quantity;
                productRevenues[productName] = (productRevenues[productName] || 0) + (price * quantity);
            });
        }
    });
    
    // Get top 5 products by revenue
    const top5 = Object.entries(productRevenues)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
    
    topProductsChart.data.labels = top5.map(item => item[0]);
    topProductsChart.data.datasets[0].data = top5.map(item => item[1]);
    topProductsChart.update();
}

// Update Category Chart
function updateCategoryChart(bills) {
    const categoryRevenues = {};
    
    bills.forEach(bill => {
        if (bill.items && Array.isArray(bill.items)) {
            bill.items.forEach(item => {
                const category = item.category || 'Other';
                const price = item.price || 0;
                const quantity = item.quantity || 1;
                
                categoryRevenues[category] = (categoryRevenues[category] || 0) + (price * quantity);
            });
        }
    });
    
    categoryChart.data.labels = Object.keys(categoryRevenues);
    categoryChart.data.datasets[0].data = Object.values(categoryRevenues);
    categoryChart.update();
}

// Group bills by period
function groupBillsByPeriod(bills) {
    const grouped = {};
    
    console.log('📊 Grouping', bills.length, 'bills by period:', currentPeriod);
    
    bills.forEach(bill => {
        const billDate = convertToDate(bill.createdAt);
        let key;
        
        switch(currentPeriod) {
            case 'week':
                key = formatDate(billDate, 'day');
                break;
            case 'month':
                key = formatDate(billDate, 'day');
                break;
            case 'quarter':
                key = formatDate(billDate, 'week');
                break;
            case 'year':
                key = formatDate(billDate, 'month');
                break;
        }
        
        if (!grouped[key]) {
            grouped[key] = {
                revenue: 0,
                count: 0
            };
        }
        
        grouped[key].revenue += bill.totalAmount || 0;
        grouped[key].count += 1;
    });
    
    // Sort by date
    const sortedKeys = Object.keys(grouped).sort();
    
    console.log('✅ Grouped into', sortedKeys.length, 'periods:', sortedKeys);
    
    return {
        labels: sortedKeys,
        revenues: sortedKeys.map(key => grouped[key].revenue),
        counts: sortedKeys.map(key => grouped[key].count)
    };
}

// Format date based on period
function formatDate(date, format) {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    
    switch(format) {
        case 'day':
            return `${day}/${month}`;
        case 'week':
            const weekNum = getWeekNumber(date);
            return `T${weekNum}`;
        case 'month':
            return `${month}/${year}`;
        default:
            return `${day}/${month}/${year}`;
    }
}

// Get week number
function getWeekNumber(date) {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

// Update table
function updateTable(bills) {
    const tableBody = document.getElementById('tableBody');
    
    console.log('📋 Updating table with', bills.length, 'bills');
    
    if (bills.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="7" class="loading-row">
                    <i class="fas fa-inbox"></i>
                    Không có dữ liệu trong khoảng thời gian này
                </td>
            </tr>
        `;
        return;
    }
    
    // Sort bills by date (newest first)
    const sortedBills = [...bills].sort((a, b) => {
        const dateA = convertToDate(a.createdAt);
        const dateB = convertToDate(b.createdAt);
        return dateB - dateA;
    });
    
    tableBody.innerHTML = sortedBills.map(bill => {
        const billDate = convertToDate(bill.createdAt);
        const products = bill.items ? bill.items.map(item => item.productName || item.name).join(', ') : 'N/A';
        const totalQuantity = bill.items ? bill.items.reduce((sum, item) => sum + (item.quantity || 1), 0) : 0;
        const statusClass = bill.status === 'completed' ? 'status-completed' : 
                           bill.status === 'pending' ? 'status-pending' : 'status-cancelled';
        const statusText = bill.status === 'completed' ? 'Hoàn thành' : 
                          bill.status === 'pending' ? 'Đang xử lý' : 'Đã hủy';
        
        return `
            <tr>
                <td>${bill.id || 'N/A'}</td>
                <td>${formatDate(billDate, 'full')}</td>
                <td>${bill.customerName || bill.email || 'N/A'}</td>
                <td title="${products}">${products.length > 50 ? products.substring(0, 50) + '...' : products}</td>
                <td>${totalQuantity}</td>
                <td>${formatPrice(bill.totalAmount || 0)}</td>
                <td><span class="status-badge ${statusClass}">${statusText}</span></td>
            </tr>
        `;
    }).join('');
    
    console.log('✅ Table updated successfully');
}

// Export to CSV
function exportToCSV() {
    const filteredBills = getFilteredBills();
    
    if (filteredBills.length === 0) {
        alert('Không có dữ liệu để xuất');
        return;
    }
    
    // CSV Header
    let csv = 'Mã Đơn,Ngày,Khách Hàng,Sản Phẩm,Số Lượng,Tổng Tiền,Trạng Thái\n';
    
    // CSV Data
    filteredBills.forEach(bill => {
        const billDate = convertToDate(bill.createdAt);
        const products = bill.items ? bill.items.map(item => item.productName || item.name).join('; ') : 'N/A';
        const totalQuantity = bill.items ? bill.items.reduce((sum, item) => sum + (item.quantity || 1), 0) : 0;
        const statusText = bill.status === 'completed' ? 'Hoàn thành' : 
                          bill.status === 'pending' ? 'Đang xử lý' : 'Đã hủy';
        
        csv += `${bill.id || 'N/A'},${formatDate(billDate, 'full')},${bill.customerName || bill.email || 'N/A'},"${products}",${totalQuantity},${bill.totalAmount || 0},${statusText}\n`;
    });
    
    // Download CSV
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `revenue_${formatDate(new Date(), 'full').replace(/\//g, '-')}.csv`);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    console.log('✅ CSV exported successfully');
}

// Utility Functions
// Convert various date formats to Date object
function convertToDate(dateValue) {
    if (!dateValue) return new Date();
    
    // If already a Date object
    if (dateValue instanceof Date) {
        return dateValue;
    }
    
    // If ISO string
    if (typeof dateValue === 'string') {
        return new Date(dateValue);
    }
    
    // If Firestore Timestamp object with toDate method
    if (dateValue.toDate && typeof dateValue.toDate === 'function') {
        return dateValue.toDate();
    }
    
    // If Firestore Timestamp object with _seconds
    if (dateValue._seconds) {
        return new Date(dateValue._seconds * 1000);
    }
    
    // Fallback
    console.warn('⚠️ Unknown date format:', dateValue);
    return new Date(dateValue);
}

function formatPrice(price) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(price);
}

function formatPriceShort(price) {
    if (price >= 1000000) {
        return (price / 1000000).toFixed(1) + 'M';
    } else if (price >= 1000) {
        return (price / 1000).toFixed(0) + 'K';
    }
    return price.toString();
}

function showLoading() {
    document.getElementById('loadingOverlay').classList.add('active');
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.remove('active');
}

function showError(message) {
    alert(message);
}

// Make functions globally available
window.applyDateFilter = applyDateFilter;
window.exportToCSV = exportToCSV;
