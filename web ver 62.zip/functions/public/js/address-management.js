// =====================================
//       ADDRESS MANAGEMENT
// =====================================

// Global variables for address management
let userAddresses = [];
let selectedAddress = null;
let isEditingAddress = false;
let editingAddressIndex = -1;
let verifiedCoordinates = null; // Store verified coordinates from Google Maps
let isAddressVerified = false; // Flag to check if address is verified

// Load user addresses on page load
async function loadUserAddresses() {
    if (!window.currentUser) {
        console.log('👤 No authenticated user - cannot load addresses');
        return;
    }
    
    try {
        let response;
        
        // Check if user is manual login (has localStorage data) or Google login (has Firebase auth)
        const storedUser = localStorage.getItem('techHavenUser');
        const isManualUser = storedUser && window.currentUser.provider === 'manual';
        
        if (isManualUser) {
            // Use UID-based endpoint for manual users
            console.log('📍 Loading addresses for manual user via UID:', window.currentUser.uid);
            response = await fetch(`/api/user/addresses/by-uid/${window.currentUser.uid}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        } else {
            // Use token-based endpoint for Google users
            console.log('📍 Loading addresses for Google user via token');
            const token = await window.getIdToken();
            response = await fetch('/api/user/addresses', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
        }
        
        if (response.ok) {
            const data = await response.json();
            userAddresses = data.addresses || [];
            window.userAddresses = userAddresses; // Export to global scope
            console.log('✅ Loaded user addresses:', userAddresses.length);
            renderAddressList();
            
            // Auto-select default address if exists
            const defaultAddress = userAddresses.find(addr => addr.isDefault);
            if (defaultAddress) {
                selectAddress(userAddresses.indexOf(defaultAddress));
            }
        } else {
            console.error('❌ Error loading addresses:', response.status);
        }
    } catch (error) {
        console.error('❌ Error loading addresses:', error);
    }
}

// Render address list in checkout modal
function renderAddressList() {
    const addressList = document.getElementById('addressList');
    const noAddresses = document.getElementById('noAddresses');
    
    if (!addressList) return;
    
    if (userAddresses.length === 0) {
        addressList.innerHTML = '';
        if (noAddresses) noAddresses.style.display = 'block';
        return;
    }
    
    if (noAddresses) noAddresses.style.display = 'none';
    
    addressList.innerHTML = userAddresses.map((address, index) => `
        <div class="address-item ${address.isDefault ? 'default' : ''} ${selectedAddress === index ? 'selected' : ''}" 
             onclick="selectAddress(${index})">
            <div class="address-details">
                <div class="address-text">
                    <strong>${address.address}</strong><br>
                    ${address.district}, ${getCityName(address.city)}
                </div>
                <div class="address-actions">
                    ${!address.isDefault ? `
                        <button class="address-action-btn set-default" onclick="event.stopPropagation(); setDefaultAddress(${index})" title="Đặt làm mặc định">
                            <i class="fas fa-star"></i>
                        </button>
                    ` : ''}
                    <button class="address-action-btn" onclick="event.stopPropagation(); editAddress(${index})" title="Chỉnh sửa">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="address-action-btn delete" onclick="event.stopPropagation(); deleteAddress(${index})" title="Xóa">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Select address for checkout
function selectAddress(index) {
    selectedAddress = index;
    window.selectedAddress = index; // Export to global scope
    renderAddressList();
    
    // Show selected address display
    const selectedAddressDisplay = document.getElementById('selectedAddressDisplay');
    const selectedAddressText = document.getElementById('selectedAddressText');
    const savedAddresses = document.getElementById('savedAddresses');
    
    if (selectedAddressDisplay && selectedAddressText && savedAddresses) {
        const address = userAddresses[index];
        selectedAddressText.innerHTML = `
            <strong>${address.address}</strong><br>
            ${address.district}, ${getCityName(address.city)}
        `;
        
        selectedAddressDisplay.style.display = 'block';
        savedAddresses.style.display = 'none';
    }
}

// Change selected address (show address list again)
function changeSelectedAddress() {
    const selectedAddressDisplay = document.getElementById('selectedAddressDisplay');
    const savedAddresses = document.getElementById('savedAddresses');
    
    if (selectedAddressDisplay && savedAddresses) {
        selectedAddressDisplay.style.display = 'none';
        savedAddresses.style.display = 'block';
    }
}

// Toggle new address form
function toggleNewAddressForm() {
    const newAddressForm = document.getElementById('newAddressForm');
    const addressFormTitle = document.getElementById('addressFormTitle');
    
    if (newAddressForm) {
        const isVisible = newAddressForm.style.display === 'block';
        newAddressForm.style.display = isVisible ? 'none' : 'block';
        
        if (!isVisible) {
            // Reset form for new address
            isEditingAddress = false;
            editingAddressIndex = -1;
            if (addressFormTitle) addressFormTitle.textContent = 'Thêm địa chỉ mới';
            clearAddressForm();
        }
    }
}

// Cancel address form
function cancelAddressForm() {
    const newAddressForm = document.getElementById('newAddressForm');
    if (newAddressForm) {
        newAddressForm.style.display = 'none';
        clearAddressForm();
        isEditingAddress = false;
        editingAddressIndex = -1;
    }
}

// Clear address form
function clearAddressForm() {
    const fields = ['newShippingAddress', 'newShippingCity', 'newShippingDistrict'];
    fields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) field.value = '';
    });
    
    const setAsDefault = document.getElementById('setAsDefault');
    if (setAsDefault) setAsDefault.checked = false;
    
    // Reset verification status
    isAddressVerified = false;
    verifiedCoordinates = null;
    
    // Remove coordinates display
    const coordDisplay = document.querySelector('.coordinates-display');
    if (coordDisplay) coordDisplay.remove();
    
    // Hide save button and show verify button
    const saveBtn = document.querySelector('.save-address-btn');
    const verifyBtn = document.querySelector('.verify-address-btn');
    if (saveBtn) saveBtn.style.display = 'none';
    if (verifyBtn) verifyBtn.style.display = 'inline-flex';
}

// Verify address with Google Maps
async function verifyAddressWithGoogleMaps() {
    // Get form values
    const address = document.getElementById('newShippingAddress')?.value.trim();
    const city = document.getElementById('newShippingCity')?.value;
    const district = document.getElementById('newShippingDistrict')?.value.trim();
    
    // Validation
    if (!address || !city || !district) {
        alert('Vui lòng điền đầy đủ thông tin địa chỉ trước khi xác thực');
        return;
    }
    
    // Get city name for search
    const cityName = getCityName(city);
    const fullAddress = `${address}, ${district}, ${cityName}, Vietnam`;
    
    console.log('🗺️ Verifying address:', fullAddress);
    
    // Clear previous verification status
    localStorage.removeItem('addressVerified');
    localStorage.removeItem('verifiedAddress');
    
    // Create verification page URL
    const encodedAddress = encodeURIComponent(fullAddress);
    const verificationUrl = `/verify-address.html?address=${encodedAddress}&return=${encodeURIComponent(window.location.href)}`;
    
    // Show verification pending status
    showVerificationPending();
    
    // Open verification page in new window
    const verifyWindow = window.open(
        verificationUrl, 
        'AddressVerification',
        'width=1200,height=800,resizable=yes,scrollbars=yes'
    );
    
    // Listen for messages from verification window
    window.addEventListener('message', handleVerificationResponse, false);
    
    // Check verification status periodically (fallback for if postMessage doesn't work)
    const checkInterval = setInterval(() => {
        const verified = localStorage.getItem('addressVerified');
        const verifiedAddr = localStorage.getItem('verifiedAddress');
        const coordsStr = localStorage.getItem('verifiedCoordinates');
        
        if (verified === 'true' && verifiedAddr === fullAddress) {
            clearInterval(checkInterval);
            
            // Parse and store coordinates
            if (coordsStr) {
                try {
                    verifiedCoordinates = JSON.parse(coordsStr);
                    console.log('📍 Loaded coordinates from localStorage:', verifiedCoordinates);
                } catch (e) {
                    console.error('Error parsing coordinates:', e);
                }
            }
            
            handleSuccessfulVerification();
        } else if (verified === 'false') {
            clearInterval(checkInterval);
            handleCancelledVerification();
        }
        
        // Stop checking after 5 minutes
        if (Date.now() - (parseInt(localStorage.getItem('verificationTimestamp')) || 0) > 300000) {
            clearInterval(checkInterval);
        }
    }, 1000);
}

// Handle verification response from popup
function handleVerificationResponse(event) {
    // Check if message is from our verification page
    if (event.data && event.data.type === 'addressVerified') {
        if (event.data.verified) {
            // Store coordinates from verification
            if (event.data.coordinates) {
                verifiedCoordinates = event.data.coordinates;
                console.log('📍 Received coordinates:', verifiedCoordinates);
            }
            handleSuccessfulVerification();
        } else {
            handleCancelledVerification();
        }
        
        // Remove listener
        window.removeEventListener('message', handleVerificationResponse);
    }
}

// Handle successful verification
function handleSuccessfulVerification() {
    // Mark as verified
    isAddressVerified = true;
    
    // Show save button
    showSaveButton();
    
    // Display coordinates if available
    if (verifiedCoordinates && verifiedCoordinates.lat && verifiedCoordinates.lng) {
        const coordDisplay = document.createElement('div');
        coordDisplay.className = 'coordinates-display';
        coordDisplay.style.cssText = 'background: #e8f5e9; padding: 12px; border-radius: 6px; margin-bottom: 15px; border-left: 4px solid #4caf50;';
        coordDisplay.innerHTML = `
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                <i class="fas fa-map-marker-alt" style="color: #4caf50;"></i>
                <strong style="color: #2e7d32;">Tọa độ đã xác thực:</strong>
            </div>
            <div style="font-size: 13px; color: #555; margin-left: 24px;">
                <div>📍 Latitude: <strong>${verifiedCoordinates.lat}</strong></div>
                <div>📍 Longitude: <strong>${verifiedCoordinates.lng}</strong></div>
            </div>
        `;
        
        // Insert before form-actions
        const formActions = document.querySelector('.form-actions');
        if (formActions && formActions.parentNode) {
            // Remove old coordinate display if exists
            const oldDisplay = formActions.parentNode.querySelector('.coordinates-display');
            if (oldDisplay) oldDisplay.remove();
            
            formActions.parentNode.insertBefore(coordDisplay, formActions);
        }
        
        console.log('✅ Displaying coordinates:', verifiedCoordinates);
    }
    
    // Clear localStorage
    setTimeout(() => {
        localStorage.removeItem('addressVerified');
        localStorage.removeItem('verifiedAddress');
        localStorage.removeItem('verifiedCoordinates');
        localStorage.removeItem('verificationTimestamp');
    }, 1000);
    
    if (window.showNotification) {
        window.showNotification('✅ Địa chỉ đã được xác thực! Bạn có thể lưu địa chỉ.', 'success');
    } else {
        alert('✅ Địa chỉ đã được xác thực! Bạn có thể lưu địa chỉ.');
    }
}

// Handle cancelled verification
function handleCancelledVerification() {
    // Reset button state
    const verifyBtn = document.querySelector('.verify-address-btn');
    if (verifyBtn) {
        verifyBtn.disabled = false;
        verifyBtn.innerHTML = '<i class="fas fa-map-marker-alt"></i> Xác thực địa chỉ trên Google Maps';
    }
    
    // Clear localStorage
    setTimeout(() => {
        localStorage.removeItem('addressVerified');
        localStorage.removeItem('verifiedAddress');
        localStorage.removeItem('verificationTimestamp');
    }, 1000);
    
    if (window.showNotification) {
        window.showNotification('⚠️ Xác thực địa chỉ đã bị hủy.', 'warning');
    }
}

// Show verification pending status
function showVerificationPending() {
    const verifyBtn = document.querySelector('.verify-address-btn');
    if (verifyBtn) {
        verifyBtn.disabled = true;
        verifyBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xác thực...';
    }
}

// Show save button after verification
function showSaveButton() {
    const saveBtn = document.querySelector('.save-address-btn');
    const verifyBtn = document.querySelector('.verify-address-btn');
    
    if (saveBtn) {
        saveBtn.style.display = 'inline-flex';
        saveBtn.disabled = false;
    }
    
    if (verifyBtn) {
        verifyBtn.style.display = 'none';
        verifyBtn.disabled = false;
        verifyBtn.innerHTML = '<i class="fas fa-map-marker-alt"></i> Xác thực địa chỉ';
    }
}

// Save new or edited address
async function saveNewAddress() {
    if (!window.currentUser) {
        alert('Vui lòng đăng nhập để lưu địa chỉ');
        return;
    }
    
    // Check if address is verified
    if (!isAddressVerified) {
        alert('Vui lòng xác thực địa chỉ trên Google Maps trước khi lưu!');
        return;
    }
    
    // Get form values
    const address = document.getElementById('newShippingAddress')?.value.trim();
    const city = document.getElementById('newShippingCity')?.value;
    const district = document.getElementById('newShippingDistrict')?.value.trim();
    const setAsDefault = document.getElementById('setAsDefault')?.checked || false;
    
    // Validation
    if (!address || !city || !district) {
        alert('Vui lòng điền đầy đủ thông tin địa chỉ');
        return;
    }
    
    try {
        const addressData = {
            address,
            city,
            district,
            isDefault: setAsDefault,
            coordinates: verifiedCoordinates // Save verified coordinates
        };
        
        let response;
        
        // Check if user is manual login or Google login
        const storedUser = localStorage.getItem('techHavenUser');
        const isManualUser = storedUser && window.currentUser.provider === 'manual';
        
        if (isManualUser) {
            // Use UID-based endpoints for manual users
            if (isEditingAddress && editingAddressIndex >= 0) {
                console.log('📍 Updating address for manual user via UID');
                response = await fetch(`/api/user/addresses/by-uid/${window.currentUser.uid}/${editingAddressIndex}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(addressData)
                });
            } else {
                console.log('📍 Adding address for manual user via UID');
                response = await fetch(`/api/user/addresses/by-uid/${window.currentUser.uid}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(addressData)
                });
            }
        } else {
            // Use token-based endpoints for Google users
            const token = await window.getIdToken();
            if (isEditingAddress && editingAddressIndex >= 0) {
                console.log('📍 Updating address for Google user via token');
                response = await fetch(`/api/user/addresses/${editingAddressIndex}`, {
                    method: 'PUT',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(addressData)
                });
            } else {
                console.log('📍 Adding address for Google user via token');
                response = await fetch('/api/user/addresses', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(addressData)
                });
            }
        }
        
        if (response.ok) {
            const result = await response.json();
            console.log('✅ Address saved successfully');
            
            // Reload addresses and update UI
            await loadUserAddresses();
            cancelAddressForm();
            
            // Show success message
            if (window.showNotification) {
                window.showNotification(
                    isEditingAddress ? 'Địa chỉ đã được cập nhật!' : 'Địa chỉ mới đã được lưu!', 
                    'success'
                );
            }
        } else {
            const error = await response.json();
            console.error('❌ Error saving address:', error);
            alert(error.error || 'Không thể lưu địa chỉ. Vui lòng thử lại.');
        }
    } catch (error) {
        console.error('❌ Error saving address:', error);
        alert('Có lỗi xảy ra khi lưu địa chỉ. Vui lòng thử lại.');
    }
}

// Edit existing address
function editAddress(index) {
    if (index < 0 || index >= userAddresses.length) return;
    
    const address = userAddresses[index];
    isEditingAddress = true;
    editingAddressIndex = index;
    
    // Fill form with existing data
    const addressField = document.getElementById('newShippingAddress');
    const cityField = document.getElementById('newShippingCity');
    const districtField = document.getElementById('newShippingDistrict');
    const defaultField = document.getElementById('setAsDefault');
    const formTitle = document.getElementById('addressFormTitle');
    
    if (addressField) addressField.value = address.address;
    if (cityField) cityField.value = address.city;
    if (districtField) districtField.value = address.district;
    if (defaultField) defaultField.checked = address.isDefault;
    if (formTitle) formTitle.textContent = 'Chỉnh sửa địa chỉ';
    
    // When editing, mark as verified (existing address)
    isAddressVerified = true;
    verifiedCoordinates = address.coordinates || null;
    
    // Show save button directly for editing
    const saveBtn = document.querySelector('.save-address-btn');
    const verifyBtn = document.querySelector('.verify-address-btn');
    if (saveBtn) saveBtn.style.display = 'inline-flex';
    if (verifyBtn) verifyBtn.style.display = 'none';
    
    // Show form
    toggleNewAddressForm();
}

// Set address as default
async function setDefaultAddress(index) {
    if (!window.currentUser || index < 0 || index >= userAddresses.length) return;
    
    try {
        let response;
        
        // Check if user is manual login or Google login
        const storedUser = localStorage.getItem('techHavenUser');
        const isManualUser = storedUser && window.currentUser.provider === 'manual';
        
        if (isManualUser) {
            // Use UID-based endpoint for manual users
            console.log('📍 Setting default address for manual user via UID');
            response = await fetch(`/api/user/addresses/by-uid/${window.currentUser.uid}/${index}/set-default`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        } else {
            // Use token-based endpoint for Google users
            console.log('📍 Setting default address for Google user via token');
            const token = await window.getIdToken();
            response = await fetch(`/api/user/addresses/${index}/set-default`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
        }
        
        if (response.ok) {
            console.log('✅ Default address updated');
            
            // Update UI immediately - remove default class from all addresses
            const addressItems = document.querySelectorAll('.address-item');
            addressItems.forEach((item, itemIndex) => {
                if (itemIndex === index) {
                    // Add default class to new default address
                    item.classList.add('default');
                    // Update the address data
                    userAddresses[itemIndex].isDefault = true;
                } else {
                    // Remove default class from other addresses
                    item.classList.remove('default');
                    // Update the address data
                    if (userAddresses[itemIndex]) {
                        userAddresses[itemIndex].isDefault = false;
                    }
                }
            });
            
            // Also reload addresses to ensure data consistency (but UI already updated)
            setTimeout(() => {
                loadUserAddresses();
            }, 1000);
            
            if (window.showNotification) {
                window.showNotification('Địa chỉ mặc định đã được cập nhật!', 'success');
            }
        } else {
            const error = await response.json();
            console.error('❌ Error setting default address:', error);
            alert(error.error || 'Không thể đặt địa chỉ mặc định.');
        }
    } catch (error) {
        console.error('❌ Error setting default address:', error);
        alert('Có lỗi xảy ra. Vui lòng thử lại.');
    }
}

// Delete address
async function deleteAddress(index) {
    if (!window.currentUser || index < 0 || index >= userAddresses.length) return;
    
    const address = userAddresses[index];
    if (!confirm(`Bạn có chắc chắn muốn xóa địa chỉ này?\n\n${address.address}\n${address.district}, ${getCityName(address.city)}`)) {
        return;
    }
    
    try {
        let response;
        
        // Check if user is manual login or Google login
        const storedUser = localStorage.getItem('techHavenUser');
        const isManualUser = storedUser && window.currentUser.provider === 'manual';
        
        if (isManualUser) {
            // Use UID-based endpoint for manual users
            console.log('📍 Deleting address for manual user via UID');
            response = await fetch(`/api/user/addresses/by-uid/${window.currentUser.uid}/${index}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        } else {
            // Use token-based endpoint for Google users
            console.log('📍 Deleting address for Google user via token');
            const token = await window.getIdToken();
            response = await fetch(`/api/user/addresses/${index}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
        }
        
        if (response.ok) {
            console.log('✅ Address deleted successfully');
            await loadUserAddresses();
            
            // Reset selected address if it was deleted
            if (selectedAddress === index) {
                selectedAddress = null;
                const selectedAddressDisplay = document.getElementById('selectedAddressDisplay');
                const savedAddresses = document.getElementById('savedAddresses');
                
                if (selectedAddressDisplay && savedAddresses) {
                    selectedAddressDisplay.style.display = 'none';
                    savedAddresses.style.display = 'block';
                }
            } else if (selectedAddress > index) {
                selectedAddress--;
            }
            
            if (window.showNotification) {
                window.showNotification('Địa chỉ đã được xóa!', 'success');
            }
        } else {
            const error = await response.json();
            console.error('❌ Error deleting address:', error);
            alert(error.error || 'Không thể xóa địa chỉ.');
        }
    } catch (error) {
        console.error('❌ Error deleting address:', error);
        alert('Có lỗi xảy ra khi xóa địa chỉ. Vui lòng thử lại.');
    }
}

// Get city display name from city code
function getCityName(cityCode) {
    const cityMap = {
        'hanoi': 'Hà Nội',
        'hcm': 'TP. Hồ Chí Minh',
        'danang': 'Đà Nẵng',
        'haiphong': 'Hải Phòng',
        'cantho': 'Cần Thơ',
        'angiang': 'An Giang',
        'bacgiang': 'Bắc Giang',
        'backan': 'Bắc Kạn',
        'baclieu': 'Bạc Liêu',
        'bacninh': 'Bắc Ninh',
        'baria': 'Bà Rịa - Vũng Tàu',
        'bentre': 'Bến Tre',
        'binhdinh': 'Bình Định',
        'binhduong': 'Bình Dương',
        'binhphuoc': 'Bình Phước',
        'binhthuan': 'Bình Thuận',
        'camau': 'Cà Mau',
        'caobang': 'Cao Bằng',
        'daklak': 'Đắk Lắk',
        'daknong': 'Đắk Nông',
        'dienbien': 'Điện Biên',
        'dongnai': 'Đồng Nai',
        'dongthap': 'Đồng Tháp',
        'gialai': 'Gia Lai',
        'hagiang': 'Hà Giang',
        'hanam': 'Hà Nam',
        'hatinh': 'Hà Tĩnh',
        'haiduong': 'Hải Dương',
        'haugiang': 'Hậu Giang',
        'hoabinh': 'Hòa Bình',
        'hungyen': 'Hưng Yên',
        'khanhhoa': 'Khánh Hòa',
        'kiengiang': 'Kiên Giang',
        'kontum': 'Kon Tum',
        'laichau': 'Lai Châu',
        'lamdong': 'Lâm Đồng',
        'langson': 'Lạng Sơn',
        'laocai': 'Lào Cai',
        'longan': 'Long An',
        'namdinh': 'Nam Định',
        'nghean': 'Nghệ An',
        'ninhbinh': 'Ninh Bình',
        'ninhthuan': 'Ninh Thuận',
        'phutho': 'Phú Thọ',
        'phuyen': 'Phú Yên',
        'quangbinh': 'Quảng Bình',
        'quangnam': 'Quảng Nam',
        'quangngai': 'Quảng Ngãi',
        'quangninh': 'Quảng Ninh',
        'quangtri': 'Quảng Trị',
        'soctrang': 'Sóc Trăng',
        'sonla': 'Sơn La',
        'tayninh': 'Tây Ninh',
        'thaibinh': 'Thái Bình',
        'thainguyen': 'Thái Nguyên',
        'thanhhoa': 'Thanh Hóa',
        'thuathienhue': 'Thừa Thiên Huế',
        'tiengiang': 'Tiền Giang',
        'travinh': 'Trà Vinh',
        'tuyenquang': 'Tuyên Quang',
        'vinhlong': 'Vĩnh Long',
        'vinhphuc': 'Vĩnh Phúc',
        'yenbai': 'Yên Bái'
    };
    return cityMap[cityCode] || cityCode;
}

// Initialize address management when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Load addresses when checkout modal is opened
    const checkoutModal = document.getElementById('checkoutModal');
    if (checkoutModal) {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    if (checkoutModal.classList.contains('active')) {
                        // Modal opened - load addresses
                        loadUserAddresses();
                    }
                }
            });
        });
        
        observer.observe(checkoutModal, { attributes: true });
    }
});

// Make address management functions globally available
window.toggleNewAddressForm = toggleNewAddressForm;
window.cancelAddressForm = cancelAddressForm;
window.saveNewAddress = saveNewAddress;
window.verifyAddressWithGoogleMaps = verifyAddressWithGoogleMaps;
window.selectAddress = selectAddress;
window.changeSelectedAddress = changeSelectedAddress;
window.editAddress = editAddress;
window.setDefaultAddress = setDefaultAddress;
window.deleteAddress = deleteAddress;
window.loadUserAddresses = loadUserAddresses;

// Export address data for checkout
window.userAddresses = userAddresses;
window.selectedAddress = selectedAddress;
window.verifiedCoordinates = verifiedCoordinates;