# Tech Haven - Hybrid Deployment Guide

## Overview
This project now supports **hybrid deployment** - you can run it both locally for development and deploy to Firebase Functions for production.

## 🏠 Local Development

### Quick Start
```bash
cd functions
npm start
```

### Alternative with auto-restart
```bash
cd functions
npm run dev  # Uses nodemon for auto-restart
```

### Local Development Features
- **Express Server**: Runs directly on http://localhost:3000
- **Environment Detection**: Automatically detects local environment
- **Firebase Auth**: Full Firebase Authentication support
- **Firestore**: Connects to production Firestore database
- **Hot Reload**: Use `npm run dev` for automatic restarts
- **Health Check**: Available at http://localhost:3000/health

### Environment Variables
The system automatically detects the environment:
- **Local**: `NODE_ENV=development` or no environment variable
- **Firebase**: Detected via `process.env.FUNCTIONS_EMULATOR`

## ☁️ Firebase Deployment

### Deploy to Firebase Functions
```bash
cd functions
npm run deploy
```

### Firebase Features
- **Functions v2**: Node.js 20 runtime
- **Hosting**: Static assets served from functions/public
- **Firestore**: Database integration
- **Authentication**: Firebase Auth with email verification

### Firebase Commands
```bash
# Deploy functions only
firebase deploy --only functions

# Deploy everything (functions + hosting + firestore)
firebase deploy

# Test with Firebase emulators
firebase emulators:start

# View function logs
firebase functions:log
```

## 🔧 Architecture

### Hybrid Index.js Structure
```javascript
// Environment detection
const isDevelopment = !process.env.FUNCTIONS_EMULATOR

if (isDevelopment) {
  // Local Express server
  app.listen(3000, () => {
    console.log('🚀 Local server running on http://localhost:3000')
  })
} else {
  // Firebase Functions export
  exports.app = onRequest(app)
}
```

### Key Components
1. **Environment Detection**: Automatically switches between local and Firebase modes
2. **Express App**: Single codebase serves both environments
3. **Firebase Admin**: Initialized for both local and cloud environments
4. **Authentication**: Firebase Auth integration with ID token verification
5. **Static Files**: Served from functions/public directory

## 📂 Directory Structure
```
functions/
├── index.js                 # Hybrid server (Express + Firebase Functions)
├── package.json             # Dependencies and scripts
├── serviceAccountKey.json   # Firebase Admin credentials
├── public/                  # Static assets (CSS, JS, images)
├── views/                   # EJS templates
└── node_modules/           # Dependencies
```

## 🚀 Getting Started

### 1. Install Dependencies
```bash
cd functions
npm install
```

### 2. Start Local Development
```bash
npm start          # Standard start
npm run dev        # With auto-restart
```

### 3. Test Authentication
- Visit http://localhost:3000
- Test user registration/login
- Verify email functionality
- Test user profile editing

### 4. Deploy to Firebase
```bash
npm run deploy
```

## 🔐 Authentication Features

### Local Development
- ✅ Firebase Auth email/password
- ✅ Email verification
- ✅ Password reset
- ✅ User profile editing
- ✅ Admin system
- ✅ Session management

### Firebase Production
- ✅ All local features
- ✅ Scalable cloud infrastructure
- ✅ Global CDN for static assets
- ✅ Automatic SSL certificates

## 🛠️ Troubleshooting

### Local Development Issues
1. **Port 3000 in use**: Change port in index.js or kill existing processes
2. **Firebase Admin errors**: Check serviceAccountKey.json file exists
3. **CORS issues**: Firebase Auth domains may need configuration

### Firebase Deployment Issues
1. **Functions timeout**: Check function execution time
2. **Environment variables**: Ensure Firebase config is correct
3. **Dependencies**: Run `npm install` in functions directory

## 📊 Monitoring

### Local Development
- Console logs show real-time activity
- Health check: http://localhost:3000/health
- Firebase Auth dashboard: https://console.firebase.google.com

### Production
- Firebase Functions logs: `firebase functions:log`
- Firebase Console: https://console.firebase.google.com
- Performance monitoring available

## 🎯 Benefits

### Development Benefits
- **Fast Iteration**: No need to deploy for testing
- **Real Database**: Uses production Firestore
- **Full Feature Parity**: All features work locally
- **Easy Debugging**: Direct console access

### Production Benefits
- **Scalability**: Firebase Functions auto-scale
- **Performance**: Global CDN and edge locations
- **Security**: Google Cloud infrastructure
- **Monitoring**: Built-in logging and analytics

---

## Quick Commands Reference
```bash
# Local development
cd functions && npm start

# Deploy to Firebase
cd functions && npm run deploy

# Development with auto-restart
cd functions && npm run dev

# View Firebase logs
firebase functions:log
```