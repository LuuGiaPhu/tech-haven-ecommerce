// =====================================
// REAL-TIME COMMENT SYSTEM WITH WEBSOCKET
// =====================================

let commentsSocket = null;
let commentsListener = null;
let currentProductId = null;
let currentUserId = null;
let commentsData = [];
let isLoadingComments = false;
let commentsPerPage = 10;
let currentPage = 0;

// Initialize comment system when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Rate Comment System Initializing...');
    
    // Get product ID from the page
    currentProductId = getProductIdFromPage();
    if (!currentProductId) {
        console.error('❌ Product ID not found on page');
        return;
    }
    
    console.log('📦 Product ID found:', currentProductId);
    
    // Initialize comment system
    initializeCommentSystem();
});

// Get product ID from page elements
function getProductIdFromPage() {
    // Try multiple ways to get product ID
    const productElement = document.querySelector('[data-product-id]');
    if (productElement) {
        return productElement.dataset.productId;
    }
    
    // Try from URL path
    const pathParts = window.location.pathname.split('/');
    const productIndex = pathParts.findIndex(part => part === 'product');
    if (productIndex !== -1 && pathParts[productIndex + 1]) {
        return pathParts[productIndex + 1];
    }
    
    // Try from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('id') || urlParams.get('productId');
}

// Initialize the complete comment system
async function initializeCommentSystem() {
    console.log('🎯 Initializing comment system for product:', currentProductId);
    
    // Wait for authentication to be ready
    await waitForAuth();
    
    // Setup UI based on auth state
    setupCommentUI();
    
    // Setup Firebase auth state listener for dynamic UI updates
    if (window.firebaseAuth) {
        window.firebaseAuth.onAuthStateChanged((user) => {
            console.log('🔐 Auth state changed in comment system:', user ? 'logged in' : 'logged out');
            if (user) {
                currentUserId = user.uid;
            } else {
                currentUserId = null;
            }
            refreshCommentUIOnAuthChange();
        });
    }
    
    // Initialize WebSocket connection
    initializeWebSocket();
    
    // Setup Firebase real-time listener
    setupFirebaseCommentsListener();
    
    // Load initial comments
    await loadComments();
    
    // Setup event listeners
    setupEventListeners();
    
    console.log('✅ Comment system initialized successfully');
}

// Wait for authentication to be ready
function waitForAuth() {
    return new Promise((resolve) => {
        // Check multiple possible sources for user authentication
        const checkAuthState = () => {
            // Check window.currentUser (Firebase compat)
            if (window.currentUser && window.currentUser.uid) {
                currentUserId = window.currentUser.uid;
                console.log('👤 Auth state ready:', currentUserId ? 'Logged in' : 'Guest');
                return true;
            }
            
            // Check Firebase auth instance directly
            if (window.firebaseAuth && window.firebaseAuth.currentUser) {
                currentUserId = window.firebaseAuth.currentUser.uid;
                window.currentUser = window.firebaseAuth.currentUser; // Sync the variables
                console.log('👤 Auth state ready (from Firebase):', currentUserId ? 'Logged in' : 'Guest');
                return true;
            }
            
            // Check if auth state is still loading
            if (window.currentUser === undefined) {
                return false; // Still loading
            }
            
            // User is definitely not logged in
            currentUserId = null;
            console.log('👤 Auth state ready: Guest');
            return true;
        };
        
        if (checkAuthState()) {
            resolve();
        } else {
            // Wait for auth state to be determined
            const checkAuth = setInterval(() => {
                if (checkAuthState()) {
                    clearInterval(checkAuth);
                    resolve();
                }
            }, 100);
            
            // Timeout after 10 seconds to prevent infinite waiting
            setTimeout(() => {
                clearInterval(checkAuth);
                console.warn('⚠️ Auth check timeout, proceeding as guest');
                currentUserId = null;
                resolve();
            }, 10000);
        }
    });
}

// Setup comment UI based on authentication state
function setupCommentUI() {
    console.log('🎨 Setting up comment UI for user:', currentUserId);
    
    const userAvatar = document.getElementById('commentUserAvatar');
    const userName = document.getElementById('commentUserName');
    const commentText = document.getElementById('commentText');
    const submitBtn = document.querySelector('.btn-comment-submit');
    
    // Get user from multiple possible sources
    const user = window.currentUser || window.firebaseAuth?.currentUser;
    
    if (currentUserId && user) {
        console.log('👤 Setting up UI for logged in user:', user.displayName || user.email);
        
        // User is logged in
        // Update avatar
        if (userAvatar) {
            const photoURL = user.photoURL || user.photo;
            if (photoURL) {
                userAvatar.innerHTML = `<img src="${photoURL}" alt="Avatar" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">`;
            } else {
                const displayName = user.displayName || user.name || user.email || 'U';
                userAvatar.innerHTML = `<div class="avatar-placeholder" style="width: 40px; height: 40px; border-radius: 50%; background: #667eea; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold;">${displayName.charAt(0).toUpperCase()}</div>`;
            }
        }
        
        // Update name
        if (userName) {
            userName.textContent = user.displayName || user.name || user.email || 'Người dùng';
            userName.style.cursor = 'default';
            userName.onclick = null;
        }
        
        // Enable comment form
        if (commentText) {
            commentText.disabled = false;
            commentText.placeholder = 'Chia sẻ ý kiến của bạn về sản phẩm này...';
        }
        
        if (submitBtn) {
            submitBtn.disabled = false;
        }
    } else {
        console.log('👤 Setting up UI for guest user');
        
        // User is not logged in
        if (userAvatar) {
            userAvatar.innerHTML = '<i class="fas fa-user" style="cursor: pointer;" onclick="openLoginModal()"></i>';
        }
        
        if (userName) {
            userName.textContent = 'Vui lòng đăng nhập để bình luận';
            userName.style.cursor = 'pointer';
            userName.onclick = () => openLoginModal();
        }
        
        if (commentText) {
            commentText.disabled = true;
            commentText.placeholder = 'Vui lòng đăng nhập để bình luận...';
        }
        
        if (submitBtn) {
            submitBtn.disabled = true;
        }
    }
}

// Refresh comment UI when auth state changes
function refreshCommentUIOnAuthChange() {
    console.log('🔄 Refreshing comment UI due to auth change');
    
    // Re-check auth state
    const user = window.currentUser || window.firebaseAuth?.currentUser;
    if (user && user.uid) {
        currentUserId = user.uid;
    } else {
        currentUserId = null;
    }
    
    // Update UI
    setupCommentUI();
}

// Initialize WebSocket connection for real-time updates
function initializeWebSocket() {
    // For now, we'll use Firebase real-time listeners
    // WebSocket can be added later for additional real-time features
    console.log('🔌 WebSocket initialization (using Firebase real-time listeners)');
}

// Setup Firebase real-time listener for comments
function setupFirebaseCommentsListener() {
    if (!window.firebase?.firestore) {
        console.warn('⚠️ Firebase not available, skipping real-time listener');
        return;
    }
    
    // Stop existing listener if any
    if (commentsListener) {
        commentsListener();
        commentsListener = null;
    }
    
    const db = window.firebase.firestore();
    
    console.log('🎧 Setting up real-time comments listener for product:', currentProductId);
    
    // Listen to comments collection for this product
    commentsListener = db.collection('comments')
        .where('productId', '==', currentProductId)
        .orderBy('createdAt', 'desc')
        .onSnapshot((snapshot) => {
            console.log('📨 Comments snapshot received:', snapshot.size, 'comments');
            
            const comments = [];
            snapshot.forEach(doc => {
                const data = doc.data();
                comments.push({
                    id: doc.id,
                    ...data,
                    createdAt: data.createdAt?.toDate() || new Date()
                });
            });
            
            // Update local comments data
            commentsData = comments;
            
            // Re-render comments
            renderComments();
            
            // Update comments count
            updateCommentsCount();
            
        }, (error) => {
            console.error('❌ Error listening to comments:', error);
        });
}

// Load comments from Firebase
async function loadComments() {
    if (!window.firebase?.firestore || isLoadingComments) {
        return;
    }
    
    isLoadingComments = true;
    
    try {
        console.log('📥 Loading comments for product:', currentProductId);
        
        const db = window.firebase.firestore();
        
        const snapshot = await db.collection('comments')
            .where('productId', '==', currentProductId)
            .orderBy('createdAt', 'desc')
            .limit(commentsPerPage)
            .get();
        
        const comments = [];
        snapshot.forEach(doc => {
            const data = doc.data();
            comments.push({
                id: doc.id,
                ...data,
                createdAt: data.createdAt?.toDate() || new Date()
            });
        });
        
        commentsData = comments;
        renderComments();
        updateCommentsCount();
        
        console.log('✅ Comments loaded successfully:', comments.length);
        
    } catch (error) {
        console.error('❌ Error loading comments:', error);
        showCommentError('Không thể tải bình luận. Vui lòng thử lại.');
    } finally {
        isLoadingComments = false;
    }
}

// Render comments in the UI
function renderComments() {
    const commentsList = document.getElementById('commentsList');
    if (!commentsList) return;
    
    if (commentsData.length === 0) {
        commentsList.innerHTML = `
            <div class="comments-placeholder">
                <p style="text-align: center; color: #666; padding: 3rem 1rem;">
                    <i class="fas fa-comment-dots" style="font-size: 3rem; margin-bottom: 1rem; display: block; color: #667eea;"></i>
                    Chưa có bình luận nào cho sản phẩm này.<br>
                    Hãy là người đầu tiên chia sẻ ý kiến của bạn!
                </p>
            </div>
        `;
        return;
    }
    
    // Group comments by parent (main comments and replies)
    const mainComments = commentsData.filter(comment => !comment.isChild);
    const replies = commentsData.filter(comment => comment.isChild);
    
    let commentsHTML = '';
    
    mainComments.forEach(comment => {
        const commentReplies = replies.filter(reply => reply.parentId === comment.id);
        commentsHTML += renderComment(comment, commentReplies);
    });
    
    commentsList.innerHTML = commentsHTML;
}

// Render individual comment with replies
function renderComment(comment, replies = []) {
    const timeAgo = getTimeAgo(comment.createdAt);
    const canDelete = currentUserId === comment.userId;
    
    const userAvatar = comment.userAvatar 
        ? `<img src="${comment.userAvatar}" alt="Avatar" class="comment-avatar">`
        : `<div class="comment-avatar-placeholder">${comment.userDisplayName ? comment.userDisplayName.charAt(0).toUpperCase() : 'U'}</div>`;
    
    let repliesHTML = '';
    if (replies.length > 0) {
        repliesHTML = replies.map(reply => {
            const replyTimeAgo = getTimeAgo(reply.createdAt);
            const canDeleteReply = currentUserId === reply.userId;
            
            const replyAvatar = reply.userAvatar 
                ? `<img src="${reply.userAvatar}" alt="Avatar" class="comment-avatar">`
                : `<div class="comment-avatar-placeholder">${reply.userDisplayName ? reply.userDisplayName.charAt(0).toUpperCase() : 'U'}</div>`;
            
            return `
                <div class="comment-reply" data-comment-id="${reply.id}">
                    <div class="comment-content">
                        <div class="comment-header">
                            <div class="comment-user">
                                ${replyAvatar}
                                <div class="comment-user-info">
                                    <span class="comment-username">${reply.userDisplayName || 'Người dùng'}</span>
                                    <span class="comment-time">${replyTimeAgo}</span>
                                </div>
                            </div>
                            ${canDeleteReply ? `
                                <div class="comment-actions">
                                    <button class="btn-delete-comment" onclick="deleteComment('${reply.id}')" title="Xóa bình luận">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            ` : ''}
                        </div>
                        <div class="comment-text">${escapeHtml(reply.content)}</div>
                    </div>
                </div>
            `;
        }).join('');
    }
    
    return `
        <div class="comment-item" data-comment-id="${comment.id}">
            <div class="comment-content">
                <div class="comment-header">
                    <div class="comment-user">
                        ${userAvatar}
                        <div class="comment-user-info">
                            <span class="comment-username">${comment.userDisplayName || 'Người dùng'}</span>
                            <span class="comment-time">${timeAgo}</span>
                        </div>
                    </div>
                    <div class="comment-actions">
                        ${currentUserId ? `
                            <button class="btn-reply-comment" onclick="showReplyForm('${comment.id}')" title="Trả lời">
                                <i class="fas fa-reply"></i>
                            </button>
                        ` : ''}
                        ${canDelete ? `
                            <button class="btn-delete-comment" onclick="deleteComment('${comment.id}')" title="Xóa bình luận">
                                <i class="fas fa-trash"></i>
                            </button>
                        ` : ''}
                    </div>
                </div>
                <div class="comment-text">${escapeHtml(comment.content)}</div>
                
                <!-- Reply Form (hidden by default) -->
                <div class="reply-form" id="replyForm-${comment.id}" style="display: none;">
                    <div class="reply-input-group">
                        <textarea id="replyText-${comment.id}" placeholder="Viết câu trả lời..." rows="2"></textarea>
                        <div class="reply-actions">
                            <button type="button" class="btn-reply-cancel" onclick="hideReplyForm('${comment.id}')">
                                Hủy
                            </button>
                            <button type="button" class="btn-reply-submit" onclick="submitReply('${comment.id}')">
                                Trả lời
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Replies -->
                ${repliesHTML ? `<div class="comment-replies">${repliesHTML}</div>` : ''}
            </div>
        </div>
    `;
}

// Setup event listeners
function setupEventListeners() {
    // Comment form submission
    const commentForm = document.getElementById('commentForm');
    if (commentForm) {
        commentForm.addEventListener('submit', handleCommentSubmit);
    }
    
    // Clear comment button
    window.clearComment = clearComment;
    
    // Global functions for comment interactions
    window.showReplyForm = showReplyForm;
    window.hideReplyForm = hideReplyForm;
    window.submitReply = submitReply;
    window.deleteComment = deleteComment;
    window.loadMoreComments = loadMoreComments;
}

// Handle comment form submission
async function handleCommentSubmit(event) {
    event.preventDefault();
    
    if (!currentUserId) {
        openLoginModal();
        return;
    }
    
    const commentText = document.getElementById('commentText');
    const submitBtn = document.querySelector('.btn-comment-submit');
    
    if (!commentText || !commentText.value.trim()) {
        showCommentError('Vui lòng nhập nội dung bình luận');
        return;
    }
    
    const content = commentText.value.trim();
    
    // Disable form during submission
    commentText.disabled = true;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang gửi...';
    
    try {
        await submitComment(content);
        
        // Clear form
        commentText.value = '';
        showCommentSuccess('Bình luận đã được gửi thành công!');
        
    } catch (error) {
        console.error('❌ Error submitting comment:', error);
        showCommentError('Không thể gửi bình luận. Vui lòng thử lại.');
    } finally {
        // Re-enable form
        commentText.disabled = false;
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Gửi bình luận';
    }
}

// Submit a new comment to Firebase
async function submitComment(content, parentId = null) {
    if (!window.firebase?.firestore || !currentUserId) {
        throw new Error('Firebase not available or user not authenticated');
    }
    
    const db = window.firebase.firestore();
    const user = window.currentUser;
    
    const commentData = {
        productId: currentProductId,
        userId: currentUserId,
        userDisplayName: user.displayName || user.email || 'Người dùng',
        userAvatar: user.photoURL || null,
        content: content,
        isChild: !!parentId,
        parentId: parentId || null,
        createdAt: window.firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt: window.firebase.firestore.FieldValue.serverTimestamp()
    };
    
    console.log('📤 Submitting comment:', commentData);
    
    const docRef = await db.collection('comments').add(commentData);
    
    console.log('✅ Comment submitted with ID:', docRef.id);
    
    return docRef.id;
}

// Show reply form for a comment
function showReplyForm(commentId) {
    if (!currentUserId) {
        openLoginModal();
        return;
    }
    
    // Hide all other reply forms
    document.querySelectorAll('.reply-form').forEach(form => {
        form.style.display = 'none';
    });
    
    // Show the specific reply form
    const replyForm = document.getElementById(`replyForm-${commentId}`);
    if (replyForm) {
        replyForm.style.display = 'block';
        const textarea = document.getElementById(`replyText-${commentId}`);
        if (textarea) {
            textarea.focus();
        }
    }
}

// Hide reply form
function hideReplyForm(commentId) {
    const replyForm = document.getElementById(`replyForm-${commentId}`);
    if (replyForm) {
        replyForm.style.display = 'none';
        // Clear textarea
        const textarea = document.getElementById(`replyText-${commentId}`);
        if (textarea) {
            textarea.value = '';
        }
    }
}

// Submit a reply to a comment
async function submitReply(parentId) {
    const textarea = document.getElementById(`replyText-${parentId}`);
    if (!textarea || !textarea.value.trim()) {
        showCommentError('Vui lòng nhập nội dung trả lời');
        return;
    }
    
    const content = textarea.value.trim();
    
    // Disable form during submission
    textarea.disabled = true;
    
    try {
        await submitComment(content, parentId);
        
        // Hide reply form and clear content
        hideReplyForm(parentId);
        showCommentSuccess('Trả lời đã được gửi thành công!');
        
    } catch (error) {
        console.error('❌ Error submitting reply:', error);
        showCommentError('Không thể gửi trả lời. Vui lòng thử lại.');
    } finally {
        textarea.disabled = false;
    }
}

// Delete a comment
async function deleteComment(commentId) {
    if (!currentUserId || !window.firebase?.firestore) {
        return;
    }
    
    if (!confirm('Bạn có chắc chắn muốn xóa bình luận này?')) {
        return;
    }
    
    try {
        const db = window.firebase.firestore();
        
        // Delete the comment
        await db.collection('comments').doc(commentId).delete();
        
        // Also delete all replies to this comment
        const repliesSnapshot = await db.collection('comments')
            .where('parentId', '==', commentId)
            .get();
        
        const batch = db.batch();
        repliesSnapshot.forEach(doc => {
            batch.delete(doc.ref);
        });
        
        await batch.commit();
        
        showCommentSuccess('Bình luận đã được xóa');
        
    } catch (error) {
        console.error('❌ Error deleting comment:', error);
        showCommentError('Không thể xóa bình luận. Vui lòng thử lại.');
    }
}

// Clear comment form
function clearComment() {
    const commentText = document.getElementById('commentText');
    if (commentText) {
        commentText.value = '';
        commentText.focus();
    }
}

// Load more comments (pagination)
async function loadMoreComments() {
    // Implementation for pagination if needed
    console.log('Loading more comments...');
}

// Update comments count
function updateCommentsCount() {
    const countElement = document.getElementById('comments-total');
    if (countElement) {
        countElement.textContent = commentsData.length;
    }
}

// Utility functions
function getTimeAgo(date) {
    if (!date) return 'Vừa xong';
    
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (diffInSeconds < 60) {
        return 'Vừa xong';
    } else if (diffInSeconds < 3600) {
        const minutes = Math.floor(diffInSeconds / 60);
        return `${minutes} phút trước`;
    } else if (diffInSeconds < 86400) {
        const hours = Math.floor(diffInSeconds / 3600);
        return `${hours} giờ trước`;
    } else if (diffInSeconds < 604800) {
        const days = Math.floor(diffInSeconds / 86400);
        return `${days} ngày trước`;
    } else {
        return date.toLocaleDateString('vi-VN');
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showCommentSuccess(message) {
    // Use existing notification system
    if (typeof showNotification === 'function') {
        showNotification(message, 'success');
    } else {
        alert(message);
    }
}

function showCommentError(message) {
    // Use existing notification system
    if (typeof showNotification === 'function') {
        showNotification(message, 'error');
    } else {
        alert(message);
    }
}

// Cleanup function
function cleanupCommentSystem() {
    if (commentsListener) {
        commentsListener();
        commentsListener = null;
    }
    
    if (commentsSocket) {
        commentsSocket.close();
        commentsSocket = null;
    }
}

// Clean up when page unloads
window.addEventListener('beforeunload', cleanupCommentSystem);

// Export functions for global access
window.initializeCommentSystem = initializeCommentSystem;
window.setupCommentUI = setupCommentUI;
window.clearComment = clearComment;
window.showReplyForm = showReplyForm;
window.hideReplyForm = hideReplyForm;
window.submitReply = submitReply;
window.deleteComment = deleteComment;
window.loadMoreComments = loadMoreComments;

console.log('✅ Rate Comment System loaded successfully');